from flask import Flask, request, jsonify
from flask_restful import Resource, Api
from flask_sqlalchemy import SQLAlchemy
from order_status import order_status
import pandas as pd
import pyodbc
import datetime
import re
import os
import names


app = Flask(__name__)
api = Api(app)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# app.config['SQLALCHEMY_DATABASE_URI'] = "mssql+pyodbc://bestbuy_db:akash$123654@WIN-CCDM0AMH1KS/bestbuymaster?driver=SQL+Server"
app.config['SQLALCHEMY_DATABASE_URI'] = "mssql+pyodbc://DESKTOP-DV8PF1D/bestbuymaster?driver=SQL+Server"
db = SQLAlchemy(app)

condb = pyodbc.connect("Driver={SQL Server};"
                       "Server=DESKTOP-DV8PF1D;"
                       "Database=bestbuymaster;"
                       )
# condb = pyodbc.connect("Driver={SQL Server};"
#                       "Server=WIN-CCDM0AMH1KS;"
#                       "Database=bestbuymaster;"
#                       "uid=bestbuy_db;pwd=akash$123654"
#                        )
print('connected')

@app.route('/')
def hello_world():
   return "TESTING......."

class BuyingInformation(Resource):
    def get(self):
        jsondata = {}
        cursor = condb.cursor()
        sql = "SELECT TOP (1) [buyingitems].[cart_id] FROM [dbo].[buyingmaster] inner join [dbo].[buyingitems] On buyingmaster.cart_id = buyingitems.cart_id WHERE buyingitems.working_status = 'Active' and (buyingmaster.Date_modify <= DATEADD(second,-1, GETDATE())) and buyingmaster.status = 'Paused' group by buyingitems.cart_id, priority, CAST( CONVERT(CHAR(16), buyingmaster.Date_modify,20) AS datetime) ORDER BY priority ASC,CAST(CONVERT(CHAR(16), buyingmaster.Date_modify,20) AS datetime) ASC"
        cursor.execute(sql)
        numberofcarts = cursor.fetchall()
        if len(numberofcarts) !=0:
            sql = "UPDATE [bestbuymaster].[dbo].[buyingmaster] SET Date_modify=GETDATE(), status='Active' WHERE cart_id=?"
            val = (numberofcarts[0][0])
            cursor.execute(sql, val)
            cursor.commit()
        if len(numberofcarts) == 0:
            sql = "SELECT TOP (1) [buyingitems].[cart_id] FROM [dbo].[buyingmaster] inner join [dbo].[buyingitems] On buyingmaster.cart_id = buyingitems.cart_id WHERE buyingitems.working_status = 'Active' and buyingmaster.status = 'Active' group by buyingitems.cart_id, priority, CAST( CONVERT(CHAR(16), buyingmaster.Date_creation,20) AS datetime) ORDER BY priority ASC,CAST(CONVERT(CHAR(16), buyingmaster.Date_creation,20) AS datetime) ASC"
            cursor.execute(sql)
            numberofcarts = cursor.fetchall()
        if len(numberofcarts) != 0:
            datalist = []
            cart_id = numberofcarts[0].cart_id
            # sql = "SELECT [loop_status],[cart_loop],[loop_ount],[fullname],[address_id],[email_id],[phone],[cart_id] FROM [dbo].[buyingitems] WHERE cart_id = {0} AND buyingitems.working_status = 'Active' AND buyingitems.loop_status ='Initial'".format(cart_id)
            sql = "SELECT [loop_status],[cart_loop],[loop_ount],[address_ids],[email_ids],[cart_id] FROM [dbo].[buyingitems] WHERE cart_id = {0} AND buyingitems.working_status = 'Active'".format(
                cart_id)
            cursor.execute(sql)
            items_loop = cursor.fetchall()
            if len(items_loop) != 0:
                sql = "SELECT [id], [item_sku], [price], [qty_percart], [unit_total], [shipping], [tax], [subtotal], [total_cost], [payment_type], [cart_id], [company_id], unfulfilled, order_count, completed_count, cancelled_count FROM [dbo].[buyingmaster] WHERE cart_id = {0} AND status = 'Active' ORDER BY priority ASC, buyingmaster.Date_creation DESC".format(
                    cart_id)
                cursor.execute(sql)
                datalist = cursor.fetchall()
            for item in items_loop:
                if cart_id == item.cart_id:
                    address_ids = item.address_ids.split(",")
                    email_ids = item.email_ids.split(",")

                    jsondata['cart_loop'] = item.cart_loop
                    jsondata['loop_status'] = item.loop_status
                    jsondata['address_family'] = address_ids
                    jsondata['email_family'] = email_ids
                    jsondata['loop_count'] = item.loop_ount
                    jsondata['cart_id'] = cart_id
            item_list = []
            for data in datalist:
                jsdata = {}
                if cart_id == data.cart_id:
                    jsdata['id'] = data.id
                    jsdata['item_sku'] = data.item_sku
                    jsdata['price'] = data.price
                    jsdata['qty_percart'] = data.qty_percart
                    jsdata['unit_total'] = data.unit_total
                    jsdata['shipping'] = data.shipping
                    jsdata['tax'] = data.tax
                    jsdata['subtotal'] = data.subtotal
                    jsdata['total_cost'] = data.total_cost
                    jsdata['payment_type'] = data.payment_type
                    jsdata['cart_id'] = cart_id
                    jsondata['order_count'] = data.order_count
                    jsondata['unfulfilled'] = data.unfulfilled
                    jsondata['completedcount'] = data.completed_count
                    jsondata['cancelledcount'] = data.cancelled_count
                    jsondata['match_count'] = data.cancelled_count + data.completed_count
                    item_list.append(jsdata)
            jsondata['items'] = item_list
        return jsonify({'message': 'successfully', "code": 200, "buyingdatalist": jsondata})

    def post(self):
        data = request.get_json()
        cart_id = None
        work = data["work"]
        if "loop_status" in data:
            work_status = data["loop_status"]
        if "cart_id" in data:
            cart_id = data["cart_id"]
        else:
            return jsonify({'message': "'cart_id' must be required for the operation", 'code': 404})
        cursor = condb.cursor()
        list_status = ['Inprogress', 'Failed', 'Finished']
        if work == 'setloopstatus':
            status = str(work_status).title()
            messages = None
            message = []
            if status in list_status:
                sql = "UPDATE [dbo].[buyingitems] SET [loop_status] =? WHERE [cart_id]=?"
                val = (status, cart_id)
                cursor.execute(sql, val)
                cursor.commit()
                sql = "SELECT TOP (1) [buyingmaster].[cart_id], [cart_loop], [loop_ount], [working_status], [loop_status], [order_count], [completed_count], [cancelled_count], [unfulfilled] FROM [dbo].[buyingitems] INNER JOIN [dbo].[buyingmaster] ON [buyingmaster].[cart_id] = [buyingitems].[cart_id] WHERE [buyingitems].[cart_id]=?"
                val = (cart_id)
                cursor.execute(sql, val)
                cart_status = cursor.fetchone()
                if status != 'Initial':
                    if cart_status != None:
                        if cart_status.unfulfilled == 0:
                            cursor = condb.cursor()
                            if status == "Finished":
                                sql = "UPDATE [dbo].[buyingitems] SET [working_status] =?, [Date_modify]=? WHERE [cart_id]=?"
                                val = (status, datetime.datetime.now(), cart_id)
                                cursor.execute(sql, val)
                                cursor.commit()
                                sql = "UPDATE [dbo].[buyingmaster] SET [status] =?, [Date_extention]=?, [Date_modify]=? WHERE [cart_id]=?"
                                val = ('Inactive', datetime.datetime.now(), datetime.datetime.now(), cart_id)
                                cursor.execute(sql, val)
                                cursor.commit()
                                message.append(
                                    "You have change status Finished.")
                            elif status == "Failed":
                                sql = "SELECT sum(completed_count) as completed FROM [dbo].[buyingmaster] WHERE [cart_id]=?"
                                cursor.execute(sql, cart_id)
                                cart_completed_status = cursor.fetchone()
                                if cart_completed_status:
                                    complted_count = cart_completed_status.completed
                                    if int(complted_count) > 0:
                                        sql = "UPDATE [dbo].[buyingitems] SET [working_status] =?, [Date_modify]=? WHERE [cart_id]=?"
                                        val = ('Finished', datetime.datetime.now(), cart_id)
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                        sql = "UPDATE [dbo].[buyingmaster] SET [status] =?, [Date_extention]=?, [Date_modify]=? WHERE [cart_id]=?"
                                        val = ('Inactive', datetime.datetime.now(), datetime.datetime.now(), cart_id)
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                        message.append(
                                            "You have change status Finished.")
                                    else:
                                        sql = "UPDATE [dbo].[buyingitems] SET [working_status] =?, [Date_modify]=? WHERE [cart_id]=?"
                                        val = (status, datetime.datetime.now(), cart_id)
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                        sql = "UPDATE [dbo].[buyingmaster] SET [status] =?, [Date_extention]=?, [Date_modify]=? WHERE [cart_id]=?"
                                        val = ('Cancelled', datetime.datetime.now(), datetime.datetime.now(), cart_id)
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                        message.append(
                                            "You have change status Failed.")
                                else:
                                    sql = "UPDATE [dbo].[buyingitems] SET [working_status] =?, [Date_modify]=? WHERE [cart_id]=?"
                                    val = (status, datetime.datetime.now(), cart_id)
                                    cursor.execute(sql, val)
                                    cursor.commit()
                                    sql = "UPDATE [dbo].[buyingmaster] SET [status] =?, [Date_extention]=?, [Date_modify]=? WHERE [cart_id]=?"
                                    val = ('Cancelled', datetime.datetime.now(), datetime.datetime.now(), cart_id)
                                    cursor.execute(sql, val)
                                    cursor.commit()
                                    message.append(
                                        "You have change status Failed.")
                            elif status == "Paused":
                                sql = "UPDATE [dbo].[buyingitems] SET [working_status] =?, [Date_modify]=? WHERE [cart_id]=?"
                                val = (status, datetime.datetime.now(), cart_id)
                                cursor.execute(sql, val)
                                cursor.commit()
                                sql = "UPDATE [dbo].[buyingmaster] SET [status] =?, [Date_extention]=?, [Date_modify]=? WHERE [cart_id]=?"
                                val = (status, datetime.datetime.now(), datetime.datetime.now(), cart_id)
                                cursor.execute(sql, val)
                                cursor.commit()
                                message.append(
                                    "You have change status Paused.")
                            else:
                                message.append(
                                    "Please change the status to Finished, Failed, or Paused. Your product loop has fulfilled.")
                                # sql query for getting data from the buying manager table on the basic of id
                        else:
                            sql = "UPDATE [dbo].[buyingitems] SET [Date_modify]=?, [loop_ount] += 1 WHERE [cart_id]=?"
                            val = (datetime.datetime.now(), cart_id)
                            cursor.execute(sql, val)
                            cursor.commit()
                            message.append(
                                "Your buying items successfully processed.")
                    else:
                        return jsonify(
                            {'message': 'The cart id is not matching, please use the correct cart id.', 'code': 404})
                else:
                    sql = "SELECT TOP (1) id FROM [dbo].[buyingitems] WHERE working_status ='Active' AND loop_status ='Initial' AND cart_id =?"
                    cursor.execute(sql, cart_id)
                    sql_data = cursor.fetchone()
                    if sql_data is None:
                        sql = "SELECT TOP (1) id, loop_status FROM [dbo].[buyingitems] WHERE working_status ='Active' AND loop_status is Null AND cart_id =?"
                        cursor.execute(sql, cart_id)
                        sql_data = cursor.fetchone()
                        if sql_data:
                            sql = "UPDATE [dbo].[buyingitems] SET [Date_modify]=?, [loop_status] =? WHERE [cart_id]=?"
                            val = ("Initial", datetime.datetime.now(), sql_data.id)
                            cursor.execute(sql, val)
                            cursor.commit()
                            message.append(
                                "You are reset your buying items.")
                sql = "SELECT TOP (1) buyingitems.cart_id, order_count, completed_count, unfulfilled, cancelled_count, cart_loop, loop_ount, working_status, loop_status FROM [dbo].[buyingmaster] INNER JOIN [dbo].[buyingitems] ON [buyingmaster].[cart_id]=[buyingitems].[cart_id] WHERE buyingitems.cart_id=?"
                val = (cart_id)
                cursor.execute(sql, val)
                cart_status = cursor.fetchone()
                if cart_status:
                    data = {}
                    data['cart_id'] = cart_status.cart_id
                    data['completedcount'] = cart_status.completed_count
                    data['unfulfilled'] = cart_status.unfulfilled
                    data['cancelledcount'] = cart_status.cancelled_count
                    data['cart_loop'] = cart_status.cart_loop
                    data['loop_count'] = cart_status.loop_ount
                    data['working_status'] = cart_status.working_status
                    data['order_count'] = cart_status.order_count
                    data['loop_status'] = cart_status.loop_status
                messages = (" ").join(message)
                if messages == "Please change the status to Finished, Failed, or Paused. Your product loop has fulfilled.":
                    return jsonify({'message': messages, 'code': 201, 'data': data})
                return jsonify({'message': messages, 'code': 200, 'data': data})
            else:
                return jsonify(
                    {'message': 'Please use valid loop status - Inprogress, Failed or Finished', 'code': 404})
        elif work == 'setbuyingorderscount':
            status = str(work_status).title()
            messages = None
            message = []
            cancellation_rate, cancellation = 0, 0
            sql = "SELECT cancellation_rate, cancellation FROM [dbo].[settings]"
            cursor.execute(sql)
            table_Data = cursor.fetchone()
            if table_Data:
                cancellation_rate = table_Data.cancellation_rate
                cancellation = table_Data.cancellation
            sql = "SELECT [cart_loop], [loop_ount], [working_status], [loop_status], [order_count], [completed_count], [cancelled_count], [unfulfilled] FROM [dbo].[buyingitems] INNER JOIN [dbo].[buyingmaster] ON [buyingmaster].[cart_id] = [buyingitems].[cart_id] WHERE [buyingitems].[cart_id]=?"
            # execute sql query
            cursor.execute(sql, cart_id)
            buying_data = cursor.fetchone()
            sql = "SELECT count(case when tracking_status != 'Cancelled' then 1 else null end) as completed_count, count(case when tracking_status = 'Cancelled' then 1 else null end) as cancelled_count FROM [bestbuymaster].[dbo].[ordertracking] WHERE [ordertracking].[cart_id]=? group by  order_number, tracking_status"
            cursor.execute(sql, cart_id)
            order_Data = cursor.fetchall()
            order_completed_count, order_cancelled_count = 0, 0
            for data in order_Data:
                if data.completed_count > 0:
                    order_completed_count +=1
                if data.cancelled_count > 0:
                    order_cancelled_count +=1
            sql = "SELECT count(order_number) as order_count FROM [bestbuymaster].[dbo].[ordertracking] WHERE [ordertracking].[cart_id]=? group by order_number"
            cursor.execute(sql, cart_id)
            active_order_count = cursor.fetchall()
            active_orders = len(active_order_count)
            # if the quantity is already fulfilled add 1 to it
            if buying_data != None:
                completed_count = buying_data.completed_count
                loop_count = buying_data.loop_ount
                cart_count = buying_data.cart_loop
                cancelled_count = buying_data.cancelled_count
                order_count = buying_data.order_count
                unfulfilled_count = buying_data.unfulfilled
                match_count = cancelled_count + completed_count
                calculate_unfullfiled = order_count - active_orders
                if unfulfilled_count > 0:
                    buying_checks = True
                    if cancellation_rate != 0:
                        cancelled_percent = round(float(((cancelled_count / order_count) * 100)), 2)
                        if cancellation_rate <= cancelled_percent:
                            buying_checks = False
                            sql = "UPDATE [dbo].[buyingitems] SET [working_status] =?, [Date_modify]=? WHERE [cart_id]=?"
                            val = ("Failed", datetime.datetime.now(), cart_id)
                            cursor.execute(sql, val)
                            cursor.commit()
                            sql = "UPDATE [dbo].[buyingmaster] SET [status] =?, [Date_extention]=?, [Date_modify]=? WHERE [cart_id]=?"
                            val = ('Cancelled', datetime.datetime.now(), datetime.datetime.now(), cart_id)
                            cursor.execute(sql, val)
                            cursor.commit()
                            message.append(
                                "You have out of cancelled order due to set cancellation rate - {0}% and your current cancelled rate is {1}%".format(
                                    cancellation_rate, cancelled_percent))
                    if int(cancellation) > 0:
                        if cancellation <= cancelled_count:
                            buying_checks = False
                            sql = "UPDATE [dbo].[buyingitems] SET [working_status] =?, [Date_modify]=? WHERE [cart_id]=?"
                            val = ("Failed", datetime.datetime.now(), cart_id)
                            cursor.execute(sql, val)
                            cursor.commit()
                            sql = "UPDATE [dbo].[buyingmaster] SET [status] =?, [Date_extention]=?, [Date_modify]=? WHERE [cart_id]=?"
                            val = ('Cancelled', datetime.datetime.now(), datetime.datetime.now(), cart_id)
                            cursor.execute(sql, val)
                            cursor.commit()
                            message.append(
                                "You have out of cancelled order due to set cancellation - {0} and your current cancelled order is {1}".format(
                                    cancellation, cancelled_count))

                    if buying_checks:
                        completed_count += 1
                        cancelled_count += 1
                        if completed_count <= cart_count and status == "Finished":
                            sql = "UPDATE [dbo].[buyingmaster] SET [completed_count] = ?, [unfulfilled] = ?, [Date_extention]=?, Date_modify=? WHERE [dbo].[buyingmaster].cart_id=?"
                            val = [order_completed_count, calculate_unfullfiled, datetime.datetime.now(), datetime.datetime.now(),
                                   cart_id]
                            cursor.execute(sql, val)
                            # committing data on the database
                            cursor.commit()
                            message.append(
                                "Your buying items - completed count updated.")
                        elif cancelled_count <= cart_count and status == "Failed":
                            sql = "UPDATE [dbo].[buyingmaster] SET [cancelled_count] = ?, [unfulfilled] = ?, [Date_extention]=?, Date_modify=? WHERE [dbo].[buyingmaster].cart_id=?"
                            val = [order_cancelled_count, calculate_unfullfiled, datetime.datetime.now(), datetime.datetime.now(), cart_id]
                            cursor.execute(sql, val)
                            # committing data on the database
                            cursor.commit()
                            message.append(
                                "Your buying items - cancelled count updated.")
                        else:
                            message.append(
                                "Please make sure your buying completed or cancelled count should not be more than orders, loop count and cart_cout. Please use 'Failed or Finished' status.")
                else:
                    message.append(
                        "Please make sure your unfulfilled count is zero, If correct then process for loop count finished.")
            else:
                return jsonify({"code": 404, "error": "Please use valid cart id."})
            sql = "SELECT TOP (1) buyingitems.cart_id, order_count, completed_count, unfulfilled, cancelled_count, cart_loop, loop_ount, working_status, loop_status FROM [dbo].[buyingmaster] INNER JOIN [dbo].[buyingitems] ON [buyingmaster].[cart_id]=[buyingitems].[cart_id] WHERE buyingitems.cart_id=?"
            val = (cart_id)
            cursor.execute(sql, val)
            cart_status = cursor.fetchone()
            if cart_status:
                data = {}
                data['cart_id'] = cart_status.cart_id
                data['completedcount'] = cart_status.completed_count
                data['unfulfilled'] = cart_status.unfulfilled
                data['cancelledcount'] = cart_status.cancelled_count
                data['cart_loop'] = cart_status.cart_loop
                data['loop_count'] = cart_status.loop_ount
                data['working_status'] = cart_status.working_status
                data['order_count'] = cart_status.order_count
                data['loop_status'] = cart_status.loop_status
            messages = (" ").join(message)
            return jsonify({'message': messages, 'code': 200, 'data': data})
        elif work == 'resetloopstatus':
            status = str(work_status).title()
            data = {}
            if status == 'Initial':
                sql = "UPDATE [dbo].[buyingitems] SET  loop_status= ?, loop_ount= ?, working_status=?, Date_modify=? WHERE [cart_id]=?"
                val = (status, 0, 'Active', None, cart_id)
                cursor.execute(sql, val)
                cursor.commit()
                sql = "UPDATE [dbo].[buyingmaster] SET [status] =?, completed_count=?, cancelled_count=?, final_cost= ?, unit_ordered= ?, unit_cancelled= ?, reason=?, Date_extention=?, Date_modify=?, unfulfilled=order_count WHERE [cart_id]=?"
                val = ('Active', 0, 0, 0, 0, 0, None, None, None, cart_id)
                cursor.execute(sql, val)
                cursor.commit()
                sql = "UPDATE [dbo].[phonenumber] SET [phone_used] =?, [is_using]=? WHERE [cart_id]=?"
                val = (0, 0, cart_id)
                cursor.execute(sql, val)
                cursor.commit()
                sql = "UPDATE [dbo].[addressmaster] SET [address_used] =?, [is_using]=? WHERE [cart_id]=?"
                val = (0, 0, cart_id)
                cursor.execute(sql, val)
                cursor.commit()
                sql = "UPDATE [dbo].[emailmaster] SET [email_used] =?, [is_using]=? WHERE [cart_id]=?"
                val = (0, 0, cart_id)
                cursor.execute(sql, val)
                cursor.commit()
                sql = "SELECT [order_number] FROM [dbo].[ordertracking] WHERE [cart_id]=?"
                cursor.execute(sql, cart_id)
                order_data = cursor.fetchall()
                if len(order_data) != 0:
                    for order in order_data:
                        order_number = order.order_number
                        sql = "DELETE FROM [dbo].[giftcardtransaction] WHERE ordernumber=?"
                        cursor.execute(sql, order_number)
                        cursor.commit()
                    sql = "DELETE FROM  [dbo].[ordertracking] WHERE [cart_id]=?"
                    cursor.execute(sql, cart_id)
                    cursor.commit()
                sql = "SELECT TOP (1) buyingitems.cart_id, completed_count, unfulfilled, cancelled_count, cart_loop, loop_ount, working_status, loop_status FROM [dbo].[buyingmaster] INNER JOIN [dbo].[buyingitems] ON [buyingmaster].[cart_id]=[buyingitems].[cart_id] WHERE buyingitems.cart_id=?"
                val = (cart_id)
                cursor.execute(sql, val)
                cart_status = cursor.fetchone()
                if cart_status:
                    data['cart_id'] = cart_status.cart_id
                    data['completedcount'] = cart_status.completed_count
                    data['unfulfilled'] = cart_status.unfulfilled
                    data['cancelledcount'] = cart_status.cancelled_count
                    data['cart_loop'] = cart_status.cart_loop
                    data['loop_count'] = cart_status.loop_ount
                    data['working_status'] = cart_status.working_status
                    data['loop_status'] = cart_status.loop_status
                return jsonify({'message': 'You have reset your buying items successfully.', 'code': 200, 'data': data})
            else:
                return jsonify(
                    {'message': 'Please use valid loop status - Initial', 'code': 404})
        elif work == "updatebuyingdetailbyid":
            try:
                unit_cancel, unit_order, projected_cost, final_cost = None, None, None, None
                date_time = datetime.datetime.now()
                message = []
                messages = None
                if "unitcancel" in data:
                    unit_cancel = data['unitcancel']
                if "unitorder" in data:
                    unit_order = data['unitorder']
                if "projectedcost" in data:
                    projected_cost = data['projectedcost']
                if "finalcost" in data:
                    final_cost = data['finalcost']
                if "id" in data:
                    id = data['id']
                else:
                    return jsonify({'message': "'id' must be required for the operation", 'code': 404})
                if final_cost != None:
                    sql = "UPDATE [dbo].[buyingmaster] SET final_cost= ?, Date_modify=? WHERE id = ?"
                    val = (final_cost, date_time, id)
                    cursor.execute(sql, val)
                    cursor.commit()
                    message.append("final cost updated")
                if projected_cost != None:
                    sql = "UPDATE [dbo].[buyingmaster] SET projected_cost= ?, Date_modify=? WHERE id = ?"
                    val = (projected_cost, date_time, id)
                    cursor.execute(sql, val)
                    cursor.commit()
                    message.append("projected cost updated")
                if unit_order != None:
                    sql = "UPDATE [dbo].[buyingmaster] SET unit_ordered= ?, Date_modify=? WHERE id = ?"
                    val = (unit_order, date_time, id)
                    cursor.execute(sql, val)
                    cursor.commit()
                    message.append("unit order updated")
                if unit_cancel != None:
                    sql = "UPDATE [dbo].[buyingmaster] SET unit_cancelled= ?, Date_modify=? WHERE id = ?"
                    val = (unit_cancel, date_time, id)
                    cursor.execute(sql, val)
                    cursor.commit()
                    message.append("unit cancel updated")
                sql = "SELECT cart_id,final_cost,projected_cost,unit_ordered,unit_cancelled FROM [dbo].[buyingmaster] WHERE id = ?"
                val = (id)
                cursor.execute(sql, val)
                data_list = cursor.fetchone()
                data = {}
                if data_list != None:
                    data['id'] = id
                    data['cart_id'] = data_list.cart_id
                    data['finalcost'] = data_list.final_cost
                    data['projectedcost'] = data_list.projected_cost
                    data['unitorder'] = data_list.unit_ordered
                    data['unitcancel'] = data_list.unit_cancelled
                    messages = (",").join(message)
                    return jsonify({'message': messages, 'code': 200, 'data': data})
                else:
                    return jsonify({'message': "Please use valid 'id' or fields for the operation", 'code': 404})
            except Exception as e:
                return jsonify({'message': str(e), 'code': 404})
        elif work == "updatebuyingfailure":
            try:
                # list_status = ['Stock Out', 'Price Change', 'Cancellations']
                reason, completed_count, unfulfilled, cancelled_count = None, None, None, None
                date_time = datetime.datetime.now()
                message = []
                messages = None
                if "reason" in data:
                    reason = data['reason']
                if "completedcount" in data:
                    completed_count = data['completedcount']
                if "unfulfilled" in data:
                    unfulfilled = data['unfulfilled']
                if "cancelledcount" in data:
                    cancelled_count = data['cancelledcount']
                if reason != None:
                    sql = "UPDATE [dbo].[buyingmaster] SET reason = ?, Date_modify=? WHERE [cart_id]=?"
                    val = (reason, date_time, cart_id)
                    cursor.execute(sql, val)
                    cursor.commit()
                    message.append("Reason Updated")
                if completed_count != None:
                    sql = "UPDATE [dbo].[buyingmaster] SET completed_count = ?, Date_modify=? WHERE [cart_id]=?"
                    val = (completed_count, date_time, cart_id)
                    cursor.execute(sql, val)
                    cursor.commit()
                    message.append("Completed Count Updated")
                if unfulfilled != None:
                    sql = "UPDATE [dbo].[buyingmaster] SET unfulfilled = ?, Date_modify=? WHERE [cart_id]=?"
                    val = (unfulfilled, date_time, cart_id)
                    cursor.execute(sql, val)
                    cursor.commit()
                    message.append("Unfulfilled Updated")
                if cancelled_count != None:
                    sql = "UPDATE [dbo].[buyingmaster] SET cancelled_count = ?, Date_modify=? WHERE [cart_id]=?"
                    val = (cancelled_count, date_time, cart_id)
                    cursor.execute(sql, val)
                    cursor.commit()
                    message.append("Cencellation Count Updated")
                sql = "SELECT cart_id,reason,completed_count,unfulfilled,cancelled_count FROM [dbo].[buyingmaster] WHERE cart_id = ?"
                val = (cart_id)
                cursor.execute(sql, val)
                data_list = cursor.fetchone()
                data = {}
                if data_list != None:
                    data['cart_id'] = cart_id
                    data['reason'] = data_list.reason
                    data['completedcount'] = data_list.completed_count
                    data['unfulfilled'] = data_list.unfulfilled
                    data['cancelledcount'] = data_list.cancelled_count
                    messages = (",").join(message)
                    return jsonify({'message': messages, 'code': 200, 'data': data})
                else:
                    return jsonify({'message': "Please use valid 'cart_id' or fields for the operation", 'code': 404})
            except Exception as e:
                return jsonify({'message': str(e), 'code': 404})
        else:
            return jsonify({'message': 'Invalid operation for work', 'code': 404})


class BuyingDetail(Resource):
    @app.route('/buyingninformation/<int:type>')
    def get(type):
        cursor = condb.cursor()
        jsondata = {}
        if type != 0:
            cart_id = int(type)
            sql = "SELECT [id], [item_sku], [price], [qty_percart], [unit_total], [shipping], [tax], [subtotal], [total_cost], [payment_type], [cart_id], [company_id], unfulfilled, order_count FROM [dbo].[buyingmaster] WHERE cart_id = {0} AND status = 'Active' ORDER BY priority ASC, buyingmaster.Date_creation DESC".format(
                cart_id)
            cursor.execute(sql)
            datalist = cursor.fetchall()
            sql = "SELECT [loop_status],[cart_loop],[loop_ount],[address_ids],[email_ids],[cart_id] FROM [dbo].[buyingitems] WHERE cart_id = {0} AND buyingitems.working_status = 'Active'".format(
                cart_id)
            cursor.execute(sql)
            items_loop = cursor.fetchall()
            for item in items_loop:
                if cart_id == item.cart_id:
                    address_ids = item.address_ids.split(",")
                    email_ids = item.email_ids.split(",")

                    jsondata['cart_loop'] = item.cart_loop
                    jsondata['loop_status'] = item.loop_status
                    jsondata['address_family'] = address_ids
                    jsondata['email_family'] = email_ids
                    jsondata['loop_count'] = item.loop_ount
                    jsondata['cart_id'] = cart_id

            item_list = []
            for data in datalist:
                jsdata = {}
                if cart_id == data.cart_id:
                    jsdata['id'] = data.id
                    jsdata['item_sku'] = data.item_sku
                    jsdata['price'] = data.price
                    jsdata['qty_percart'] = data.qty_percart
                    jsdata['unit_total'] = data.unit_total
                    jsdata['shipping'] = data.shipping
                    jsdata['tax'] = data.tax
                    jsdata['subtotal'] = data.subtotal
                    jsdata['total_cost'] = data.total_cost
                    jsdata['payment_type'] = data.payment_type
                    jsdata['cart_id'] = cart_id
                    jsondata['order_count'] = data.order_count
                    jsondata['unfulfilled'] = data.unfulfilled
                    item_list.append(jsdata)

            if len(item_list) != 0:
                jsondata['items'] = item_list
                return jsonify({'message': 'successfully', "code": 200, "buyingdatalist": jsondata})
            else:
                return jsonify({'message': 'Please use valid cart id.', "code": 404})
        else:
            return jsonify({'message': 'Invailid url', "code": 404})


class SendGiftCardDetails(Resource):
    def post(self):
        data = request.get_json()
        method = data["method"]
        cursor = condb.cursor()
        if method == "getgiftcard":
            non_cancelled_days = 1
            sql = "SELECT non_cancelled_order FROM [dbo].[settings]"
            cursor.execute(sql)
            table_Data = cursor.fetchone()
            if table_Data:
                non_cancelled_days = table_Data.non_cancelled_order
            amount = data['amount']
            retailer = None
            if 'retailer' in data:
                retailer = data['retailer']
            card_range = None
            if 'card_above' in data:
                card_range = data['card_above']

            GiftCradlist = []
            all_email = []
            default_address_list = []
            affiliate_email = []
            # cursor = condb.cursor()

            sql = "SELECT top 1 id,gift_card_no,balance,gift_card_pin,retailer,status FROM [dbo].[giftcardlist] where balance <= ? and (last_used <= DATEADD(day,-"+str(non_cancelled_days)+", GETDATE()) or last_used is null) and balance > 0 and status != 'Error'  and status != 'No Balance' and status != 'Bad' and status !='Locked' and status != 'Loss' and retailer = ? order by balance ASC, last_used ASC"
            value = (float(amount), retailer)
            cursor.execute(sql, value)
            tableData = cursor.fetchall()
            usedid = ""
            print(tableData)
            if len(tableData) > 0:
                for x in tableData:
                    giftCardValue = x[2]
                    usedid = (x[0],)
                    print(usedid)
                    jsonData = {
                        'id': x[0],
                        'giftno': x[1],
                        'value': x[2],
                        'pin': x[3],
                        'retailer': x[4],
                        'status': x[5]
                    }
                    GiftCradlist.append(jsonData)
                i = 0
                while i < 3:
                    if (amount == giftCardValue):
                        return jsonify({"code": 200, "success": "true", "gift_card_list": GiftCradlist})
                    else:
                        amount = float(amount) - giftCardValue
                        cursor = condb.cursor()
                        if card_range is not None:
                            sql = "SELECT top 1 id,gift_card_no,balance,gift_card_pin,retailer,status FROM [dbo].[giftcardlist] where balance BETWEEN '" + str(
                                card_range) + "' and '" + str(
                                amount) + "' and (last_used <= DATEADD(day,-"+str(non_cancelled_days)+", GETDATE()) or last_used is null) and status != 'Error'  and status != 'No Balance' and status != 'Bad' and status !='Locked' and status != 'Loss' and  retailer = ? and balance > 0 and  id NOT IN (" + ','.join(
                                map(str, usedid)) + ") order by balance"
                        else:
                            sql = "SELECT top 1 id,gift_card_no,balance,gift_card_pin,retailer,status FROM [dbo].[giftcardlist] where balance <= '" + str(
                                amount) + "' and  (last_used <= DATEADD(day,-"+str(non_cancelled_days)+", GETDATE()) or last_used is null) and status != 'Error'  and status != 'No Balance' and status != 'Bad' and status !='Locked' and status != 'Loss' and  retailer = ? and balance > 0 and  id NOT IN (" + ','.join(
                                map(str, usedid)) + ") order by balance"
                        value = (retailer)
                        print(sql)
                        cursor.execute(sql, value)
                        tableData = cursor.fetchall()
                        if len(tableData) == 0:
                            giftCardValue = 0
                        for x in tableData:
                            giftCardValue = x[2]
                            usedid += (x[0],)
                            print(usedid)
                            jsonData = {
                                'id': x[0],
                                'giftno': x[1],
                                'value': x[2],
                                'pin': x[3],
                                'retailer': x[4],
                                'status': x[5]
                            }
                            GiftCradlist.append(jsonData)
                        i += 1

            if len(GiftCradlist) != 0:
                for x in GiftCradlist:
                    id = x.get('id')
                    if id not in usedid:
                        usedid += (id,)
                    sql = "SELECT top 1 id,gift_card_no,balance,gift_card_pin,retailer,status FROM [dbo].[giftcardlist] where " \
                          "balance >= ? and  (last_used <= DATEADD(day,-"+str(non_cancelled_days)+", GETDATE()) or last_used is null) and status != 'Error'  and status != 'No Balance' and status != 'Bad' and status !='Locked' and status != 'Loss' and retailer = ? and balance > 0 and  id NOT IN (" + ','.join(
                        map(str, usedid)) + ") order by balance ASC"
            elif len(GiftCradlist) == 0:
                sql = "SELECT top 1 id,gift_card_no,balance,gift_card_pin,retailer,status FROM [dbo].[giftcardlist] where " \
                      "balance >= ? and  (last_used <= DATEADD(day,-"+str(non_cancelled_days)+", GETDATE()) or last_used is null) and status != 'Error'  and status != 'No Balance' and status != 'Bad' and status !='Locked' and status != 'Loss' and retailer = ? and balance > 0 order by balance ASC"

            value = (amount, retailer)
            cursor.execute(sql, value)
            tableData = cursor.fetchall()
            print(tableData)
            if len(tableData) == 0 and amount != 0 and usedid != "":
                sql = "SELECT top 1 id,gift_card_no,balance,gift_card_pin,retailer,status FROM [dbo].[giftcardlist] where " \
                      "balance <= ? and  (last_used <= DATEADD(day,-"+str(non_cancelled_days)+", GETDATE()) or last_used is null) and status != 'Error'  and status != 'No Balance' and status != 'Bad' and status !='Locked' and status != 'Loss' and retailer = ? and balance > 0 and  id NOT IN (" + ','.join(
                    map(str, usedid)) + ") order by balance DESC"
                value = (amount, retailer)
                cursor.execute(sql, value)
                tableData = cursor.fetchall()
            for x in tableData:
                jsonData = {
                    'id': x[0],
                    'giftno': x[1],
                    'value': x[2],
                    'pin': x[3],
                    'retailer': x[4],
                    'status': x[5]
                }
                GiftCradlist.append(jsonData)
            return jsonify({"code": 200, "success": "true", "gift_card_list": GiftCradlist})
        elif method == "giftcardused":
            try:
                id = data["giftno"]
                date_time = datetime.datetime.now()
                check_used, check_status, check_vendor = False, False, False
                if "used" in data:
                    if data["used"] == True:
                        sql = "UPDATE [dbo].[giftcardlist] SET [last_used]=?, [check_balance_status] = ?, [Date_modify]=? WHERE [gift_card_no]=?"
                        val = (date_time, None, date_time, id)
                        cursor.execute(sql, val)
                        cursor.commit()
                        check_used = True
                if "status" in data:
                    if data['status']:
                        status = data["status"]
                        sql = "UPDATE [dbo].[giftcardlist] SET [status]=?, [Date_modify]=? WHERE [gift_card_no]=?"
                        val = (status, date_time, id)
                        cursor.execute(sql, val)
                        cursor.commit()
                        check_status = True
                if "vendor" in data:
                    if data['vendor']:
                        vendor = data['vendor']
                        sql = "UPDATE [dbo].[giftcardlist] SET [vendor] =?, [Date_modify]=? WHERE [gift_card_no]=?"
                        val = (vendor, date_time, id)
                        cursor.execute(sql, val)
                        cursor.commit()
                        check_vendor = True
                sql = "SELECT id, gift_card_no, balance, gift_card_value, status, vendor, retailer, check_balance_status, CONVERT (varchar(10), last_used ,110) 'last_used' FROM [dbo].[giftcardlist] WHERE gift_card_no = ?"
                val = (id)
                cursor.execute(sql, val)
                tabledata = cursor.fetchall()
                json_data = {}
                for data in tabledata:
                    json_data['id'] = data.id
                    json_data['giftno'] = data.gift_card_no
                    json_data["balance"] = data.balance
                    json_data["value"] = data.gift_card_value
                    json_data['status'] = data.status
                    json_data['vendor'] = data.vendor
                    json_data['retailer'] = data.retailer
                    json_data['last_used'] = data.last_used
                    check_balance_status = None
                    if data.check_balance_status == 'checked':
                        check_balance_status = 'Balance Checked'
                    else:
                        check_balance_status = 'Balance Not Checked'
                    json_data['last_check_status'] = check_balance_status

                message_list = []
                if check_used:
                    message_list.append("last used updated")
                if check_status:
                    message_list.append("status updated")
                if check_vendor:
                    message_list.append("vendor updated")
                messages = (",").join(message_list)
                return jsonify({"code": 200, "message": messages, "gift_card_detail": json_data})
            except Exception as e:
                return jsonify({"code": 404, "message": str(e), "gift_card_detail": {}})

class ExtraGiftCards(Resource):
    def post(self):
        data = request.get_json()
        cursor = condb.cursor()
        GiftCradlist = []
        usedid = ()
        amount = 0
        more_card = 0
        non_cancelled_days = 1
        sql = "SELECT non_cancelled_order FROM [dbo].[settings]"
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        if table_Data:
            non_cancelled_days = table_Data.non_cancelled_order
        if 'usedid' in data:
            usedid = tuple(data['usedid'])
        if 'more_card' in data:
            more_card = data['more_card']
        if 'amount' in data:
            amount = data['amount']
        sql = "SELECT id, gift_card_no,balance,gift_card_pin,retailer,status FROM [dbo].[giftcardlist] where " \
              "balance <= ? and  (last_used <= DATEADD(day,-"+str(non_cancelled_days)+", GETDATE()) or last_used is null) and status != 'Error'  and status != 'No Balance' and status != 'Bad' and status !='Locked' and status != 'Loss' and retailer = ? and balance > 0 and  id NOT IN (" + ','.join(
            map(str, usedid)) + ") order by balance ASC"
        value = (amount, 'Best Buy')
        cursor.execute(sql, value)
        tableData = cursor.fetchall()

        gc_amount = amount
        for x in tableData:
            if x.balance:
                if len(GiftCradlist) < more_card:
                    balance = x.balance
                    gc_amount = gc_amount - balance
                    if gc_amount > 0:
                        jsonData = {
                            'id': x[0],
                            'giftno': x[1],
                            'value': x[2],
                            'pin': x[3],
                            'retailer': x[4],
                            'status': x[5]
                        }
                        GiftCradlist.append(jsonData)
                    else:
                        jsonData = {
                            'id': x[0],
                            'giftno': x[1],
                            'value': x[2],
                            'pin': x[3],
                            'retailer': x[4],
                            'status': x[5]
                        }
                        GiftCradlist.append(jsonData)
                        break
        if len(GiftCradlist) == 0 or gc_amount > 0:
            if gc_amount > 0:
                if len(GiftCradlist) != 0:
                    gc_amount = gc_amount + GiftCradlist[0]['value']
                    del(GiftCradlist[0])
            sql = "SELECT id, gift_card_no,balance,gift_card_pin,retailer,status FROM [dbo].[giftcardlist] where " \
                  "balance >= ? and  (last_used <= DATEADD(day,-"+str(non_cancelled_days)+", GETDATE()) or last_used is null) and status != 'Error' and status != 'No Balance' and status != 'Bad' and status !='Locked' and status != 'Loss' and retailer = ? and balance > 0 and  id NOT IN (" + ','.join(
                map(str, usedid)) + ") order by balance DESC"
            value = (amount, 'Best Buy')
            cursor.execute(sql, value)
            tableData = cursor.fetchall()
            for x in tableData:
                if x.balance:
                    balance = x.balance
                    gc_amount = gc_amount - balance
                    if gc_amount > 0:
                        jsonData = {
                            'id': x[0],
                            'giftno': x[1],
                            'value': x[2],
                            'pin': x[3],
                            'retailer': x[4],
                            'status': x[5]
                        }
                        GiftCradlist.append(jsonData)
                    else:
                        jsonData = {
                            'id': x[0],
                            'giftno': x[1],
                            'value': x[2],
                            'pin': x[3],
                            'retailer': x[4],
                            'status': x[5]
                        }
                        GiftCradlist.append(jsonData)
                        break
        return jsonify({"code": 200, "success": "true", "gift_card_list": GiftCradlist})

# Buying api for insering records on fullfilled & total cost column
class BuyingCostFullfilled(Resource):
    def post(self):
        if request.method == "POST":
            try:
                json_cart_id = None
                INSERT_OPERATION = None
                # initializing cursor
                cursor = condb.cursor()
                # getting json data
                order_parser = request.get_json()
                json_order_id = order_parser['order_id']
                if json_order_id:
                    json_order_id = json_order_id.replace(" ", "")
                json_date_of_purchase = order_parser['date_of_purchase']
                json_date_of_purchase_only = None
                if json_date_of_purchase:
                    json_date_of_purchase = pd.to_datetime(json_date_of_purchase)
                    json_date_of_purchase_only = json_date_of_purchase.date()
                    json_time_check = json_date_of_purchase.time()
                    if '00:00:00' == str(json_time_check):
                        current_time = pd.to_datetime('now').time()
                        json_date_of_purchase = pd.to_datetime(
                            str(json_date_of_purchase_only) + ' ' + str(current_time))
                    # json_date_of_purchase = pd.to_datetime(json_date_of_purchase_only)

                # the orderid & cost should not be null
                if json_order_id != None and len(json_order_id) != 0 and str(json_order_id).lower() != 'null' and str(
                        json_order_id).lower() != 'undefine':
                    json_user_id, json_tax, json_cost, json_subtotal, json_ship_cost = 1, 0, 0, 0, 0
                    json_no_of_gc, json_no_of_item = 0, 0
                    json_order_status, json_vendor, json_retailer, json_payment_type = None, None, None, None
                    json_career, json_tracking_number = None, None
                    json_cart_id, json_address_id, json_email_id, json_phone_number = None, None, None, None
                    status_list = ['Ordered', 'Processed', 'Cancelled', 'Shipped', 'Delivered', 'Received']

                    if 'cost' in order_parser:
                        json_cost = order_parser['cost']
                        try:
                            if json_cost:
                                json_cost = float(json_cost)
                            elif json_cost == None:
                                json_cost = 0
                        except Exception as e:
                            json_cost = 0
                            print(e)
                            pass
                    if 'status' in order_parser:
                        json_order_status = order_parser['status']
                        if json_order_status:
                            json_order_status = json_order_status.strip()
                            json_order_status = json_order_status.title()
                        if json_order_status not in status_list:
                            return jsonify({"code": 400,
                                            "error": "Status is not matched. Please use like - 'Ordered','Processed','Cancelled','Shipped','Delivered','Received'"})
                    if 'vendor' in order_parser:
                        json_vendor = order_parser['vendor']
                        if json_vendor:
                            json_vendor = json_vendor.strip()
                    if 'fullname' in order_parser:
                        json_fullname = order_parser['fullname']
                        if json_fullname:
                            json_fullname = json_fullname.strip()
                    if 'retailer' in order_parser:
                        json_retailer = order_parser['retailer']
                        if json_retailer:
                            json_retailer = json_retailer.strip()
                    if 'tax' in order_parser:
                        json_tax = order_parser['tax']
                        try:
                            if json_tax:
                                json_tax = float(json_tax)
                            elif json_tax == None:
                                json_tax = 0
                        except Exception as e:
                            json_tax = 0
                            print(e)
                            pass
                    if 'subtotal' in order_parser:
                        json_subtotal = order_parser['subtotal']
                        try:
                            if json_subtotal:
                                json_subtotal = float(json_subtotal)
                            elif json_subtotal == None:
                                json_subtotal = 0
                        except Exception as e:
                            json_subtotal = 0
                            print(e)
                            pass
                    if 'gc_nos' in order_parser:
                        json_no_of_gc = order_parser['gc_nos']
                        if json_no_of_gc == None:
                            json_no_of_gc = 0
                    if 'item_nos' in order_parser:
                        json_no_of_item = order_parser['item_nos']
                        if json_no_of_item == None:
                            json_no_of_item = 0
                    if 'user_id' in order_parser:
                        json_user_id = order_parser['user_id']
                        if json_user_id == None:
                            json_user_id = 1
                    if 'cart_id' in order_parser:
                        json_cart_id = order_parser['cart_id']
                        sql = "UPDATE [dbo].[buyingmaster] SET Date_extention=? WHERE cart_id=?"
                        val = (datetime.datetime.now(),json_cart_id)
                        cursor.execute(sql, val)
                        cursor.commit()
                        sql = "SELECT count(DISTINCT order_number) as order_number, loop_ount, cart_loop FROM [dbo].[ordertracking] INNER JOIN [dbo].[buyingitems] ON [ordertracking].[cart_id]=[buyingitems].[cart_id] WHERE buyingitems.cart_id=? GROUP BY loop_ount, cart_loop"
                        val = (json_cart_id)
                        cursor.execute(sql, val)
                        order_status = cursor.fetchone()
                        if order_status != None:
                            order_count = order_status.order_number
                            loop_count = order_status.loop_ount
                            cart_loop = order_status.cart_loop
                            if cart_loop == loop_count:
                                if cart_loop == order_count:
                                    if 'update_order' in order_parser:
                                        if order_parser['update_order'] == True:
                                            sql = "SELECT order_number FROM [dbo].[ordertracking] WHERE order_number = ? and cart_id = ?"
                                            val = (json_order_id, json_cart_id)
                                            cursor.execute(sql, val)
                                            order_presence = cursor.fetchall()
                                            if len(order_presence) != 0:
                                                pass
                                            else:
                                                return jsonify({"code": 404,
                                                                "error": "Your order number or associate card_id are not matched for update operation. please use correct values."})
                                        else:
                                            return jsonify({"code": 404,
                                                            "error": "You have not inserted or updated new orders due to fulfilled buying conditions, please 'update_order : true' and use existence order id for update records."})
                                    else:
                                        return jsonify({"code": 404,
                                                        "error": "You have not inserted new orders due to fulfilled buying conditions, please 'update_order : true' and use existence order id for update records."})
                                else:
                                    pass
                            else:
                                pass
                        else:
                            pass
                    if 'address_id' in order_parser:
                        json_address_id = order_parser['address_id']
                        if json_address_id:
                            sql = "UPDATE [dbo].[addressmaster] SET is_using = 1, no_of_order=1 WHERE id = ?"
                            cursor.execute(sql, json_address_id)
                            cursor.commit()
                    if 'email_id' in order_parser:
                        json_email_id = order_parser['email_id']
                        if json_email_id:
                            sql = "UPDATE [dbo].[emailmaster] SET is_using = 1, no_of_order=1 WHERE id = ?"
                            cursor.execute(sql, json_email_id)
                            cursor.commit()
                    if 'mobile' in order_parser:
                        json_phone_number = order_parser['mobile']
                        if json_phone_number:
                            sql = "UPDATE [dbo].[phonenumber] SET is_using = 1 WHERE phone = ?"
                            cursor.execute(sql, json_phone_number)
                            cursor.commit()
                    if 'payment_type' in order_parser:
                        json_payment_type = order_parser['payment_type']
                        if json_payment_type:
                            json_payment_type = json_payment_type.strip()
                    if 'ship_cost' in order_parser:
                        json_ship_cost = order_parser['ship_cost']
                        try:
                            if json_ship_cost:
                                json_ship_cost = float(json_ship_cost)
                            elif json_ship_cost == None:
                                json_ship_cost = 0
                        except Exception as e:
                            print(e)
                            json_ship_cost = 0
                            pass
                    sql = "SELECT [id], [companyid] FROM [dbo].[usermaster] WHERE [dbo].[usermaster].id=?"
                    cursor.execute(sql, json_user_id)
                    userid = cursor.fetchall()
                    # Checking registered user id exist or not
                    if len(userid) != 0:
                        user_id = userid[0][0]
                        company_id = userid[0][1]
                        for product in order_parser['product_items']:
                            title, sku, tracking_status = None, None, None
                            qty, product_price = 0, 0
                            if 'title' in product:
                                title = product['title']
                                if title:
                                    title = title.strip()
                            if 'sku' in product:
                                sku = product['sku']
                                if sku:
                                    sku = sku.replace(" ", "")
                            if 'qty' in product:
                                qty = product['qty']
                                try:
                                    if qty:
                                        qty = int(qty)
                                    elif qty == None:
                                        qty = 0
                                except Exception as e:
                                    print(e)
                                    qty = 0
                                    pass
                            if 'product_price' in product:
                                product_price = product['product_price']
                                try:
                                    if product_price:
                                        product_price = float(product_price)
                                    elif product_price == None:
                                        product_price = 0
                                except Exception as e:
                                    print(e)
                                    product_price = 0
                                    pass
                            if 'tracking_status' in product:
                                tracking_status = product["tracking_status"]
                                if tracking_status:
                                    tracking_status = tracking_status.replace(" ", "")
                                    tracking_status = tracking_status.title()
                                if tracking_status not in status_list:
                                    return jsonify({"code": 404,
                                                    "error": "Tracking Status is not matched. Please use like - 'Ordered','Processed','Cancelled','Shipped','Delivered','Received'"})
                            if 'tracking_number' in product:
                                json_tracking_number = product['tracking_number']
                                if json_tracking_number:
                                    json_tracking_number = str(json_tracking_number).replace(" ", "")
                            if 'career' in product:
                                json_career = product['career']
                                if json_career:
                                    json_career = json_career.strip()
                            if len(json_order_id) != 0 and (tracking_status != None):
                                # Insert records on order tracking table when qty, product_price, Cost will not be there on particular orderno

                                sql = "select id, item_sku, price, orderedDate from [dbo].[ordertracking] where order_number=?"
                                val = [json_order_id]
                                cursor.execute(sql, val)
                                data_exists = cursor.fetchall()
                                existance_id = None
                                for data in data_exists:
                                    if data.item_sku is not None and sku is not None:
                                        if json_date_of_purchase_only is not None:
                                            if str(product_price) == str(data.price) and str(sku) == str(
                                                    data.item_sku) and str(json_date_of_purchase_only) in str(
                                                data.orderedDate):
                                                existance_id = data.id
                                            elif str(sku) == str(data.item_sku):
                                                existance_id = data.id
                                                # json_date_of_purchase = data.orderedDate
                                        elif str(product_price) == str(data.price) and str(sku) == str(data.item_sku):
                                            existance_id = data.id
                                            # json_date_of_purchase = data.orderedDate
                                        elif str(sku) == str(data.item_sku):
                                            existance_id = data.id
                                    else:
                                        if json_date_of_purchase_only is not None:
                                            if str(product_price) == str(data.price) and str(
                                                    json_date_of_purchase_only) in str(data.orderedDate):
                                                existance_id = data.id
                                                # json_date_of_purchase = data.orderedDate
                                        elif str(product_price) == str(data.price):
                                            existance_id = data.id
                                            # json_date_of_purchase = data.orderedDate
                                if len(data_exists) == 0:
                                    INSERT_OPERATION = True
                                elif existance_id is None:
                                    INSERT_OPERATION = True
                                if INSERT_OPERATION:
                                    sql = "select order_number from [dbo].[ordertracking] where order_number=? AND item_sku=?"
                                    val = (json_order_id, sku)
                                    cursor.execute(sql, val)
                                    id_exists = cursor.fetchone()
                                    if id_exists == None:
                                        sql = "INSERT INTO [dbo].[ordertracking] (user_id, company_id, vendor, fullname, item_sku, qty_cart, title, tracking_status, carrier, tracking_number, price, cart_total, payment_type, retailer, order_number, tax_cost, subtotal, shipping_cost, cart_id, address_id, email_id, phone, no_of_gc, no_of_item, orderedDate, Date_creation, Date_modify) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);"
                                        val = [user_id, company_id, json_vendor, json_fullname, sku, qty, title,
                                               tracking_status, json_career, json_tracking_number,
                                               product_price, json_cost, json_payment_type, json_retailer, json_order_id,
                                               json_tax, json_subtotal, json_ship_cost,
                                               json_cart_id, json_address_id, json_email_id,
                                               json_phone_number, json_no_of_gc, json_no_of_item, json_date_of_purchase,
                                               datetime.datetime.now(), datetime.datetime.now()]
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                        sql = "If Not Exists(select order_number from [dbo].[notification] WHERE order_number=?) Begin INSERT INTO [dbo].[notification] (user_id, company_id, seen, message, order_number, status, Date_creation) VALUES(?,?,?,?,?,?,?) End"
                                        notification_message = "Order placed - '{}'".format(json_order_id)
                                        val = [json_order_id, user_id, company_id, 1, notification_message, json_order_id, 'New', datetime.datetime.now()]
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                        if cursor.rowcount < 0:
                                            sql = "UPDATE [dbo].[notification] SET seen=1, status='New', message=?, Date_creation WHERE order_number=?"
                                            val = [notification_message, datetime.datetime.now(), json_order_id]
                                            cursor.execute(sql, val)
                                            cursor.commit()
                                elif existance_id is not None:
                                    update_field = {}
                                    update_field['json_vendor'] = "vendor"
                                    update_field['json_retailer'] = "retailer"
                                    update_field['sku'] = 'item_sku'
                                    update_field['qty'] = 'qty_cart'
                                    update_field['title'] = 'title'
                                    update_field['tracking_status'] = 'tracking_status'
                                    update_field['json_payment_type'] = 'payment_type'
                                    update_field['json_cost'] = 'cart_total'
                                    update_field['json_tax'] = 'tax_cost'
                                    update_field['json_career'] = 'carrier'
                                    update_field['json_tracking_number'] = 'tracking_number'
                                    update_field['json_subtotal'] = 'subtotal'
                                    update_field['json_cart_id'] = 'cart_id'
                                    update_field['json_address_id'] = 'address_id'
                                    update_field['json_email_id'] = 'email_id'
                                    update_field['json_phone_number'] = 'phone'
                                    update_field['json_no_of_gc'] = 'no_of_gc'
                                    update_field['json_no_of_item'] = 'no_of_item'
                                    update_field['json_date_of_purchase'] = 'orderedDate'
                                    update_field['json_ship_cost'] = 'shipping_cost'
                                    update_field['json_fullname'] = 'fullname'
                                    for key, value in update_field.items():
                                        if key == 'json_vendor':
                                            if json_vendor:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE order_number=?;".format(
                                                    value)
                                                val = [json_vendor, json_order_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_retailer':
                                            if json_retailer:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE order_number=?;".format(
                                                    value)
                                                val = [json_retailer, json_order_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'sku':
                                            if sku:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE id=?;".format(
                                                    value)
                                                val = [sku, existance_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'qty':
                                            if qty != None:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE id=?;".format(
                                                    value)
                                                val = [qty, existance_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'title':
                                            if title:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE id=?;".format(
                                                    value)
                                                val = [title, existance_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'tracking_status':
                                            if tracking_status:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE id=?;".format(
                                                    value)
                                                val = [tracking_status, existance_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_payment_type':
                                            if json_payment_type:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE order_number=?;".format(
                                                    value)
                                                val = [json_payment_type, json_order_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_cost':
                                            if json_cost != None:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE order_number=?;".format(
                                                    value)
                                                val = [json_cost, json_order_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_tax':
                                            if json_tax != None:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE order_number=?;".format(
                                                    value)
                                                val = [json_tax, json_order_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_career':
                                            if json_career:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? FROM [dbo].[ordertracking] WHERE id=?;".format(
                                                    value)
                                                val = [json_career, existance_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_tracking_number':
                                            if json_tracking_number:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE id=?;".format(
                                                    value)
                                                val = [json_tracking_number, existance_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_fullname':
                                            if json_fullname != None:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE id=?;".format(
                                                    value)
                                                val = [json_fullname, existance_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_subtotal':
                                            if json_subtotal != None:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE order_number=?;".format(
                                                    value)
                                                val = [json_subtotal, json_order_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_cart_id':
                                            if json_cart_id != None:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE order_number=?;".format(
                                                    value)
                                                val = [json_cart_id, json_order_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_address_id':
                                            if json_address_id != None:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE order_number=?;".format(
                                                    value)
                                                val = [json_address_id, json_order_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_email_id':
                                            if json_email_id != None:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE order_number=?;".format(
                                                    value)
                                                val = [json_email_id, json_order_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_phone_number':
                                            if json_phone_number != None:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE order_number=?;".format(
                                                    value)
                                                val = [json_phone_number, json_order_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_no_of_gc':
                                            if json_no_of_gc != None:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE order_number=?;".format(
                                                    value)
                                                val = [json_no_of_gc, json_order_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_no_of_item':
                                            if json_no_of_item != None:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE order_number=?;".format(
                                                    value)
                                                val = [json_no_of_item, json_order_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_date_of_purchase':
                                            if json_date_of_purchase != None:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE order_number=?;".format(
                                                    value)
                                                val = [json_date_of_purchase, json_order_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()
                                        elif key == 'json_ship_cost':
                                            if json_ship_cost != None:
                                                sql = "UPDATE [dbo].[ordertracking] SET {}=? WHERE order_number=?;".format(
                                                    value)
                                                val = [json_ship_cost, json_order_id]
                                                cursor.execute(sql, val)
                                                cursor.commit()

                                    sql = "UPDATE [dbo].[ordertracking] SET [Date_modify]=? WHERE order_number=?;"
                                    val = [datetime.datetime.now(), json_order_id]
                                    cursor.execute(sql, val)
                                    cursor.commit()

                        for payment in order_parser['payment_card_list']:
                            payment_type = payment['payment_type'].strip()
                            payment_type = payment_type.replace(" ", "")
                            payment_type = str(payment_type).lower()
                            if payment_type == 'giftcard':
                                gift_card_number = payment['giftcard_no'].strip()
                                gift_card_price = payment['giftcard_price']
                                if len(
                                        gift_card_number) != 0 and gift_card_number != 'NULL' and gift_card_price != 0 and gift_card_price != 'NULL':
                                    sql = "SELECT giftcard_number, amount, order_purchase_total  FROM [dbo].[giftcardtransaction] WHERE giftcardtransaction.ordernumber = ? and action_type is null"
                                    cursor.execute(sql, json_order_id)
                                    giftcard_count = cursor.fetchall()
                                    if len(giftcard_count) <= 5:
                                        sql = "SELECT id, ordernumber, giftcard_number FROM [dbo].[giftcardtransaction] WHERE ordernumber = ? AND giftcard_number = ? AND action_type is null"
                                        cursor.execute(sql, json_order_id, gift_card_number)
                                        giftcard_data = cursor.fetchall()
                                        sql = "SELECT balance, amount_paid, status, gift_card_value FROM [dbo].[giftcardlist] WHERE gift_card_no = ?"
                                        cursor.execute(sql, gift_card_number)
                                        gc_data = cursor.fetchone()
                                        if len(giftcard_data) == 0:
                                            gc_value, gc_balance, amount_paid, gifcard_value = 0, 0, 0, 0
                                            gc_status = None
                                            if gc_data:
                                                gc_value = gc_data.gift_card_value
                                                amount_paid = gc_data.amount_paid
                                                gc_status = gc_data.status
                                                gc_balance = gc_data.balance

                                            sql = "SELECT giftcard_number, sum(amount) FROM [dbo].[giftcardtransaction] where giftcard_number =? and action_type is null group by giftcard_number"
                                            cursor.execute(sql, gift_card_number)
                                            data = cursor.fetchall()
                                            if len(data) != 0:
                                                # last transaction amount & json balance will not be same
                                                amount = data[0][1]
                                                gifcard_value = gc_value - amount
                                                gifcard_value = round(gifcard_value, 2)
                                            else:
                                                gifcard_value = round(float(gc_value), 2)

                                            sql = "INSERT INTO [dbo].[giftcardtransaction] (user_id, company_id, ordernumber, giftcard_number, cost, gift_card_value, gc_balance, amount, order_purchase_total, order_purchase_status, order_purchase_date, check_balance, Date_creation) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)"
                                            val = [user_id, company_id, json_order_id, gift_card_number,
                                                   amount_paid, gc_value, gc_balance, gift_card_price, json_cost, json_order_status, json_date_of_purchase,
                                                   1, datetime.datetime.now()]
                                            cursor.execute(sql, val)
                                            cursor.commit()
                                        else:
                                            amount_paid = 0
                                            if gc_data:
                                                amount_paid = gc_data.amount_paid
                                            sql = "UPDATE [dbo].[giftcardtransaction] SET [cost]=?, [amount] = ?, [order_purchase_total] = ?, [order_purchase_status] = ?, check_balance=?, [Date_modify] = ? WHERE  giftcardtransaction.id = ?"
                                            val = [amount_paid, gift_card_price, json_cost, json_order_status, 1,
                                                   datetime.datetime.now(), giftcard_data[0][0]]
                                            cursor.execute(sql, val)
                                            cursor.commit()
                else:
                    return jsonify({"code": 404, "error": "Order number must be required."})
                return jsonify({"code": 201, "success": "true"})
            except Exception as e:
                print(e)
                return jsonify({"code": 404, "error": str(e)})

class UpdateGiftCardTrasactionEvent(Resource):
    def get(self):
        cursor = condb.cursor()
        sql = "SELECT id, amount, ordernumber, giftcard_number, giftcard_status, action_type, gc_balance FROM [dbo].[giftcardtransaction] WHERE check_balance=1"
        cursor.execute(sql)
        transaction_data = cursor.fetchall()
        trasaction = []
        for data in transaction_data:
            gift_card_number = data.giftcard_number
            sql = "SELECT gift_card_pin, balance, gift_card_value, amount_paid FROM [dbo].[giftcardlist] WHERE gift_card_no=?"
            cursor.execute(sql,gift_card_number)
            gc_data = cursor.fetchone()
            result = {
                'id': data.id,
                'order_no': data.ordernumber,
                'giftcard_no': gift_card_number,
                'giftcard_pin': gc_data.gift_card_pin,
                'giftcard_value': gc_data.gift_card_value,
                'giftcard_cost': gc_data.amount_paid,
                'balance': data.amount,
                'giftcard_status': data.giftcard_status,
                'giftcard_action': data.action_type
            }
            if data.action_type is None:
                result['gc_balance_old'] = data.gc_balance
                result['order_current_balance']= round((float(data.gc_balance) - float(data.amount)),2)
            else:
                sql = "SELECT gc_balance FROM [dbo].[giftcardtransaction] WHERE ordernumber=? and giftcard_number=? and action_type is null"
                value = (data.ordernumber, gift_card_number)
                cursor.execute(sql, value)
                get_balance = cursor.fetchone()
                if get_balance is not None:
                    result['gc_balance_old'] = get_balance.gc_balance
                    result['order_current_balance']= round((float(get_balance.gc_balance) - float(data.amount)),2)
            trasaction.append(result)
        return jsonify({"code": 200, "data": trasaction})

    def post(self):
        cursor = condb.cursor()
        json_value = request.get_json()
        id, order_no, giftcard_no, work, status, balance, order_current_balance = None, None, None, None, None, None, None
        if 'order_no' in json_value:
            order_no = json_value['order_no']
        if 'giftcard_no' in json_value:
            giftcard_no = json_value['giftcard_no']
        if 'balance' in json_value:
            balance = json_value['balance']
        if 'order_current_balance' in json_value:
            order_current_balance = json_value['order_current_balance']
        if 'gc_status' in json_value:
            status = json_value['gc_status']
        if 'id' in json_value:
            id = json_value['id']
        if 'work' in json_value:
            work = str(json_value['work']).lower()
        if work == "update gc action":
            sql = "SELECT tracking_status FROM [dbo].[ordertracking] WHERE order_number=?"
            cursor.execute(sql, order_no)
            order_data = cursor.fetchone()
            action_status, action = None, 1
            if order_data:
                action_status = 'Check Balance'

                sql = "SELECT amount_paid, status, gift_card_value, balance FROM [dbo].[giftcardlist] WHERE gift_card_no = ? and check_balance_status is not null"
                cursor.execute(sql, giftcard_no)
                gc_data = cursor.fetchone()
                if gc_data:
                    gc_value, amount_paid, gc_balance = 0, 0, 0
                    gc_status = None

                    gc_value = gc_data.gift_card_value
                    amount_paid = gc_data.amount_paid
                    gc_status = gc_data.status
                    gc_balance = gc_data.balance
                    if order_data.tracking_status == 'Cancelled':
                        if gc_status == 'New Balance':
                            status = 'Refunded'

                    sql = "SELECT id FROM [dbo].[giftcardtransaction] WHERE ordernumber=? and giftcard_number=? and giftcard_status=? and action_type is not null order by Date_creation DESC"
                    val = (order_no, giftcard_no, status)
                    cursor.execute(sql, val)
                    gc_trasaction = cursor.fetchall()
                    if len(gc_trasaction) ==0:
                        current_balance = round((float(balance) - float(order_current_balance)), 2)
                        sql = "UPDATE [dbo].[giftcardtransaction] SET check_balance=? WHERE ordernumber=? and giftcard_number=?"
                        val = [0, order_no, giftcard_no]
                        cursor.execute(sql, val)
                        cursor.commit()

                        sql = "INSERT INTO [dbo].[giftcardtransaction] (user_id, company_id, ordernumber, giftcard_number, amount, gc_balance, gift_card_value, cost, giftcard_status, action, action_type, Date_creation) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
                        val = [1, 1, order_no, giftcard_no,
                               current_balance, gc_balance, gc_value, amount_paid, status,
                               action, action_status, datetime.datetime.now()]
                        cursor.execute(sql, val)
                        cursor.commit()
                        return jsonify({"code": 201, "success": "true"})
                    else:
                        sql = "UPDATE [dbo].[giftcardtransaction] SET check_balance=? WHERE ordernumber=? and giftcard_number=?"
                        val = [0, order_no, giftcard_no]
                        cursor.execute(sql, val)
                        cursor.commit()
                        return jsonify({"code": 404, "error": "The giftcard already exist with status."})

                        '''current_balance = round((float(balance) - float(order_current_balance)),2)
                        sql = "UPDATE [dbo].[giftcardtransaction] SET [amount] = ?, gc_balance=?, gift_card_value=?, cost=?, giftcard_status=?, Date_modify=? WHERE [id] = ?"
                        val = [current_balance, gc_balance, gc_value, amount_paid, status, datetime.datetime.now(), gc_trasaction[0][0]]
                        cursor.execute(sql, val)
                        cursor.commit()

                        sql = "UPDATE [dbo].[giftcardtransaction] SET check_balance=? WHERE ordernumber=? and giftcard_number=?"
                        val = [0, order_no, giftcard_no]
                        cursor.execute(sql, val)
                        cursor.commit()
                        return jsonify({"code": 200, "success": "true"})'''

                return jsonify({"code": 404, "error": "Giftcard balance is not checked."})
            else:
                return jsonify({"code": 403, "error": "Order number not exist."})
        elif work == "check balance":
            sql = "UPDATE [dbo].[giftcardtransaction] SET [amount] = ?, giftcard_status=?, check_balance=?, Date_modify=?, action=1 WHERE [id] = ?"
            val = [balance, status, 0, datetime.datetime.now(), id]
            cursor.execute(sql, val)
            cursor.commit()
            return jsonify({"code": 200, "success": "true"})
        elif work == "deletebyid":
            sql = "DELETE FROM [dbo].[giftcardtransaction] WHERE [id] = ?"
            cursor.execute(sql, id)
            cursor.commit()
            if cursor.rowcount>0:
                return jsonify({"code": 200, "success": str(cursor.rowcount)+" giftcards details are deleted"})
            return jsonify({"code": 404, "error": "No items are avaialbe."})
        elif work == "deletebyordernumber":
            sql = "DELETE FROM [dbo].[giftcardtransaction] WHERE [ordernumber] = ?"
            cursor.execute(sql, order_no)
            cursor.commit()
            if cursor.rowcount>0:
                return jsonify({"code": 200, "success": str(cursor.rowcount)+" giftcards details are deleted"})
            return jsonify({"code": 404, "error": "No items are avaialbe."})
        else:
            return jsonify({"code": 404, "error": "Invalid work style please use - update gc action, check balance, deletebyid or deletebyordernumber"})

class GetOrderDetail(Resource):
    def get(self):
        cursor = condb.cursor()
        json_data = []
        sql = "SELECT DISTINCT order_number, fullname, phone, tracking_status FROM [dbo].[ordertracking] WHERE tracking_status not in ('Recieved','Cancelled')"
        cursor.execute(sql)
        datalist = cursor.fetchall()
        json_data = []
        for data in datalist:
            data_dict = {}
            data_dict['order_id'] = data.order_number
            data_dict['phone'] = data.phone
            data_dict['tracking_status'] = data.tracking_status
            last_name = ""
            if data.fullname:
                last_name = str(data.fullname).split(" ")[1]
            data_dict['last_name'] = last_name
            json_data.append(data_dict)
        return {"code": 200, "data": json_data}

    def post(self):
        cursor = condb.cursor()
        json_data = []
        sql = "SELECT order_number, fullname, phone, max(Date_creation) as now_time FROM [dbo].[ordertracking] where Date_creation >= DATEADD(day,-1, GETDATE()) group by order_number, fullname, phone order by max(Date_creation) DESC"
        cursor.execute(sql)
        datalist = cursor.fetchall()
        json_data = []
        for data in datalist:
            data_dict = {}
            data_dict['order_id'] = data.order_number
            data_dict['phone'] = data.phone
            data_dict['date_time'] = data.now_time.strftime("%m-%d-%Y %H:%M:%S")
            last_name = ""
            if data.fullname:
                last_name = str(data.fullname).split(" ")[1]
            data_dict['last_name'] = last_name
            json_data.append(data_dict)
        return {"code": 200, "data": json_data}


'''class UpdateOrderStatus(Resource):
    def get(type):
        cursor = condb.cursor()
        json_data = []
        args = request.args
        if args:
            order_id = args['order_id']
            sql = "SELECT id, order_number, no_of_gc, item_sku, cart_total, tracking_status, fullname, phone, tracking_number, carrier FROM [dbo].[ordertracking] WHERE order_number = {0}".format(
                order_id)
            cursor.execute(sql)
            datalist = cursor.fetchall()
            json_data = []
            if len(datalist) != 0:
                for data in datalist:
                    data_dict = {}
                    data_dict['id'] = data.id
                    data_dict['order_id'] = data.order_number
                    data_dict['item_sku'] = data.item_sku
                    data_dict['cart_total'] = data.cart_total
                    data_dict['gc_nos'] = data.no_of_gc
                    data_dict['status'] = data.tracking_status
                    data_dict['phone'] = data.phone
                    data_dict['tracking_number'] = data.tracking_number
                    data_dict['carrier_name'] = data.carrier
                    last_name = ""
                    if data.fullname:
                        last_name = str(data.fullname).split(" ")[1]
                    data_dict['last_name'] = last_name
                    json_data.append(data_dict)
                return {"code": 200, "data": json_data}
            else:
                return {"code": 404, "data": "Please use valid order number"}

    def post(self):
        if request.method == "POST":
            # initializing cursor
            cursor = condb.cursor()
            # getting json data
            json_value = request.get_json()
            order_number, order_status, order_id, giftcard_nos = None, None, None, None
            sku_number, tracking_number, carrier_name, sku_number = None, None, None, None
            roucount = 0
            status_list = ['Ordered', 'Processed', 'Cancelled', 'Shipped', 'Delivered', 'Received']
            if 'order_id' in json_value:
                order_number = json_value['order_id']
                order_number = str(order_number).strip()
            if 'status' in json_value:
                order_status = json_value['status']
                order_status = order_status.title()
            if 'items' in json_value:
                items = json_value['items']
            if 'id' in json_value:
                order_id = json_value['id']
            if 'gc_nos' in json_value:
                giftcard_nos = json_value['gc_nos']

            if order_number and items:
                for order_data in items:
                    if 'tracking_status' in order_data:
                        order_status = order_data['tracking_status']
                        order_status = str(order_status).strip()
                        order_status = order_status.title()
                        if order_status not in status_list:
                            return jsonify({"code": 404,
                                            "error": "Please use valid status like - 'Ordered','Processed','Cancelled','Shipped','Delivered','Received'"})
                    if 'tracking_number' in order_data:
                        tracking_number = order_data['tracking_number']
                    if 'carrier_name' in order_data:
                        carrier_name = order_data['carrier_name']
                    if 'sku_no' in order_data:
                        for sku_no in order_data['sku_no']:
                            sku_number = sku_no
                            if sku_number and order_number and order_status:
                                sql = "UPDATE [dbo].[ordertracking] SET [tracking_status] = ?, [tracking_number] = ?, [carrier] = ?, [Date_modify] = ? WHERE [order_number] = ? and [item_sku] = ?"
                                val = [order_status, tracking_number, carrier_name, datetime.datetime.now(), order_number, sku_number]
                                cursor.execute(sql, val)
                                cursor.commit()
                                roucount += cursor.rowcount
                if order_status == 'Cancelled':
                    success = cancelledOrderForCheckingQueueGC(order_number, order_status)
                    print(success)
                else:
                    sql = "UPDATE [dbo].[giftcardtransaction] SET [order_purchase_status] = ?, [Date_modify] = ? WHERE [ordernumber] = ? and action_type is null"
                    val = [order_status, datetime.datetime.now(), order_number]
                    cursor.execute(sql, val)
                    cursor.commit()
                if roucount>0:
                    return jsonify({"code": 200, "success": "true"})
                return jsonify({"code": 404, "error": "Order Number or Sku Number have not matched."})
            elif order_number and giftcard_nos:
                sql = "UPDATE [dbo].[ordertracking] SET [no_of_gc] = ?, [Date_modify] = ? WHERE [order_number] = ?"
                val = [giftcard_nos, datetime.datetime.now(), order_number]
                cursor.execute(sql, val)
                # committing data on the database
                cursor.commit()
                return jsonify({"code": 200, "success": "true"})
            elif order_id and order_status:
                sql = "UPDATE [dbo].[ordertracking] SET [tracking_status] = ?, [Date_modify] = ? WHERE [id] = ?"
                val = [order_status, datetime.datetime.now(), order_id]
                cursor.execute(sql, val)
                # committing data on the database
                cursor.commit()

                return jsonify({"code": 200, "success": "true"})'''



class UpdateOrderStatus(Resource):
    def get(type):
        cursor = condb.cursor()
        json_data = []
        args = request.args
        if args:
            order_id = args['order_id']
            sql = "SELECT id, order_number, no_of_gc, item_sku, cart_total, tracking_status, fullname, phone, tracking_number, carrier FROM [dbo].[ordertracking] WHERE order_number = {0}".format(
                order_id)
            cursor.execute(sql)
            datalist = cursor.fetchall()
            json_data = []
            if len(datalist) != 0:
                for data in datalist:
                    data_dict = {}
                    data_dict['id'] = data.id
                    data_dict['order_id'] = data.order_number
                    data_dict['item_sku'] = data.item_sku
                    data_dict['cart_total'] = data.cart_total
                    data_dict['gc_nos'] = data.no_of_gc
                    data_dict['status'] = data.tracking_status
                    data_dict['phone'] = data.phone
                    data_dict['tracking_number'] = data.tracking_number
                    data_dict['carrier_name'] = data.carrier
                    last_name = ""
                    if data.fullname:
                        last_name = str(data.fullname).split(" ")[1]
                    data_dict['last_name'] = last_name
                    json_data.append(data_dict)
                return {"code": 200, "data": json_data}
            else:
                return {"code": 404, "data": "Please use valid order number"}

    def post(self):
        if request.method == "POST":
            # initializing cursor
            cursor = condb.cursor()
            # getting json data
            json_value = request.get_json()
            order_number, order_status, order_id, giftcard_nos = None, None, None, None
            sku_number, tracking_number, carrier_name, sku_number = None, None, None, None
            order_total, products_total, order_taxes, shipping, total_qty = 0, 0, 0, 0, 0
            roucount = 0
            status_list = ['Ordered', 'Processed', 'Cancelled', 'Shipped', 'Delivered', 'Received']
            if 'status' in json_value:
                order_status = json_value['status']
                order_status = order_status.title()
            if 'items' in json_value:
                items = json_value['items']
            if 'id' in json_value:
                order_id = json_value['id']
            if 'gc_nos' in json_value:
                giftcard_nos = json_value['gc_nos']
            if 'order_id' in json_value:
                order_number = json_value['order_id']
                order_number = str(order_number).strip()
            if 'order_total' in json_value:
                try:
                    order_total = float(json_value['order_total'])
                except:
                    pass
            if 'products_total' in json_value:
                try:
                    products_total = float(json_value['products_total'])
                except:
                    pass
            if 'order_taxes' in json_value:
                try:
                    order_taxes = float(json_value['order_taxes'])
                except:
                    pass
            if 'shipping' in json_value:
                try:
                    shipping = float(json_value['shipping'])
                except:
                    pass

            combine_details = []
            item_sku_qty = {}
            status_set = set()
            if order_number and items:
                sku_no_check = ""
                for order_data in items:
                    if 'tracking_status' in order_data:
                        order_status = order_data['tracking_status']
                        order_status = str(order_status).strip()
                        order_status = order_status.title()
                        status_set.add(order_status)
                        # if order_status not in status_list:
                        #     return jsonify({"code": 404,
                        #                     "error": "Please use valid status like - 'Ordered','Processed','Cancelled','Shipped','Delivered','Received'"})
                    if 'tracking_number' in order_data:
                        tracking_number = order_data['tracking_number']
                    if 'carrier_name' in order_data:
                        carrier_name = order_data['carrier_name']
                    if 'sku_no' in order_data:
                        for sku in order_data['sku_no']:
                            sku_data = {}
                            if sku['sku']:
                                if sku_no_check != sku['sku']: 
                                    sku_no_check = sku['sku']
                                    total_qty = 0
                                try:
                                    qty = int(float(sku['qty']))
                                    total_qty += qty 
                                    item_sku_qty[sku_no_check] = total_qty
                                except:
                                    qty = 0
                                try:
                                    price = float(sku['item_price'])
                                except:
                                    price = 0
                                sku_data['sku'] = sku['sku']
                                sku_data['qty'] = qty
                                sku_data['price'] = price
                                sku_data['order_number'] = order_number
                                sku_data['total_cost'] = products_total
                                sku_data['sub_total'] = order_total
                                sku_data['tax'] = order_taxes
                                sku_data['shipping'] = shipping
                                sku_data['tracking_status'] = order_status
                                sku_data['tracking_number'] = tracking_number
                                sku_data['carrier'] = carrier_name
                                sku_data['operation'] = True
                                combine_details.append(sku_data)


                                # sql = "UPDATE [dbo].[ordertracking] SET [tracking_status] = ?, [tracking_number] = ?, [carrier] = ?, [Date_modify] = ? WHERE [order_number] = ? and [item_sku] = ?"
                                # val = [order_status, tracking_number, carrier_name, datetime.datetime.now(), order_number, sku_number]
                                # cursor.execute(sql, val)
                                # cursor.commit()
                                # roucount += cursor.rowcount
                print(combine_details)
                print(item_sku_qty)
                sql ="SELECT * FROM [dbo].[ordertracking] WHERE order_number=?"
                val= [order_number]
                cursor.execute(sql, val)
                order_tracking_detail = cursor.fetchall()
                if len(order_tracking_detail) < len(combine_details):
                    insert_record = len(combine_details) - len(order_tracking_detail)
                    item_sku, price, qty_cart, user_id, company_id, cart_id, address_id, email_id = None, None, None, None, None, None, None, None
                    vendor, retailer, title, cart_total, payment_type, order_number, tracking_status = None, None, None, None, None, None, None
                    tracking_number, phone, discount_cost, tax_cost, subtotal, shipping_cost, carrier = None, None, None, None, None, None, None
                    no_of_gc, no_of_item, orderedDate, fullname = None, None, None, None
                    for ot_detail in order_tracking_detail:
                        item_sku = ot_detail.item_sku
                        price = ot_detail.price
                        qty_cart = ot_detail.qty_cart
                        user_id = ot_detail.user_id
                        company_id = ot_detail.company_id
                        cart_id = ot_detail.cart_id
                        address_id = ot_detail.address_id
                        email_id = ot_detail.email_id
                        vendor = ot_detail.vendor
                        retailer = ot_detail.retailer
                        title = ot_detail.title
                        cart_total = ot_detail.cart_total
                        payment_type = ot_detail.payment_type
                        order_number = ot_detail.order_number
                        tracking_status = ot_detail.tracking_status
                        tracking_number = ot_detail.tracking_number
                        phone = ot_detail.phone
                        discount_cost = ot_detail.discount_cost
                        tax_cost = ot_detail.tax_cost
                        subtotal = ot_detail.subtotal
                        shipping_cost = ot_detail.shipping_cost
                        carrier = ot_detail.carrier
                        no_of_gc = ot_detail.no_of_gc
                        no_of_item = ot_detail.no_of_item
                        orderedDate = ot_detail.orderedDate
                        fullname = ot_detail.fullname
                        for cds in combine_details:
                            if item_sku == cds['sku']:
                                if item_sku == cds['sku'] and qty_cart == cds['qty'] and cds['operation']:
                                    sql = "UPDATE [dbo].[ordertracking] SET [qty_cart]=?, [tracking_status] = ?, [tracking_number] = ?, [carrier] = ?, [Date_modify] = ? WHERE [order_number] = ? and [item_sku] = ? and [qty_cart]=?"
                                    val = [cds['qty'], cds['tracking_status'], cds['tracking_number'], cds['carrier'], datetime.datetime.now(),
                                           cds['order_number'], cds['sku'], qty_cart]
                                    cursor.execute(sql, val)
                                    cursor.commit()
                                    cds['operation'] = False
                                    roucount += cursor.rowcount
                                elif insert_record > 0 and cds['operation']:
                                    sql = "INSERT INTO [dbo].[ordertracking] (user_id, company_id, vendor, fullname, item_sku, qty_cart, title, tracking_status, carrier, tracking_number, price, cart_total, payment_type, retailer, order_number, tax_cost, subtotal, shipping_cost, cart_id, address_id, email_id, phone, no_of_gc, no_of_item, orderedDate, Date_creation) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);"
                                    val = [user_id, company_id, vendor, fullname, cds['sku'], cds['qty'], title,
                                           cds['tracking_status'], cds['carrier'], cds['tracking_number'],
                                           price, cds['total_cost'], payment_type, retailer, cds['order_number'],
                                           cds['tax'], cds['sub_total'], cds['shipping'],
                                           cart_id, address_id, email_id,
                                           phone, no_of_gc, no_of_item, orderedDate,
                                           datetime.datetime.now()]
                                    cursor.execute(sql, val)
                                    cursor.commit()
                                    cds['operation'] = False
                                    roucount += cursor.rowcount
                                    insert_record = insert_record-1
                                elif item_sku == cds['sku'] and qty_cart != cds['qty'] and cds['operation']:
                                    if cds['qty'] != 0:
                                        sql = "UPDATE [dbo].[ordertracking] SET [qty_cart]=?, [tracking_status] = ?, [tracking_number] = ?, [carrier] = ?, [Date_modify] = ? WHERE [order_number] = ? and [item_sku] = ? and [qty_cart]=?"
                                        val = [cds['qty'], cds['tracking_status'], cds['tracking_number'],
                                               cds['carrier'],
                                               datetime.datetime.now(),
                                               cds['order_number'], cds['sku'], qty_cart]
                                    else:
                                        sql = "UPDATE [dbo].[ordertracking] SET [tracking_status] = ?, [tracking_number] = ?, [carrier] = ?, [Date_modify] = ? WHERE [order_number] = ? and [item_sku] = ?"
                                        val = [cds['tracking_status'], cds['tracking_number'],
                                               cds['carrier'],
                                               datetime.datetime.now(),
                                               cds['order_number'], cds['sku']]
                                    cursor.execute(sql, val)
                                    cursor.commit()
                                    cds['operation'] = False
                                    roucount += cursor.rowcount
                elif len(order_tracking_detail) == len(combine_details):
                    item_sku, qty_cart = None, None
                    for ot_detail in order_tracking_detail:
                        item_sku = ot_detail.item_sku
                        qty_cart = ot_detail.qty_cart
                        for cds in combine_details:
                            if item_sku == cds['sku']:
                                if item_sku == cds['sku'] and qty_cart == cds['qty'] and cds['operation']:
                                    sql = "UPDATE [dbo].[ordertracking] SET [tracking_status] = ?, [tracking_number] = ?, [carrier] = ?, [Date_modify] = ? WHERE [order_number] = ? and [item_sku] = ? and [qty_cart]=?"
                                    val = [cds['tracking_status'], cds['tracking_number'], cds['carrier'],
                                           datetime.datetime.now(),
                                           cds['order_number'], cds['sku'], qty_cart]
                                    cursor.execute(sql, val)
                                    cursor.commit()
                                    cds['operation'] = False
                                    roucount += cursor.rowcount
                                elif item_sku == cds['sku'] and qty_cart != cds['qty'] and cds['operation']:
                                    if cds['qty'] != 0:
                                        sql = "UPDATE [dbo].[ordertracking] SET [qty_cart]=?, [tracking_status] = ?, [tracking_number] = ?, [carrier] = ?, [Date_modify] = ? WHERE [order_number] = ? and [item_sku] = ? and [qty_cart]=?"
                                        val = [cds['qty'], cds['tracking_status'], cds['tracking_number'],
                                               cds['carrier'],
                                               datetime.datetime.now(),
                                               cds['order_number'], cds['sku'], qty_cart]
                                    else:
                                        sql = "UPDATE [dbo].[ordertracking] SET [tracking_status] = ?, [tracking_number] = ?, [carrier] = ?, [Date_modify] = ? WHERE [order_number] = ? and [item_sku] = ?"
                                        val = [cds['tracking_status'], cds['tracking_number'],
                                               cds['carrier'],
                                               datetime.datetime.now(),
                                               cds['order_number'], cds['sku']]
                                    cursor.execute(sql, val)
                                    cursor.commit()
                                    cds['operation'] = False
                                    roucount += cursor.rowcount

                order_status = ", ".join(list(status_set))
                if order_status == 'Cancelled':
                    success = cancelledOrderForCheckingQueueGC(order_number, order_status)
                    print(success)
                else:
                    sql = "UPDATE [dbo].[giftcardtransaction] SET [order_purchase_status] = ?, [Date_modify] = ? WHERE [ordernumber] = ? and action_type is null"
                    val = [order_status, datetime.datetime.now(), order_number]
                    cursor.execute(sql, val)
                    cursor.commit()
                if roucount>0:
                    return jsonify({"code": 200, "success": "true"})
                return jsonify({"code": 404, "error": "Order Number or Sku Number have not matched."})
            elif order_number and giftcard_nos:
                sql = "UPDATE [dbo].[ordertracking] SET [no_of_gc] = ?, [Date_modify] = ? WHERE [order_number] = ?"
                val = [giftcard_nos, datetime.datetime.now(), order_number]
                cursor.execute(sql, val)
                # committing data on the database
                cursor.commit()
                return jsonify({"code": 200, "success": "true"})
            elif order_id and order_status:
                sql = "UPDATE [dbo].[ordertracking] SET [tracking_status] = ?, [Date_modify] = ? WHERE [id] = ?"
                val = [order_status, datetime.datetime.now(), order_id]
                cursor.execute(sql, val)
                # committing data on the database
                cursor.commit()

                return jsonify({"code": 200, "success": "true"})


class UpdateGiftcardTrasactionStatus(Resource):
    def get(self):
        cursor = condb.cursor()
        json_data = []
        args = request.args
        if args:
            order_id = args['order_id']
            sql = "SELECT id, order_purchase_total, order_purchase_status, amount, giftcard_number, ordernumber FROM [dbo].[giftcardtransaction] WHERE ordernumber = {0} and action_type is null".format(
                order_id)
            cursor.execute(sql)
            datalist = cursor.fetchall()
            if len(datalist) != 0:
                for data in datalist:
                    data_dict = {}
                    data_dict['id'] = data.id
                    data_dict['order_cost'] = data.order_purchase_total
                    data_dict['order_status'] = data.order_purchase_status
                    data_dict['giftcard_price'] = data.amount
                    data_dict['giftcard_no'] = data.giftcard_number
                    data_dict['order_id'] = data.ordernumber
                    json_data.append(data_dict)
                return {"code": 200, "data": json_data}
            else:
                return {"code": 404, "data": "Please use valid order number"}

    def post(self):
        if request.method == "POST":
            # initializing cursor
            cursor = condb.cursor()
            # getting json data
            json_value = request.get_json()
            order_number, order_status, order_id = None, None, None
            status_list = ['Ordered', 'Processed', 'Cancelled', 'Shipped', 'Delivered', 'Received']
            if 'order_id' in json_value:
                order_number = json_value['order_id']
            if 'status' in json_value:
                order_status = json_value['status']
                order_status = order_status.title()

            if order_status not in status_list:
                return jsonify({"code": 404,
                                "error": "Please use valid status like - 'Ordered','Processed','Cancelled','Shipped','Delivered','Received'"})

            if order_number and order_status:
                if order_status == 'Cancelled':
                    status = cancelledOrderForCheckingQueueGC(order_number, order_status)
                    print(status)
                else:
                    sql = "UPDATE [dbo].[giftcardtransaction] SET [order_purchase_status] = ? WHERE [ordernumber] = ? and action_type is null"
                    val = [order_status, order_number]
                    cursor.execute(sql, val)
                    cursor.commit()
                return jsonify({"code": 200, "success": "true"})
            else:
                return jsonify({"code": 404})


class SetContactDetails(Resource):
    def post(self):
        cursor = condb.cursor()
        json_value = request.get_json()
        address_id=email_id=phone=cart_id=None
        method = ""
        if 'address_id' in json_value:
            address_id = json_value['address_id']
        if 'email_id' in json_value:
            email_id = json_value['email_id']
        if 'phone' in json_value:
            phone = json_value['phone']
        if 'cart_id' in json_value:
            cart_id = json_value['cart_id']
        if 'method' in json_value:
            method = json_value['method']

        sql = "SELECT id FROM [dbo].[buyingmaster] WHERE cart_id = ?"
        cursor.execute(sql, cart_id)
        data_existance = cursor.fetchall()
        json_data = {}
        if len(data_existance) != 0:
            if method == 'InvalidPhoneNumber':
                sql = "UPDATE [dbo].[phonenumber] SET status=?, last_used=? WHERE phone=?"
                val = ('Invalid', datetime.datetime.now(), phone)
                cursor.execute(sql, val)
                cursor.commit()

                sql = "SELECT top (1) id, phone, phone_used, status from [dbo].[phonenumber] where status = 'Active' AND is_using = 0"
                cursor.execute(sql)
                table_data = cursor.fetchall()
                for td in table_data:
                    id = td.id
                    sql = "UPDATE [dbo].[phonenumber] SET is_using = 1 WHERE id = ?"
                    cursor.execute(sql, id)
                    cursor.commit()
                    json_data['id'] = id
                    json_data['phone'] = td.phone
                    json_data['phone_used'] = td.phone_used
                    json_data['status'] = td.status

            elif method == 'InvalidEmail':
                sql = "UPDATE [dbo].[emailmaster] SET status=?, last_used=? WHERE id=?"
                val = ('Invalid', datetime.datetime.now(), email_id)
                cursor.execute(sql, val)
                cursor.commit()

                sql = "SELECT top (1) id, parent_id, email, email_used, status from [dbo].[emailmaster] where status = 'Active' and is_using = 0"
                cursor.execute(sql)
                table_data = cursor.fetchall()
                json_data = {}
                for td in table_data:
                    id = td.id
                    sql = "UPDATE [dbo].[emailmaster] SET is_using = 1 WHERE id = ?"
                    cursor.execute(sql, id)
                    cursor.commit()
                    json_data['id'] = id
                    json_data['parent_id'] = td.parent_id
                    json_data['email'] = td.email
                    json_data['email_used'] = td.email_used
                    json_data['status'] = td.status

            elif method == 'InvalidAddress':
                sql = "UPDATE [dbo].[emailmaster] SET status=?, last_used=? WHERE id=?"
                val = ('Invalid', datetime.datetime.now(), address_id)
                cursor.execute(sql, val)
                cursor.commit()

                sql = "SELECT top (1) id, parent_id, street, suite, city, state, zip, address_used, status from [dbo].[addressmaster] where status = 'Active' AND is_using = 0"
                cursor.execute(sql)
                table_data = cursor.fetchall()
                json_data = {}
                for td in table_data:
                    id = td.id
                    sql = "UPDATE [dbo].[addressmaster] SET is_using = 1 WHERE id = ?"
                    cursor.execute(sql, id)
                    cursor.commit()
                    json_data['id'] = id
                    json_data['parent_id'] = td.parent_id
                    json_data['street'] = td.street
                    json_data['suite'] = td.suite
                    json_data['city'] = td.city
                    json_data['state'] = td.state
                    json_data['zip'] = td.zip
                    json_data['address_used'] = td.address_used
                    json_data['status'] = td.status

            elif method == 'UpdateContactInfo':
                if address_id != None:
                    sql = "UPDATE [dbo].[addressmaster] SET status=?, address_used=?, cart_id=?, last_used=? WHERE id=?"
                    val = ('Inactive', 1, cart_id, datetime.datetime.now(), address_id)
                    cursor.execute(sql, val)
                    cursor.commit()
                if email_id != None:
                    sql = "UPDATE [dbo].[emailmaster] SET status=?, email_used=?, cart_id=?, last_used=? WHERE id=?"
                    val = ('Inactive', 1, cart_id, datetime.datetime.now(), email_id)
                    cursor.execute(sql, val)
                    cursor.commit()
                if phone != None:
                    sql = "UPDATE [dbo].[phonenumber] SET status=?, phone_used=?, cart_id=?, last_used=? WHERE phone=?"
                    val = ('Inactive', 1, cart_id, datetime.datetime.now(), phone)
                    cursor.execute(sql, val)
                    cursor.commit()
            else:
                return jsonify({'code': 403, 'message': "Please use valid operation method"})
            if json_data:
                return jsonify({'code': 200, 'message': "Updated Privious and Please Check New Contact Details",
                                'data': json_data})
            else:
                return jsonify({'code': 200, 'message': "updated successfully"})
        else:
            return jsonify({'code': 404, 'message': "The valid cart id must be required."})


class GetContactDetails(Resource):
    def post(self):
        if request.method == "POST":
            # initializing cursor
            cursor = condb.cursor()
            # getting json data
            all_json = {}
            json_data = {}
            json_value = request.get_json()
            cart_id = None
            if 'cart_id' in json_value:
                cart_id = json_value['cart_id']
            else:
                return jsonify({'message': "'cart_id' must be required for the operation", 'code': 404})
            if 'phone' in json_value:
                if json_value['phone']:
                    sql = "SELECT top (1) id, phone, phone_used, status from [dbo].[phonenumber] where status = 'Inactive' AND (is_using = 0) AND cart_id=?"
                    cursor.execute(sql,cart_id)
                    table_data = cursor.fetchall()

                    json_data = {}
                    for td in table_data:
                        id = td.id
                        sql = "UPDATE [dbo].[phonenumber] SET is_using = 1 WHERE id = ?"
                        cursor.execute(sql, id)
                        cursor.commit()
                        json_data['id'] = id
                        json_data['phone'] = td.phone
                        json_data['phone_used'] = td.phone_used
                        json_data['status'] = td.status
                    all_json['phone_details'] = json_data
            if 'name' in json_value:
                if json_value['name']:
                    full_names = names.get_full_name(gender='male')
                    first_name = full_names.split(" ")[0]
                    last_name = full_names.split(" ")[1]
                    json_data = {}
                    json_data['full_names'] = full_names
                    json_data['first_name'] = first_name
                    json_data['last_name'] = last_name
                    all_json['contact_person'] = json_data
            if 'address' in json_value:
                if json_value['address']:
                    sql = "SELECT top (1) id, parent_id, street, suite, city, state, zip, address_used, status from [dbo].[addressmaster] where status = 'Inactive' AND (is_using = 0) AND cart_id=?"
                    cursor.execute(sql, cart_id)
                    table_data = cursor.fetchall()
                    json_data = {}
                    for td in table_data:
                        id = td.id
                        sql = "UPDATE [dbo].[addressmaster] SET is_using = 1 WHERE id = ?"
                        cursor.execute(sql, id)
                        cursor.commit()
                        json_data['id'] = id
                        json_data['parent_id'] = td.parent_id
                        json_data['street'] = td.street
                        json_data['suite'] = td.suite
                        json_data['city'] = td.city
                        json_data['state'] = td.state
                        json_data['zip'] = td.zip
                        json_data['address_used'] = td.address_used
                        json_data['status'] = td.status
                    all_json['addresses'] = json_data
            if 'by_parent_id_address' in json_value:
                if json_value['by_parent_id_address']:
                    sql = "SELECT top (1) id, parent_id, street, suite, city, state, zip, address_used, status from [dbo].[addressmaster] where status = 'Ictive' and parent_id=? and is_using = 0"
                    val = [json_value['parent_id']]
                    cursor.execute(sql, val)
                    table_data = cursor.fetchall()
                    json_data = {}
                    for td in table_data:
                        id = td.id
                        sql = "UPDATE [dbo].[addressmaster] SET is_using = 1 WHERE id = ?"
                        cursor.execute(sql, id)
                        cursor.commit()
                        json_data['id'] = id
                        json_data['parent_id'] = td.parent_id
                        json_data['street'] = td.street
                        json_data['suite'] = td.suite
                        json_data['city'] = td.city
                        json_data['state'] = td.state
                        json_data['zip'] = td.zip
                        json_data['address_used'] = td.address_used
                        json_data['status'] = td.status
                    all_json['addresses_by_parent_id'] = json_data
            if 'email' in json_value:
                if json_value['email']:
                    sql = "SELECT top (1) id, parent_id, email, email_used, status from [dbo].[emailmaster] where status = 'Inactive' and (is_using = 0) AND cart_id=?"
                    cursor.execute(sql, cart_id)
                    table_data = cursor.fetchall()
                    json_data = {}
                    for td in table_data:
                        id = td.id
                        sql = "UPDATE [dbo].[emailmaster] SET is_using = 1 WHERE id = ?"
                        cursor.execute(sql, id)
                        cursor.commit()
                        json_data['id'] = id
                        json_data['parent_id'] = td.parent_id
                        json_data['email'] = td.email
                        json_data['email_used'] = td.email_used
                        json_data['status'] = td.status
                    all_json['emails'] = json_data
            if 'by_parent_id_email' in json_value:
                if json_value['by_parent_id_email']:
                    sql = "SELECT top (1) id, parent_id, email, email_used, status from [dbo].[emailmaster] where status = 'Active' and parent_id=? and is_using = 0"
            +        v\[json_value['parent_id']]
                    cursor.execute(sql, val)
                    table_data = cursor.fetchall()
                    json_data = {}
                    for td in table_data:
                        id = td.id
                        sql = "UPDATE [dbo].[emailmaster] SET is_using = 1 WHERE id = ?"
                        cursor.execute(sql, id)
                        cursor.commit()
                        json_data['id'] = id
                        json_data['parent_id'] = td.parent_id
                        json_data['email'] = td.email
                        json_data['email_used'] = td.email_used
                        json_data['status'] = td.status
                    all_json['emails_by_parent_id'] = json_data
            if 'all_json' in json_value:
                if json_value['all_json'] == True:
                    return jsonify({'code': 200, 'data': all_json})
                else:
                    return jsonify({'code': 200, 'data': json_data})
            else:
                return jsonify({'code': 200, 'data': json_data})
            return jsonify(
                {'code': 404, 'data': "Please true at least one operation from address, email, name or phone."})


class ResetContactUse(Resource):
    def post(self):
        cursor = condb.cursor()
        json_value = request.get_json()
        address, email, phone, = False, False, False
        messages = ''
        message = []
        if 'address' in json_value:
            address = json_value['address']
        if 'email' in json_value:
            email = json_value['email']
        if 'phone' in json_value:
            phone = json_value['phone']
        if address:
            sql = "UPDATE [dbo].[addressmaster] SET is_using = 0 WHERE address_used = 0"
            cursor.execute(sql)
            cursor.commit()
            message.append('Address')
        if email:
            sql = "UPDATE [dbo].[emailmaster] SET is_using = 0 WHERE email_used = 0"
            cursor.execute(sql)
            cursor.commit()
            message.append('Email')
        if phone:
            sql = "UPDATE [dbo].[phonenumber] SET is_using = 0 WHERE phone_used = 0"
            cursor.execute(sql)
            cursor.commit()
            message.append('Phone')
        messages = (', ').join(message)
        if messages != '':
            messages = "Reset - " + messages
            return jsonify({'code': 200, 'message': messages})
        return jsonify({'code': 200, 'message': "Are you sure you have set 'true' for address, email or phone"})


class GiftCardUpdate(Resource):
    # api for getting data from giftcard list on the basis of last_used giftcard date
    def get(self):
        try:
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # converting today date into yesterday
            yesterday = datetime.datetime.now() - datetime.timedelta(days=1)
            # formatting date in string format
            yesterdayDate = yesterday.strftime('%Y-%m-%d')
            # sql query for getting data on the basic of last-used giftcard date
            # sql = "SELECT giftcard_number FROM [dbo].[giftcardtransaction] where cast(Date_creation as date) = ?"
            sql = "SELECT [gift_card_no] FROM [bestbuymaster].[dbo].[giftcardlist] WHERE check_balance_status is Null AND cast(last_used as date) = ?"
            # execute sql query on the basic of python yesterday date
            cursor.execute(sql, yesterdayDate)
            # cursor.execute(sql)
            # fetch all data on the basic of last-used giftcard date
            last_used_gc = cursor.fetchall()
            # checking whether there will be last used date or not
            lastUsedCard_list = []
            if len(last_used_gc) != 0:
                for gc in last_used_gc:
                    ##execute sql query on the basic of id, user id, balance, check_balance_status, gift_card_pin and gift_card_no
                    sql = "SELECT [id], [balance], [gift_card_value], [user_id], [gift_card_pin], [gift_card_no], [retailer], [status], [batch_id] FROM [dbo].[giftcardlist] WHERE gift_card_no = ?"
                    cursor.execute(sql, gc[0])
                    giftcard_data = cursor.fetchall()
                    print(giftcard_data)

                    if len(giftcard_data) != 0:
                        giftcardDict = {
                            "id": giftcard_data[0][0],
                            "balance": giftcard_data[0][1],
                            "value": giftcard_data[0][2],
                            "userid": giftcard_data[0][3],
                            "giftcardpin": giftcard_data[0][4],
                            "giftcardno": giftcard_data[0][5],
                            "retailer": giftcard_data[0][6],
                            "status": giftcard_data[0][7],
                            "batch_id": giftcard_data[0][8]
                        }
                        lastUsedCard_list.append(giftcardDict)
                    else:
                        return jsonify({"error": {"code": 404, "message": "giftcard not found in giftcardlist"}})
                return jsonify({"code": 200, "data": {'lastUsedCard_list': lastUsedCard_list}})
            return jsonify({"code": 404, "data": {'lastUsedCard_list': lastUsedCard_list}})
        except Exception as e:
            print(e)
            return jsonify({"error": {"code": 404, "message": str(e)}})

    # api for updating balance and status of the gift-card
    def post(self):
        try:
            # initializing cursor
            cursor = condb.cursor()
            # getting updating data like userid, balance, status in json format
            updated_data = request.get_json()
            print(updated_data)
            # checking weather updated_data is not empty
            if len(updated_data) != 0:
                giftcard_id = updated_data['giftcardno'].strip()
                json_balance = updated_data['balance'].strip()
                json_status = updated_data['status'].strip()

                if giftcard_id and json_balance and json_status:
                    # Checking given giftcard_id exist or not giftcardlist Table
                    sql = "SELECT [id], [balance], [gift_card_no], [gift_card_value], [status] FROM [dbo].[giftcardlist] WHERE [dbo].[giftcardlist].[gift_card_no]=?"
                    cursor.execute(sql, giftcard_id)
                    giftcardId = cursor.fetchall()
                    if len(giftcardId) != 0:
                        balance = giftcardId[0][1]
                        gift_card_no = giftcardId[0][2]
                        gift_card_value = giftcardId[0][3]
                        gift_card_status = giftcardId[0][4]
                        round_json_balance = round(float(json_balance),2)
                        # sql query for updating data on the database --> balance and status
                        sql = "UPDATE [dbo].[giftcardlist] SET [balance] = ?, [last_check] = ?, [status] = ?, [check_balance_status] = ? WHERE [dbo].[giftcardlist].[gift_card_no]=?"
                        val = (
                        round_json_balance, datetime.datetime.now(), json_status, 'checked',
                        giftcard_id)
                        # execute sql query on the basic of user id, balance and status
                        cursor.execute(sql, val)
                        # committing data on the database
                        cursor.commit()

                        # if new found balance is greater than existing balance then it update the value in new money
                        if float(json_balance) > balance:
                            new_money = float(json_balance) - balance
                            sql = "UPDATE [dbo].[giftcardlist] SET status='New Balance', [new_money] = ? WHERE [dbo].[giftcardlist].[gift_card_no]=?"
                            val = (new_money, giftcard_id)
                            cursor.execute(sql, val)
                            cursor.commit()
                        else:
                            # if new found balance is less than existing balance then  new money becomes zero
                            sql = "UPDATE [dbo].[giftcardlist] SET [new_money] = ? WHERE [dbo].[giftcardlist].[gift_card_no]=?"
                            val = (0, giftcard_id)
                            cursor.execute(sql, val)
                            cursor.commit()

                        # sql = "SELECT giftcard_number, sum(amount) FROM [dbo].[giftcardtransaction] where giftcard_number =? and action_type is null group by giftcard_number"
                        # cursor.execute(sql, giftcard_id)
                        # data = cursor.fetchall()
                        # if len(data) != 0:
                        #     # last transaction amount & json balance will not be same
                        #     amount = data[0][1]
                        #     cal = gift_card_value - amount
                        #     cal = round(cal, 2)
                        #     if float(json_balance) != cal:
                        #         sql = "UPDATE [dbo].[giftcardlist] SET [status] = ? WHERE [dbo].[giftcardlist].gift_card_no=?"
                        #         val = ("Balance Off", giftcard_id)
                        #         # execute sql query on the basic of user id, balance and status
                        #         cursor.execute(sql, val)
                        #         # committing data on the database
                        #         cursor.commit()

                        return jsonify({"code": 200, "success": "true"})
                    else:
                        return jsonify({"error": {"code": 404, "message": "UserId Not Found"}})
                else:
                    return jsonify(
                        {"error": {"code": 404, "message": {"Invalid Params": "UserID or Balance or Status"}}})
            else:
                return jsonify({"error": {"code": 404, "message": {"Parameter Not Found": updated_data}}})
        except KeyError as e:
            print(e)
            return jsonify({"error": {"code": 404, "message": f"Parameter Missing:{str(e)}"}})
        except Exception as e:
            print(e)
            return jsonify({"error": {"code": 404, "message": str(e)}})


class LockGcUpdate(Resource):
    def get(self):
        try:
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # converting today date into yesterday
            non_cancelled_days, cancelled_days = 0, 0
            sql = "SELECT non_cancelled_order, cancelled_order, status FROM [dbo].[settings]"
            cursor.execute(sql)
            table_Data = cursor.fetchone()
            if table_Data:
                non_cancelled_days = table_Data.non_cancelled_order
                non_cancelled_status = table_Data.status
                cancelled_days = table_Data.cancelled_order

            # sql query for getting data on the basis of cancelled order locked giftcard
            sql = "SELECT B.id, B.gift_card_no FROM [dbo].[giftcardtransaction] AS A INNER JOIN [dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no where B.[last_used] <= DATEADD(day,-{}, GETDATE()) and A.order_purchase_status='Cancelled' and B.status='Locked' and A.action_type is null".format(
                cancelled_days)
            cursor.execute(sql)
            cancelled_data = cursor.fetchall()

            # sql query for getting data on the basis of non cancelled order locked giftcard
            sql = "SELECT B.id, B.gift_card_no FROM [dbo].[giftcardtransaction] AS A INNER JOIN [dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no where (B.[last_used] <= DATEADD(day,-{}, GETDATE()) OR A.order_purchase_status='{}') and A.order_purchase_status!='Cancelled' and B.status='Locked' and A.action_type is null".format(
                non_cancelled_days, non_cancelled_status)
            cursor.execute(sql)
            non_cancelled_data = cursor.fetchall()

            # checking whether there will be last used date or not
            lockedCard_list = []
            if len(cancelled_data) != 0:
                for gc in cancelled_data:
                    ##execute sql query on the basic of id, user id, balance, check_balance_status, gift_card_pin and gift_card_no
                    sql = "SELECT [id], [balance], [gift_card_value], [user_id], [gift_card_pin], [gift_card_no], [retailer], [status], [batch_id] FROM [dbo].[giftcardlist] WHERE id = ?"
                    cursor.execute(sql, gc[0])
                    giftcard_data = cursor.fetchall()
                    # print(giftcard_data)

                    if len(giftcard_data) != 0:
                        giftcardDict = {
                            "id": giftcard_data[0][0],
                            "balance": giftcard_data[0][1],
                            "value": giftcard_data[0][2],
                            "userid": giftcard_data[0][3],
                            "giftcardpin": giftcard_data[0][4],
                            "giftcardno": giftcard_data[0][5],
                            "retailer": giftcard_data[0][6],
                            "status": giftcard_data[0][7],
                            "batch_id": giftcard_data[0][8]
                        }
                        lockedCard_list.append(giftcardDict)

            if len(non_cancelled_data) != 0:
                for gc in non_cancelled_data:
                    ##execute sql query on the basic of id, user id, balance, check_balance_status, gift_card_pin and gift_card_no
                    sql = "SELECT [id], [balance], [gift_card_value], [user_id], [gift_card_pin], [gift_card_no], [retailer], [status], [batch_id] FROM [dbo].[giftcardlist] WHERE id = ?"
                    cursor.execute(sql, gc[0])
                    giftcard_data = cursor.fetchall()
                    # print(giftcard_data)

                    if len(giftcard_data) != 0:
                        giftcardDict = {
                            "id": giftcard_data[0][0],
                            "balance": giftcard_data[0][1],
                            "value": giftcard_data[0][2],
                            "userid": giftcard_data[0][3],
                            "giftcardpin": giftcard_data[0][4],
                            "giftcardno": giftcard_data[0][5],
                            "retailer": giftcard_data[0][6],
                            "status": giftcard_data[0][7],
                            "batch_id": giftcard_data[0][8]
                        }
                        lockedCard_list.append(giftcardDict)

            if len(lockedCard_list) !=0:
                return jsonify({"code": 200, "data": {'lockedCard_list': lockedCard_list}})
            else:
                return jsonify({"code": 404, "data": {'lockedCard_list': lockedCard_list}})
        except Exception as e:
            print(e)
            return jsonify({"error": {"code": 404, "message": str(e)}})


class GiftCardQueue(Resource):
    # api for check balance when checkbalance button is clicked from bulk action tab on GiftCardLIst Page
    def get(self):
        try:
            # initializing cursor
            cursor = condb.cursor()
            # sql query for getting data from the giftcardlist table if checkbalance is null
            sql = "SELECT [id], [balance], [gift_card_value], [user_id], [check_balance_status], [gift_card_pin], [gift_card_no], [retailer], [batch_id], status FROM [dbo].[giftcardlist] WHERE queue_status='que' and check_balance_status IS NULL ORDER BY queue_id DESC"
            ##execute sql query on the basic of id, user id, balance, check_balance_status, gift_card_pin and gift_card_no
            cursor.execute(sql)
            check_balance = cursor.fetchall()
            print(check_balance)

            checkbalance_list = []
            for checking in check_balance:
                checkbalanceData = {
                    "id": checking.id,
                    "balance": checking.balance,
                    "value": checking.gift_card_value,
                    "userid": checking.user_id,
                    "giftcardpin": checking.gift_card_pin,
                    "giftcardno": checking.gift_card_no,
                    "retailer": checking.retailer,
                    "status": checking.status,
                    "batch_id": checking.batch_id
                }
                checkbalance_list.append(checkbalanceData)
            return jsonify({"code": 200, "data": {'checkbalance_list': checkbalance_list}})
        except Exception as e:
            print(e)
            return jsonify({"error": {"code": 404, "message": str(e)}})


class NewgiftCardQueue(Resource):
    # api for check balance when new giftcard is sent by the Shi
    def get(self):
        try:
            # initializing cursor ..
            cursor = condb.cursor()
            # sql query for getting data from the checkingqueue table if checkbalance is null
            # sql = "SELECT TOP 5 [id], [balance], [userid], [check_balance_status], [gift_card_pin], [gift_card_no],[retailler] FROM [dbo].[giftcardlist] WHERE [dbo].[giftcardlist].check_balance_status IS NULL AND (retailler !='Amazon' AND retailler !='Toys R Us' AND retailler !='B&N' AND retailler !='Office Max')"
            sql = "SELECT [id], [balance], [gift_card_value], [user_id], [check_balance_status], [gift_card_pin], [gift_card_no],[retailer], [status], [batch_id] FROM [dbo].[giftcardlist] WHERE [dbo].[giftcardlist].check_balance_status IS NULL AND (retailer ='Best Buy') AND (status = 'New')"
            ##execute sql query on the basic of id, user id, balance, check_balance_status, gift_card_pin and gift_card_no
            cursor.execute(sql)
            check_balance = cursor.fetchall()
            print(check_balance)

            checkbalance_list = []
            for checking in check_balance:
                checkbalanceData = {
                    "id": checking.id,
                    "balance": checking.balance,
                    "value": checking.gift_card_value,
                    "userid": checking.user_id,
                    "giftcardpin": checking.gift_card_pin,
                    "giftcardno": checking.gift_card_no,
                    "retailer": checking.retailer,
                    "status": checking.status,
                    "batch_id": checking.batch_id
                }
                checkbalance_list.append(checkbalanceData)
            return jsonify(
                {"code": 200, "data": {'checkbalance_list': checkbalance_list}, 'total_record': len(checkbalance_list)})
        except Exception as e:
            print(e)
            return jsonify({"error": {"code": 404, "message": str(e)}})

    # api for updating balance and status of the new gift-card
    def post(self):
        try:
            # initializing cursor
            cursor = condb.cursor()
            # getting updating data like userid, balance, status in json format
            updated_data = request.get_json()
            print(updated_data)
            # checking weather updated_data is not empty
            if len(updated_data) != 0:
                giftCardNo = updated_data['giftcardno'].strip()
                json_balance = updated_data['balance'].strip()
                json_status = updated_data['status'].strip()

                if giftCardNo and json_balance and json_status:
                    # sql query for updating data on the database --> balance and status
                    sql = "UPDATE [dbo].[giftcardlist] SET [balance] = ?, [last_check] = ?, [status] = ?, [check_balance_status] = ?, [last_used] = ? WHERE [dbo].[giftcardlist].[gift_card_no]=?"
                    val = (json_balance, datetime.datetime.now(), json_status, 'checked', None, giftCardNo)
                    # execute sql query on the basic of user id, balance and status
                    cursor.execute(sql, val)
                    # committing data on the database
                    cursor.commit()

                    return jsonify({"code": 200, "success": "true"})
                else:
                    return jsonify(
                        {"error": {"code": 404, "message": {"Invalid Params": "UserID or Balance or Status"}}})
            else:
                return jsonify({"error": {"code": 404, "message": {"Parameter Not Found": updated_data}}})
        except KeyError as e:
            print(e)
            return jsonify({"error": {"code": 404, "message": f"Parameter Missing:{str(e)}"}})
        except Exception as e:
            print(e)
            return jsonify({"error": {"code": 404, "message": str(e)}})


class CatalogueBuy(Resource):
    def get(self):
        try:
            cursor = condb.cursor()
            rows, page, days = 1, 1, 1
            if 'rows' in request.args:
                try:
                    rows = int(request.args['rows'])
                except:
                    return jsonify({"error": {"code": 404, "message":"Invalid input, Please use numeric fields for rows."}})
            if 'page' in request.args:
                try:
                    page = int(request.args['page'])
                except:
                    return jsonify({"error": {"code": 404, "message":"Invalid input, Please use numeric fields for pages."}})
            if 'new' in request.args:
                try:
                    days = int(request.args['new'])
                except:
                    return jsonify({"error": {"code": 404, "message":"Invalid input, Please use numeric fields for new."}})
                sql = "DECLARE @PageNumber AS INT, @RowsOfPage AS INT SET @PageNumber = {0} SET @RowsOfPage = {1} SELECT id, sku, available, product_name FROM [bestbuymaster].[dbo].[buycatalogue] WHERE (Date_creation >= DATEADD(day,-{2}, GETDATE())) ORDER BY available DESC, profit DESC, Date_creation DESC OFFSET ((@PageNumber - 1) * @RowsOfPage) ROWS FETCH NEXT @RowsOfPage ROWS ONLY;".format(
                     page, rows, days)
                print(sql)
                cursor.execute(sql)
                sku_data = cursor.fetchall()
                json_data = []
                for data in sku_data:
                    sku_dict = {}
                    sku_dict['sku'] = data.sku
                    sku_dict['id'] = data.id
                    sku_dict['availability'] = data.available
                    sku_dict['name'] = data.product_name
                    json_data.append(sku_dict)
                sql = "DECLARE @RowsOfPage AS INT SET @RowsOfPage = {0} SELECT CEILING(COUNT(*)/@RowsOfPage) as total_pages, COUNT(*) as total_record FROM [dbo].[buycatalogue] WHERE (Date_creation >= DATEADD(day,-{1}, GETDATE()))".format(
                    rows, days)
                cursor.execute(sql)
                tableData = cursor.fetchone()
                total_pages, total_records = 0, 0
                if tableData:
                    total_pages = tableData[0]
                    total_records = tableData[1]
                return jsonify({"success": {"code": 200, "data": json_data, "total_pages": total_pages,
                                            "current_page": page, "current_records": len(sku_data),
                                            "total_records": total_records}})
            sql = "DECLARE @PageNumber AS INT, @RowsOfPage AS INT SET @PageNumber = {0} SET @RowsOfPage = {1} SELECT id, sku, available, product_name FROM [bestbuymaster].[dbo].[buycatalogue] ORDER BY available DESC, profit DESC, Date_creation DESC OFFSET ((@PageNumber - 1) * @RowsOfPage) ROWS FETCH NEXT @RowsOfPage ROWS ONLY;".format(page, rows)
            print(sql)
            cursor.execute(sql)
            sku_data = cursor.fetchall()
            json_data = []
            for data in sku_data:
                sku_dict = {}
                sku_dict['sku'] = data.sku
                sku_dict['id'] = data.id
                sku_dict['availability'] = data.available
                sku_dict['name'] = data.product_name
                json_data.append(sku_dict)
            sql = "DECLARE @RowsOfPage AS INT SET @RowsOfPage = {0} SELECT CEILING(COUNT(*)/@RowsOfPage) as total_pages, COUNT(*) as total_record FROM [dbo].[buycatalogue]".format(rows)
            cursor.execute(sql)
            tableData = cursor.fetchone()
            total_pages, total_records = 0, 0
            if tableData:
                total_pages = tableData[0]
                total_records = tableData[1]
            return jsonify({"success": {"code": 200, "data": json_data, "total_pages":total_pages, "current_page":page, "current_records": len(sku_data), "total_records": total_records}})
        except Exception as e:
            return jsonify({"error": {"code": 404, "error_message":str(e), "basic_tips":"/buycatalogue?rows=100&page=1"}})

    # api for check
    def post(self):
        try:
            cursor = condb.cursor()
            # getting updating data like userid, balance, status in json format
            response = request.get_json()
            sku_id, product_name, brand_name, short_desc, long_desc, url_info = None, None, None, None, None, None
            image_url, modal_no, upc, sale_price, regular_price, category, sub_category = None, None, None, None, None, None, None
            available, user_id, company_id = 0, 1, 1
            dollar_saving, percent_saving, amazonPriceHistory = 0, 0, 0
            referal_fee, FBA_fee, amazon_price, buybox = 0, 0, 0, 0
            asin, amazonSR, amazonSRHistory = None, None, None
            if 'sku' in response:
                sku_id = response['sku']
                if sku_id:
                    sku_id = str(sku_id).replace(" ", "")
                    sku_id = str(sku_id).strip()
            if 'image' in response:
                image_url = response['image']
            if 'modelNumber' in response:
                modal_no = response['modelNumber']
            if 'upc' in response:
                upc = response['upc']
            if 'url' in response:
                url_info = response['url']
            if 'salePrice' in response:
                sale_price = response['salePrice']
            if 'regularPrice' in response:
                regular_price = response['regularPrice']
            if 'name' in response:
                product_name = response['name']
                if product_name:
                    product_name = str(product_name).replace('\n', ' ').replace('\t', ' ').strip(' ')
            if 'manufacturer' in response:
                brand_name = response['manufacturer']
            if 'shortDescription' in response:
                short_desc = response['shortDescription']
            if 'longDescription' in response:
                long_desc = response['longDescription']
            if 'dollarSavings' in response:
                dollar_saving = response['dollarSavings']
            if 'percentSavings' in response:
                percent_saving = response['percentSavings']
            if 'referalFee' in response:
                referal_fee = response['referalFee'] if response['referalFee'] else 0
            if 'FBAFee' in response:
                FBA_fee = response['FBAFee'] if response['FBAFee'] else 0
            if 'amazonPrice' in response:
                amazon_price = response['amazonPrice'] if response['amazonPrice'] else 0
            if 'buybox' in response:
                buybox = response['buybox'] if response['buybox'] else 0
            if 'asin' in response:
                asin = response['asin'] if response['asin'] else None
            if 'amazonSR' in response:
                amazonSR = response['amazonSR'] if response['amazonSR'] else None
            if 'amazonSR30Days' in response:
                amazonSRHistory = response['amazonSR30Days'] if response['amazonSR30Days'] else None
            if 'amazonPrice90Days' in response:
                amazonPriceHistory = response['amazonPrice90Days'] if response['amazonPrice90Days'] else 0
            if 'onlineAvailability' in response:
                available = 1 if response['onlineAvailability'] else 0
            if 'categoryPath' in response:
                category_path = response['categoryPath']
                if len(category_path) != 0:
                    category = category_path[1]['name']
                    sub_category = category_path[-1]['name']

            if 'userid' in response:
                sql = "SELECT [id], [companyid] FROM [dbo].[usermaster] WHERE [dbo].[usermaster].id=?"
                cursor.execute(sql, response['userid'])
                userid = cursor.fetchall()
                # Checking registered user id exist or not
                if len(userid) != 0:
                    user_id = userid[0][0]
                    company_id = userid[0][1]
            if sku_id != None and sku_id != '' and product_name != None and product_name != '':
                sql = "SELECT sku, sale_price, amazon_price, FBA_fee, referal_fee FROM [dbo].[buycatalogue] WHERE sku = ?"
                cursor.execute(sql, sku_id)
                sku_data = cursor.fetchall()
                # print(sku_data)
                if len(sku_data) == 0:
                    sql = "INSERT INTO [dbo].[buycatalogue] (user_id, company_id, image_url, modal_no, sku, upc, sale_price, regular_price, product_name, available, brand_name, short_desc, long_desc, category, sub_category, dollersave, percentsave, url_info, referal_fee, amazon_price, buybox, FBA_fee, asin, amazon_sale_rank, amazon_price_history, amazon_sale_rank_history, Date_creation) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);"
                    val = [user_id, company_id, image_url, modal_no, sku_id, upc, sale_price,
                           regular_price, product_name, available, brand_name,
                           short_desc, long_desc, category, sub_category,
                           dollar_saving, percent_saving, url_info,
                           referal_fee, amazon_price, buybox, FBA_fee,
                           asin, amazonSR, amazonPriceHistory,
                           amazonSRHistory, datetime.datetime.now()]
                    cursor.execute(sql, val)
                    cursor.commit()
                    if insert_status > 0:
                        return jsonify(
                            {"success": {"code": 200, "message": str("Catalogue information successfully inserted")}})
                else:
                    sql = "UPDATE [dbo].[buycatalogue] SET was_price=sale_price WHERE sku=?;"
                    val = (sku_id)
                    cursor.execute(sql, val)
                    cursor.commit()
                    sale_price_1 = sku_data[0][1]
                    amazon_price_1 = sku_data[0][2]
                    fba_fee_1 = sku_data[0][3]
                    referal_fee_1 = sku_data[0][4]
                    amazon_price_int = int(float(amazon_price_1))
                    profit_amt, profit_percent = 0, 0
                    if amazon_price_int != None:
                        sale_price_profit_amt = float(sale_price_1) + float(referal_fee_1) + float(fba_fee_1)
                        profit_amt = round((float(amazon_price_1) - float(sale_price_profit_amt)), 2)
                        profit_percent = round(((float(profit_amt) / float(sale_price_1)) * 100), 2)
                        sql = "UPDATE [dbo].[buycatalogue] SET profit=?, profit_amt=? WHERE sku=?;"
                        val = [profit_percent, profit_amt, sku_id]
                        cursor.execute(sql, val)
                        cursor.commit()

                    update_field = {}
                    update_field['image_url'] = 'image_url'
                    update_field['modal_no'] = 'modal_no'
                    update_field['upc'] = 'upc'
                    update_field['sale_price'] = 'sale_price'
                    update_field['regular_price'] = 'regular_price'
                    update_field['product_name'] = 'product_name'
                    update_field['available'] = 'available'
                    update_field['short_desc'] = 'short_desc'
                    update_field['long_desc'] = 'long_desc'
                    update_field['category'] = 'category'
                    update_field['sub_category'] = 'sub_category'
                    update_field['dollar_saving'] = 'dollersave'
                    update_field['percent_saving'] = 'percentsave'
                    update_field['url_info'] = 'url_info'
                    update_field['amazon_price'] = 'amazon_price'
                    update_field['buybox'] = 'buybox'
                    update_field['referal_fee'] = 'referal_fee'
                    update_field['FBA_fee'] = 'FBA_fee'
                    update_field['asin'] = 'asin'
                    update_field['amazonSR'] = 'amazon_sale_rank'
                    update_field['amazonPriceHistory'] = 'amazon_price_history'
                    update_field['amazonSRHistory'] = 'amazon_sale_rank_history'
                    for key, value in update_field.items():
                        if key == 'image_url':
                            if image_url != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [image_url, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'modal_no':
                            if modal_no != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [modal_no, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'upc':
                            if upc != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [upc, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'product_name':
                            if product_name != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [product_name, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'regular_price':
                            if regular_price != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [regular_price, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'available':
                            if available != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [available, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'short_desc':
                            if short_desc != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [short_desc, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'long_desc':
                            if long_desc != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [long_desc, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'category':
                            if category != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [category, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'sub_category':
                            if sub_category != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [sub_category, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'dollar_saving':
                            if dollar_saving != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [dollar_saving, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'percent_saving':
                            if percent_saving != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [percent_saving, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'url_info':
                            if url_info != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [url_info, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'amazon_price':
                            if amazon_price != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [amazon_price, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'buybox':
                            if buybox != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [buybox, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'FBA_fee':
                            if FBA_fee != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [FBA_fee, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'referal_fee':
                            if referal_fee != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [referal_fee, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'asin':
                            if asin != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [asin, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'amazonSR':
                            if amazonSR != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [amazonSR, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'amazonPriceHistory':
                            if amazonPriceHistory != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [amazonPriceHistory, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'amazonSRHistory':
                            if amazonSRHistory != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [amazonSRHistory, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()
                        elif key == 'sale_price':
                            if sale_price != None:
                                sql = "UPDATE [dbo].[buycatalogue] SET {}=? WHERE sku=?;".format(
                                    value)
                                val = [sale_price, sku_id]
                                cursor.execute(sql, val)
                                cursor.commit()

                    sql = 'UPDATE [dbo].[buycatalogue] SET Date_modify=? WHERE sku=?'
                    val = [datetime.datetime.now(), sku_id]
                    cursor.execute(sql, val)
                    cursor.commit()
                    return jsonify(
                        {"success": {"code": 201, "message": str("Catalogue information successfully updated")}})
            else:
                return jsonify(
                    {"error": {"code": 403, "message": str("Sku number or product name is must be required.")}})
        except Exception as e:
            print(e)
            return jsonify({"error": {"code": 404, "message": str(e)}})


class CatalogueData(Resource):
    def get(self):
        cursor = condb.cursor()
        sql = "SELECT sku, id, sale_price, regular_price, was_price, watch_price, amazon_price, referal_fee, FBA_fee, available, asin, amazon_sale_rank, amazon_price_history, amazon_sale_rank_history FROM [dbo].[buycatalogue] WHERE watch_price>0 order by Date_modify desc"
        cursor.execute(sql)
        sku_data = cursor.fetchall()
        json_data = []
        for data in sku_data:
            sku_dict = {}
            sku_dict['sku'] = data.sku
            sku_dict['id'] = data.id
            sku_dict['salePrice'] = data.sale_price
            sku_dict['regularPrice'] = data.regular_price
            sku_dict['wasPrice'] = data.was_price
            sku_dict['watchPrice'] = data.watch_price
            sku_dict['amazonPrice'] = data.amazon_price
            sku_dict['referalFee'] = data.referal_fee
            sku_dict['FBAFee'] = data.FBA_fee
            sku_dict['onlineAvailability'] = data.available
            sku_dict['asin'] = data.asin
            sku_dict['amazonSR'] = data.amazon_sale_rank
            sku_dict['amazonSR30Days'] = data.amazon_sale_rank_history
            sku_dict['amazonPrice90Days'] = data.amazon_price_history
            json_data.append(sku_dict)
        return jsonify({"success": {"code": 200, "data": json_data, "total_items": len(sku_data)}})

    def post(self):
        try:
            cursor = condb.cursor()
            data = request.json
            id, sku_id, work = None, None, None
            regularPrice, salePrice, availability, dollar_saving, percent_saving = 0, 0, 0, 0, 0
            if 'id' in data:
                id = data['id']
            if 'sku' in data:
                sku_id = data['sku']
            if 'regularPrice' in data:
                regularPrice = data['regularPrice']
            if 'salePrice' in data:
                salePrice = data['salePrice']
            if 'onlineAvailability' in data:
                availability = 1 if data['onlineAvailability'] else 0
            if 'dollarSavings' in data:
                dollar_saving = data['dollarSavings']
            if 'percentSavings' in data:
                percent_saving = data['percentSavings']
            if 'work' in data:
                work = data['work']
                if work == 'byid':
                    work = "id = '"+str(id)+"'"
                elif work == 'bysku':
                    work = "sku = '"+str(sku_id)+"'"
                else:
                    return jsonify({"error": {"code": 404, "data": "Please use work - bysku or byid"}})
            else:
                return jsonify({"error": {"code": 404, "data": "Please use work - bysku or byid"}})
            sql = "UPDATE [dbo].[buycatalogue] SET regular_price=?, sale_price=?, available=?, dollersave=?, percentsave=? WHERE {0}".format(work)
            val = [regularPrice, salePrice, availability, dollar_saving, percent_saving]
            cursor.execute(sql, val)
            cursor.commit()

            sql = "SELECT sku, sale_price, amazon_price, FBA_fee, referal_fee FROM [dbo].[buycatalogue] WHERE {0}".format(work)
            cursor.execute(sql)
            sku_data = cursor.fetchone()
            if sku_data != None:
                sql = "UPDATE [dbo].[buycatalogue] SET was_price=sale_price WHERE {0}".format(work)
                cursor.execute(sql)
                cursor.commit()
                sale_price_1 = sku_data[1]
                amazon_price_1 = sku_data[2]
                fba_fee_1 = sku_data[3]
                referal_fee_1 = sku_data[4]
                amazon_price_int = int(float(amazon_price_1))
                profit_amt, profit_percent = 0, 0
                if amazon_price_int != None:
                    sale_price_profit_amt = float(sale_price_1) + float(referal_fee_1) + float(fba_fee_1)
                    profit_amt = round((float(amazon_price_1) - float(sale_price_profit_amt)), 2)
                    profit_percent = round(((float(profit_amt) / float(sale_price_1)) * 100), 2)
                    sql = "UPDATE [dbo].[buycatalogue] SET profit=?, profit_amt=? WHERE {0}".format(work)
                    val = [profit_percent, profit_amt]
                    cursor.execute(sql, val)
                    cursor.commit()

                return jsonify({"success": {"code": 201, "message": "Information updated", "success": True}})
            else:
                return jsonify({"error": {"code": 404, "message": "Sku not available."}})
        except Exception as e:
            return jsonify({"error": {"code": 404, "message": str(e)}})


class CatalogAmazonFieldsUpdate(Resource):
    def post(self):
        try:
            cursor = condb.cursor()
            data = request.json
            amazonPriceHistory = 0
            id, sku_id, work = None, None, None
            referal_fee, FBA_fee, amazon_price, buybox = None, None, None, None
            asin, amazonSR, amazonSRHistory = None, None, None
            if 'id' in data:
                id = data['id']
            if 'sku' in data:
                sku_id = data['sku']
            if 'referalFee' in data:
                referal_fee = data['referalFee'] if data['referalFee'] else 0
            if 'FBAFee' in data:
                FBA_fee = data['FBAFee'] if data['FBAFee'] else 0
            if 'amazonPrice' in data:
                amazon_price = data['amazonPrice'] if data['amazonPrice'] else 0
            if 'buybox' in data:
                buybox = data['buybox'] if data['buybox'] else 0
            if 'asin' in data:
                asin = data['asin'] if data['asin'] else None
            if 'amazonSR' in data:
                amazonSR = data['amazonSR'] if data['amazonSR'] else None
            if 'amazonSR30Days' in data:
                amazonSRHistory = data['amazonSR30Days'] if data['amazonSR30Days'] else None
            if 'amazonPrice90Days' in data:
                amazonPriceHistory = data['amazonPrice90Days'] if data['amazonPrice90Days'] else 0
            if 'work' in data:
                work = data['work']
                if work == 'byid':
                    work = "id = '" + str(id) + "'"
                elif work == 'bysku':
                    work = "sku = '" + str(sku_id) + "'"
                else:
                    return jsonify({"error": {"code": 404, "data": "Please use work - bysku or byid"}})
            else:
                return jsonify({"error": {"code": 404, "data": "Please use work - bysku or byid"}})
            if referal_fee is not None:
                sql = "UPDATE [dbo].[buycatalogue] SET referal_fee=? WHERE {0}".format(work)
                val = [referal_fee]
                cursor.execute(sql, val)
                cursor.commit()
            if FBA_fee is not None:
                sql = "UPDATE [dbo].[buycatalogue] SET FBA_fee=? WHERE {0}".format(work)
                val = [FBA_fee]
                cursor.execute(sql, val)
                cursor.commit()
            if amazon_price is not None:
                sql = "UPDATE [dbo].[buycatalogue] SET amazon_price=? WHERE {0}".format(work)
                val = [amazon_price]
                cursor.execute(sql, val)
                cursor.commit()
            if buybox is not None:
                sql = "UPDATE [dbo].[buycatalogue] SET buybox=? WHERE {0}".format(work)
                val = [buybox]
                cursor.execute(sql, val)
                cursor.commit()
            if asin is not None:
                sql = "UPDATE [dbo].[buycatalogue] SET asin=? WHERE {0}".format(work)
                val = [asin]
                cursor.execute(sql, val)
                cursor.commit()
            if amazonSR is not None:
                sql = "UPDATE [dbo].[buycatalogue] SET amazon_sale_rank=? WHERE {0}".format(work)
                val = [amazonSR]
                cursor.execute(sql, val)
                cursor.commit()
            if amazonSRHistory is not None:
                sql = "UPDATE [dbo].[buycatalogue] SET amazon_sale_rank_history=? WHERE {0}".format(work)
                val = [amazonSRHistory]
                cursor.execute(sql, val)
                cursor.commit()
            if amazonPriceHistory is not None:
                sql = "UPDATE [dbo].[buycatalogue] SET amazon_price_history=? WHERE {0}".format(work)
                val = [amazonPriceHistory]
                cursor.execute(sql, val)
                cursor.commit()
            sql = "SELECT sku, sale_price, amazon_price, FBA_fee, referal_fee FROM [dbo].[buycatalogue] WHERE {0}".format(
                work)
            cursor.execute(sql)
            sku_data = cursor.fetchone()
            if sku_data != None:
                sql = "UPDATE [dbo].[buycatalogue] SET was_price=sale_price WHERE {0}".format(work)
                cursor.execute(sql)
                cursor.commit()
                sale_price_1 = sku_data[1]
                amazon_price_1 = sku_data[2]
                fba_fee_1 = sku_data[3]
                referal_fee_1 = sku_data[4]
                amazon_price_int = int(float(amazon_price_1))
                profit_amt, profit_percent = 0, 0
                if amazon_price_int != None:
                    sale_price_profit_amt = float(sale_price_1) + float(referal_fee_1) + float(fba_fee_1)
                    profit_amt = round((float(amazon_price_1) - float(sale_price_profit_amt)), 2)
                    profit_percent = round(((float(profit_amt) / float(sale_price_1)) * 100), 2)
                    sql = "UPDATE [dbo].[buycatalogue] SET profit=?, profit_amt=? WHERE {0}".format(work)
                    val = [profit_percent, profit_amt]
                    cursor.execute(sql, val)
                    cursor.commit()

                return jsonify({"success": {"code": 201, "message": "Information updated for amazon", "success": True}})
            else:
                return jsonify({"error": {"code": 404, "message": "Sku not available."}})
        except Exception as e:
            return jsonify({"error": {"code": 404, "message": str(e)}})


def cancelledOrderForCheckingQueueGC(order_no=None, status=None):
    cursor = condb.cursor()
    status_count = 0
    sql = "SELECT giftcard_number FROM [dbo].[giftcardtransaction] WHERE ordernumber=? and action_type is null"
    val = (order_no)
    cursor.execute(sql, val)
    giftcard_data = cursor.fetchall()
    if len(giftcard_data)!=0:
        sql = "UPDATE [dbo].[giftcardtransaction] SET order_purchase_status = ?, check_balance = 1  WHERE [dbo].[giftcardtransaction].ordernumber=? and action_type is null"
        # execute sql query
        val = (status, order_no)
        cursor.execute(sql, val)
        # committing data on the database
        cursor.commit()

        sql = "SELECT Max(queue_id) FROM [dbo].[giftcardlist]"
        cursor.execute(sql)
        data = cursor.fetchall()
        queue_id = data[0][0]
        queue_id = queue_id + 1 if queue_id else 1

        for gc_number in giftcard_data:
            sql = "UPDATE [dbo].[giftcardlist] SET [queue_status] = ?, [queue_date] = ?, [queue_id] = ?, [check_balance_status] = ? WHERE [gift_card_no]=?"
            val = ("que", datetime.datetime.now(), queue_id, None, gc_number.giftcard_number)
            cursor.execute(sql, val)
            cursor.commit()
            status_count += cursor.rowcount
    return {'status':status_count}


class SeleniumOrderData(Resource):
    def post(self):
        try:
            cursor = condb.cursor()
            data = request.json
            path = app.root_path
            details = order_status(data, path)
            order_number = data['order_number']
            # details = {'order_number': 'BBY01-806453163144', 'order_total': 489.98, 'products_total': 459.54, 'order_taxes': 30.44, 'shipping': 'FREE', 'items': [{'tracking_status': 'Delivered', 'tracking_number': '1ZW490240357589184', 'carrier_name': 'UPS', 'sku_no': [{'sku': '6394950', 'qty': '46', 'item_total': '489.98', 'item_price': ' 459.54', 'item_tax': ' 30.44'}]}]}
            roucount = 0
            tracking_status, tracking_number, carrier_name, sku_number, ordered_status = None, None, None, None, None
            order_total, products_total, order_taxes, shipping, total_qty = 0, 0, 0, 0, 0
            combine_details = []
            item_sku_qty = {}
            status_set = set()

            if 'items' in details:
                if 'order_total' in details:
                    try:
                        order_total = float(details['order_total'])
                    except:
                        pass
                if 'products_total' in details:
                    try:
                        products_total = float(details['products_total'])
                    except:
                        pass
                if 'order_taxes' in details:
                    try:
                        order_taxes = float(details['order_taxes'])
                    except:
                        pass
                if 'shipping' in details:
                    try:
                        shipping = float(details['shipping'])
                    except:
                        pass
                items = details['items']
                sku_no_check = ""
                for order_data in items:
                    if 'tracking_status' in order_data:
                        tracking_status = order_data['tracking_status']
                        if tracking_status:
                            tracking_status = str(tracking_status).strip()
                            tracking_status = tracking_status.title()
                        if tracking_status == 'Canceled':
                            tracking_status = 'Cancelled'
                        elif 'Arriving' in tracking_status:
                            tracking_status = 'Ordered'
                        elif 'Order' in tracking_status:
                            tracking_status = 'Ordered'
                        status_set.add(tracking_status)
                    if 'tracking_number' in order_data:
                        tracking_number = order_data['tracking_number']
                    if 'carrier_name' in order_data:
                        carrier_name = order_data['carrier_name']
                    if 'sku_no' in order_data:
                        for sku in order_data['sku_no']:
                            sku_data = {}
                            if sku['sku']:
                                if sku_no_check != sku['sku']:
                                    sku_no_check = sku['sku']
                                    total_qty = 0
                                try:
                                    qty = int(float(sku['qty']))
                                    total_qty += qty
                                    item_sku_qty[sku_no_check] = total_qty
                                except:
                                    qty = 0
                                try:
                                    price = float(sku['item_price'])
                                except:
                                    price = 0
                                sku_data['sku'] = sku['sku']
                                sku_data['qty'] = qty
                                sku_data['price'] = price
                                sku_data['order_number'] = order_number
                                sku_data['total_cost'] = products_total
                                sku_data['sub_total'] = order_total
                                sku_data['tax'] = order_taxes
                                sku_data['shipping'] = shipping
                                sku_data['tracking_status'] = tracking_status
                                sku_data['tracking_number'] = tracking_number
                                sku_data['carrier'] = carrier_name
                                sku_data['operation'] = True
                                combine_details.append(sku_data)

                print(combine_details)
                print(item_sku_qty)
                sql = "SELECT * FROM [dbo].[ordertracking] WHERE order_number=?"
                val = [order_number]
                cursor.execute(sql, val)
                order_tracking_detail = cursor.fetchall()
                if len(order_tracking_detail) < len(combine_details):
                    insert_record = len(combine_details) - len(order_tracking_detail)
                    item_sku, price, qty_cart, user_id, company_id, cart_id, address_id, email_id = None, None, None, None, None, None, None, None
                    vendor, retailer, title, cart_total, payment_type, order_number, tracking_status = None, None, None, None, None, None, None
                    tracking_number, phone, discount_cost, tax_cost, subtotal, shipping_cost, carrier = None, None, None, None, None, None, None
                    no_of_gc, no_of_item, orderedDate, fullname = None, None, None, None
                    for ot_detail in order_tracking_detail:
                        item_sku = ot_detail.item_sku
                        price = ot_detail.price
                        qty_cart = ot_detail.qty_cart
                        user_id = ot_detail.user_id
                        company_id = ot_detail.company_id
                        cart_id = ot_detail.cart_id
                        address_id = ot_detail.address_id
                        email_id = ot_detail.email_id
                        vendor = ot_detail.vendor
                        retailer = ot_detail.retailer
                        title = ot_detail.title
                        cart_total = ot_detail.cart_total
                        payment_type = ot_detail.payment_type
                        order_number = ot_detail.order_number
                        tracking_status = ot_detail.tracking_status
                        tracking_number = ot_detail.tracking_number
                        phone = ot_detail.phone
                        discount_cost = ot_detail.discount_cost
                        tax_cost = ot_detail.tax_cost
                        subtotal = ot_detail.subtotal
                        shipping_cost = ot_detail.shipping_cost
                        carrier = ot_detail.carrier
                        no_of_gc = ot_detail.no_of_gc
                        no_of_item = ot_detail.no_of_item
                        orderedDate = ot_detail.orderedDate
                        fullname = ot_detail.fullname
                        for cds in combine_details:
                            if item_sku == cds['sku']:
                                if item_sku == cds['sku'] and qty_cart == cds['qty'] and cds['operation']:
                                    sql = "UPDATE [dbo].[ordertracking] SET [qty_cart]=?, [tracking_status] = ?, [tracking_number] = ?, [carrier] = ?, [Date_modify] = ? WHERE [order_number] = ? and [item_sku] = ? and [qty_cart]=?"
                                    val = [cds['qty'], cds['tracking_status'], cds['tracking_number'], cds['carrier'],
                                           datetime.datetime.now(),
                                           cds['order_number'], cds['sku'], qty_cart]
                                    cursor.execute(sql, val)
                                    cursor.commit()
                                    cds['operation'] = False
                                    roucount += cursor.rowcount
                                elif insert_record > 0 and cds['operation']:
                                    sql = "INSERT INTO [dbo].[ordertracking] (user_id, company_id, vendor, fullname, item_sku, qty_cart, title, tracking_status, carrier, tracking_number, price, cart_total, payment_type, retailer, order_number, tax_cost, subtotal, shipping_cost, cart_id, address_id, email_id, phone, no_of_gc, no_of_item, orderedDate, Date_creation) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);"
                                    val = [user_id, company_id, vendor, fullname, cds['sku'], cds['qty'], title,
                                           cds['tracking_status'], cds['carrier'], cds['tracking_number'],
                                           price, cds['total_cost'], payment_type, retailer, cds['order_number'],
                                           cds['tax'], cds['sub_total'], cds['shipping'],
                                           cart_id, address_id, email_id,
                                           phone, no_of_gc, no_of_item, orderedDate,
                                           datetime.datetime.now()]
                                    cursor.execute(sql, val)
                                    cursor.commit()
                                    cds['operation'] = False
                                    roucount += cursor.rowcount
                                    insert_record = insert_record - 1
                                elif item_sku == cds['sku'] and qty_cart != cds['qty'] and cds['operation']:
                                    if cds['qty'] != 0:
                                        sql = "UPDATE [dbo].[ordertracking] SET [qty_cart]=?, [tracking_status] = ?, [tracking_number] = ?, [carrier] = ?, [Date_modify] = ? WHERE [order_number] = ? and [item_sku] = ? and [qty_cart]=?"
                                        val = [cds['qty'], cds['tracking_status'], cds['tracking_number'], cds['carrier'],
                                               datetime.datetime.now(),
                                               cds['order_number'], cds['sku'], qty_cart]
                                    else:
                                        sql = "UPDATE [dbo].[ordertracking] SET [tracking_status] = ?, [tracking_number] = ?, [carrier] = ?, [Date_modify] = ? WHERE [order_number] = ? and [item_sku] = ?"
                                        val = [cds['tracking_status'], cds['tracking_number'],
                                               cds['carrier'],
                                               datetime.datetime.now(),
                                               cds['order_number'], cds['sku']]
                                    cursor.execute(sql, val)
                                    cursor.commit()
                                    cds['operation'] = False
                                    roucount += cursor.rowcount
                elif len(order_tracking_detail) == len(combine_details):
                    item_sku, qty_cart = None, None
                    for ot_detail in order_tracking_detail:
                        item_sku = ot_detail.item_sku
                        qty_cart = ot_detail.qty_cart
                        for cds in combine_details:
                            if item_sku == cds['sku']:
                                if item_sku == cds['sku'] and qty_cart == cds['qty'] and cds['operation']:
                                    sql = "UPDATE [dbo].[ordertracking] SET [tracking_status] = ?, [tracking_number] = ?, [carrier] = ?, [Date_modify] = ? WHERE [order_number] = ? and [item_sku] = ? and [qty_cart]=?"
                                    val = [cds['tracking_status'], cds['tracking_number'], cds['carrier'],
                                           datetime.datetime.now(),
                                           cds['order_number'], cds['sku'], qty_cart]
                                    cursor.execute(sql, val)
                                    cursor.commit()
                                    cds['operation'] = False
                                    roucount += cursor.rowcount
                                elif item_sku == cds['sku'] and qty_cart != cds['qty'] and cds['operation']:
                                    if cds['qty'] != 0:
                                        sql = "UPDATE [dbo].[ordertracking] SET [qty_cart]=?, [tracking_status] = ?, [tracking_number] = ?, [carrier] = ?, [Date_modify] = ? WHERE [order_number] = ? and [item_sku] = ? and [qty_cart]=?"
                                        val = [cds['qty'], cds['tracking_status'], cds['tracking_number'], cds['carrier'],
                                               datetime.datetime.now(),
                                               cds['order_number'], cds['sku'], qty_cart]
                                    else:
                                        sql = "UPDATE [dbo].[ordertracking] SET [tracking_status] = ?, [tracking_number] = ?, [carrier] = ?, [Date_modify] = ? WHERE [order_number] = ? and [item_sku] = ?"
                                        val = [cds['tracking_status'], cds['tracking_number'],
                                               cds['carrier'],
                                               datetime.datetime.now(),
                                               cds['order_number'], cds['sku']]
                                    cursor.execute(sql, val)
                                    cursor.commit()
                                    cds['operation'] = False
                                    roucount += cursor.rowcount

                ordered_status = ", ".join(list(status_set))
                if roucount > 0:
                    if ordered_status == "Cancelled":
                        status = cancelledOrderForCheckingQueueGC(order_number, ordered_status)
                        print(status)
                    return jsonify({"code": 200, "success": True})
                else:
                    return jsonify({"code": 201, "success": False})
            else:
                return jsonify({"code": 201, "success": False})
        except Exception as e:
            print(e)
            return jsonify({"code": 401, "error": str(e)})


api.add_resource(BuyingInformation, '/buyingninformation')
api.add_resource(SendGiftCardDetails, '/giftcartforbuying')
api.add_resource(ExtraGiftCards, '/moregiftcards')
api.add_resource(BuyingCostFullfilled, '/ordertrackingfullfill')
api.add_resource(UpdateOrderStatus, '/updateorderstatus')
api.add_resource(GetOrderDetail, '/getorderdetail')
api.add_resource(UpdateGiftcardTrasactionStatus, '/updategiftcardtracstatus')
api.add_resource(UpdateGiftCardTrasactionEvent, '/updatetrasactionaction')
api.add_resource(GetContactDetails, '/getcontacts')
api.add_resource(SetContactDetails, '/setcontacts')
api.add_resource(ResetContactUse, '/resetcontacts')
api.add_resource(GiftCardUpdate, '/cardupdate')
api.add_resource(GiftCardQueue, '/cardqueue')
api.add_resource(LockGcUpdate, '/getlockedgc')
api.add_resource(NewgiftCardQueue, '/newcardqueue')
api.add_resource(CatalogueBuy, '/buycatalogue')
api.add_resource(CatalogueData, '/catalogue')
api.add_resource(CatalogAmazonFieldsUpdate, '/catalogue-amazon-update')
api.add_resource(SeleniumOrderData, '/statusdetails')


if __name__ == "__main__":
    app.run(debug = True, port=5001)