from flask import Flask, flash, render_template, request, session, redirect, url_for, make_response, jsonify, send_file, Response
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_static_compress import FlaskStaticCompress
import pyodbc
import pandas as pd
import numpy as np
import os
import json
import names
import re
import logging
from utility import *

app = Flask(__name__)
compress = FlaskStaticCompress(app)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# app.config['SQLALCHEMY_DATABASE_URI'] = "mssql+pyodbc://bestbuy_db:akash$123654@WIN-CCDM0AMH1KS/bestbuymaster?driver=SQL+Server"
app.config['SQLALCHEMY_DATABASE_URI'] = "mssql+pyodbc://DESKTOP-DV8PF1D/bestbuymaster?driver=SQL+Server"
db = SQLAlchemy(app)

condb = pyodbc.connect("Driver={SQL Server};"
                       "Server=DESKTOP-DV8PF1D;"
                       "Database=bestbuymaster;"
                       )
# condb = pyodbc.connect("Driver={SQL Server};"
#                       "Server=WIN-CCDM0AMH1KS;"
#                       "Database=bestbuymaster;"
#                       "uid=bestbuy_db;pwd=akash$123654"
#                        )
print("Connected")
app.secret_key = 'rgrerrrgfgdfge3434fg'

# /log_filename = "logs/bbcrm.log"
# def remove_if_exists(filename):
#   if os.path.exists(filename):
#     os.remove(filename)
# # remove_if_exists(log_filename)
# os.makedirs(os.path.dirname(log_filename), exist_ok=True)
# logging.basicConfig(filename=log_filename, level=logging.INFO, format='%(levelname)s %(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')

# logger = logging.getLogger(log_filename)

companyid = ""
user_role = ""
#cursor = condb.cursor()
############### --------- Login & Index Page-------------  ########################
@app.route('/', methods=['POST', 'GET'])
def login():
    try:
        # initiallizing cursor
        cursor = condb.cursor()
        if request.method == 'POST':
            # getting data from login form
            email = request.form.get('email')
            password = request.form.get('password')
            remember = request.form.get('remember')

            # check whether email & password exist
            sql = "SELECT [id],[businessname],[contactname],[email],[phone],[password],[Date_creation],[Date_modify],[accessid],[companyid],[role],[status] FROM [dbo].[usermaster] WHERE [dbo].[usermaster].[email]=? and [dbo].[usermaster].[password]=?"
            val = [email, password]
            cursor.execute(sql, val)
            user_data = cursor.fetchall()

            # if password & email id exist
            if len(user_data) != 0:
                if user_data[0][11] == 1:
                    user_id = user_data[0][0]
                    user_role = user_data[0][10]
                    username = user_data[0][2]

                    sql = "SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid = ?"
                    cursor.execute(sql, user_id)
                    accessdata = cursor.fetchall()

                    # adding value in session
                    session['email'] = email
                    session['password'] = password
                    session['companyid'] = user_id  # basically companyid is the userMaster_id comes from user master table
                    session['userrole'] = user_role
                    session['username'] = username

                    if remember == 'on':
                        session.permanent = True
                    else:
                        session.permanent = False
                    return render_template('index.html', accessdata=accessdata)
                else:
                    return render_template('login.html', error='Permission Denied')
            else:
                return render_template('login.html', error='Enter Valid Email And Password')

        # this code run when remember me is on
        else:
            # return redirect(url_for('logintest'))
            if 'password' and 'email' in session:
                # getting value from the session
                email = session["email"]
                password = session["password"]

                # check whether email & password exist
                cursor = condb.cursor()
                sql = "SELECT [id],[businessname],[contactname],[email],[phone],[password],[Date_creation],[Date_modify],[accessid],[companyid],[role],[status] FROM [usermaster] WHERE [dbo].[usermaster].[email]=? and [dbo].[usermaster].[password]=?"
                val = [email, password]
                cursor.execute(sql, val)
                user_data = cursor.fetchall()
                # if password & email id exist
                if len(user_data) != 0:
                    if user_data[0][11] == 1:
                        companyid = session["userrole"]
                        cursor = condb.cursor()
                        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid = " + str(companyid))
                        accessdata = cursor.fetchall()
                        return render_template('index.html', accessdata=accessdata)
            return render_template('login.html')
    except Exception as e:
        print(e)
        return render_template('login.html')

@app.route('/logintest', methods=['GET'])
def logintest():

    email = 'admin@gmail.com'
    password = '123456'
    remember = ''

    # check whether email & password exist
    sql = "SELECT [id],[businessname],[contactname],[email],[phone],[password],[Date_creation],[Date_modify],[accessid],[companyid],[role],[status] FROM [dbo].[usermaster] WHERE [dbo].[usermaster].[email]=? and [dbo].[usermaster].[password]=?"
    val = [email, password]
    cursor.execute(sql, val)
    user_data = cursor.fetchall()

    # if password & email id exist
    if len(user_data) != 0:
        if user_data[0][11] == 1:
            user_id = user_data[0][0]
            user_role = user_data[0][10]
            username = user_data[0][2]

            sql = "SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid = ?"
            cursor.execute(sql, user_id)
            accessdata = cursor.fetchall()

            # adding value in session
            session['email'] = email
            session['password'] = password
            session['companyid'] = user_id  # basically companyid is the userMaster_id comes from user master table
            session['userrole'] = user_role
            session['username'] = username

            if remember == 'on':
                session.permanent = True
            else:
                session.permanent = False
            return redirect(url_for('giftcardlist'))
            # return render_template('index.html', accessdata=accessdata)



@app.route('/logout', methods=['POST', 'GET'])
def logout():
    resp = redirect(url_for('login'))
    session.pop('username', None)
    session.pop('companyid', None)
    session.pop('email', None)
    session.pop('password', None)
    session.pop('userrole', None)
    return resp

@app.route('/index', methods=['POST', 'GET'])
def index():
    if 'password' and 'email' in session:
        # global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        return render_template('index.html', accessdata=accessdata)
    else:
        return redirect(url_for('login'))

@app.route('/myaccount', methods=['PUT', 'GET'])
def myaccount():
    global companyid
    companyid = session["companyid"]
    cursor = condb.cursor()
    cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid=" + str(companyid))
    accessdata = cursor.fetchall()
    if request.method == 'PUT':
        content = request.json
        print(content)
        id = content['id']
        confirm_pass = content['conpassword']
        contact_name = content['contactname']
        password = content['password']
        if confirm_pass == password and contact_name != "":
            if len(password) > 3 and len(contact_name) > 3:
                contact_name = str(contact_name).title()
                sql = "UPDATE [dbo].[usermaster] SET password = ?, contactname = ? WHERE id=?"
                val = (password, contact_name, id)
                cursor.execute(sql, val)
                cursor.commit()
                return json.dumps({'code': 200, "column": "Full name and Password Updated."})
            else:
                return json.dumps({'code': 404, "column": "Full name and Password should be more than 4 characters."})
        elif contact_name != "":
            if len(contact_name) > 3:
                contact_name = str(contact_name).title()
                sql = "UPDATE [dbo].[usermaster] SET contactname = ? WHERE id=?"
                val = (contact_name, id)
                cursor.execute(sql, val)
                cursor.commit()
                return json.dumps({'code': 200, "column": "Full name Updated."})
            else:
                return json.dumps({'code': 404, "column": "Full name should be more the 4 characters"})
        else:
            return json.dumps({'code': 404, "column": "Invalid Operation."})
    sql = "SELECT * FROM [dbo].[usermaster] FULL OUTER JOIN [dbo].[accessmaster] ON [dbo].[usermaster].id = [dbo].[accessmaster].userid WHERE [dbo].[usermaster].id=?"
    val = [companyid]
    cursor.execute(sql, val)
    userdata = cursor.fetchall()
    return render_template('myaccount.html', accessdata=accessdata, userdata=userdata)
############### ---------End Login & Index Page-------------  ########################

############### ---------Notification Page-------------  ########################
@app.route('/notification', methods=['POST', 'PUT', 'GET', 'DELETE'])
def notification():
    responsedata = {}
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        if request.method == 'PUT':
            data = request.json
            id = data['id']
            sql = "UPDATE [dbo].[notification] SET seen=0 WHERE id=?"
            cursor.execute(sql, id)
            cursor.commit()
            if cursor.rowcount > 0:
                responsedata['code'] = '200'
            else:
                responsedata['code'] = '404'
            return jsonify(responsedata)
        if request.method == 'POST':
            sql = "UPDATE [dbo].[notification] SET status='View' WHERE status !='Delete'"
            cursor.execute(sql)
            cursor.commit()
            if cursor.rowcount > 0:
                responsedata['code'] = '200'
            else:
                responsedata['code'] = '404'
            return jsonify(responsedata)
        if request.method == 'DELETE':
            sql = "UPDATE [dbo].[notification] SET status='Delete' WHERE status !='Delete'"
            cursor.execute(sql)
            cursor.commit()
            if cursor.rowcount > 0:
                responsedata['code'] = '200'
            else:
                responsedata['code'] = '404'
            return jsonify(responsedata)
        elif request.method == 'GET':
            cursor = condb.cursor()
            sql = "SELECT count(id) as count FROM notification WHERE status='New'"
            cursor.execute(sql)
            notification_count = cursor.fetchall()[0][0]
            sql = "SELECT TOP 10 id, message, order_number, seen FROM [dbo].[notification] WHERE status!='Delete' ORDER BY Date_creation DESC"
            cursor.execute(sql)
            notifications = cursor.fetchall()
            notification_data = []
            for data in notifications:
                tracking_status = None
                image_url = "static/images/notification/All.png"
                sql = "SELECT TOP 1 tracking_status FROM [dbo].[ordertracking] WHERE order_number=?"
                cursor.execute(sql,data.order_number)
                order_status = cursor.fetchone()
                if order_status:
                    tracking_status = order_status.tracking_status
                    if tracking_status == 'Cancelled':
                        image_url = "static/images/notification/Order_Cancelled.png"
                    elif tracking_status == 'Processed':
                        image_url = "static/images/notification/Order_Processed.png"
                    elif tracking_status != 'Processed' and tracking_status != 'Cancelled':
                        image_url = "static/images/notification/Order_Success.png"
                notification = {
                    'Id': data.id,
                    'Message': data.message,
                    'TrackingStatus': tracking_status,
                    'Seen': data.seen,
                    'OrderNo': data.order_number,
                    'ImageUrl': image_url
                }
                notification_data.append(notification)
            responsedata['code'] = '200'
            responsedata['data'] = notification_data
            responsedata['noti_count'] = notification_count
            return jsonify(responsedata)
        else:
            responsedata['code'] = '404'
            responsedata['message'] = 'Invalid Method Type'
            return jsonify(responsedata)
    else:
        responsedata['code'] = '404'
        responsedata['message'] = 'Invalid User Crendential'
        return jsonify(responsedata)

@app.route('/notification-list', methods=['POST', 'PUT', 'GET', 'DELETE'])
def notification_list():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        if request.method == 'POST':
            import datetime
            noti_obj = NotificationList()
            content = request.json
            columns = content['columns']
            offset = content['start']
            length = content['length']
            search = content['search']
            searchbox = search['value'].strip()
            searchbox = "{" if searchbox.startswith("'") else searchbox
            searchbox = "{" if searchbox.startswith("-") else searchbox
            searchbox = "{" if searchbox.startswith(";") else searchbox

            columns_status = columns[3]
            columns_status_search = columns_status['search']['value']
            # print(columns_status_search)
            if columns_status_search == 'Status':
                columns_status_search = ''

            orderable = content['order']
            sorting = ["Date_creation" if orderable[0]['column'] == 1 else (
                "message" if orderable[0]['column'] == 2 else (
                    'status' if orderable[0]['column'] == 3 else (
                    )))]
            direction = orderable[0]['dir']

            columns_date = columns[1]
            columns_date = columns_date['search']['value']
            columns_date_search = ("" if columns_date == "DateRange" else columns_date)

            today = datetime.datetime.now()
            lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
            date1, date2 = (
                (today - datetime.timedelta(days=6)).date(), today.date()) if columns_date_search == 'Last7days' else (
                ((
                         today - datetime.timedelta(
                     days=today.weekday())).date(),
                 today.date()) if columns_date_search == "ThisWeek" else (
                    ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                     lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                        (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                            (today - datetime.timedelta(days=30)).date(),
                            today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                            datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                        datetime.date.strftime(
                                                                                            datetime.datetime.strptime(
                                                                                                columns_date_search[
                                                                                                18:28],
                                                                                                '%m-%d-%Y'),
                                                                                            "%Y-%m-%d")) if len(
                            columns_date_search) == 28 else ("", "")))))


            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            if columns_date_search != "":
                query_shorter.append("CAST([Date_creation] as DATE) between '" + str(
                    date1) + "' and '" + str(
                    date2) + "'")
            if columns_status_search != "":
                query_shorter.append("[status] = '" + str(columns_status_search) + "'")
            if len(searchbox) != 0:
                search_query = "([message] LIKE '{}%' OR CONVERT (varchar(10), Date_creation,110) LIKE '{}%' OR [order_number] LIKE '{}%' OR [status] LIKE '{}%')".format(
                    searchbox, searchbox, searchbox, searchbox)
                query_shorter.append(search_query)
            if len(sorting[0]) != 0:
                custom_sorting = sorting[0]
                custom_direction = direction

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            cursor = condb.cursor()
            sql = noti_obj.notificationqueryforcount(custom_query)
            # print(sql)
            cursor.execute(sql)
            # fetching buying details
            count = cursor.fetchall()
            # print("count", count)
            try:
                no_of_records = count[0][0]
            except Exception as e:
                no_of_records = len(count)
            # print("no_of_records", no_of_records)

            sql = noti_obj.notificationquery(offset, length, custom_query, custom_sorting, custom_direction)
            # print(sql)
            cursor.execute(sql)

            tableData = cursor.fetchall()
            notification_data = []
            for data in tableData:
                noti_data = {
                    'Id': data.id,
                    'Date_creation': data.dateCreation,
                    'Seen': int(data.seen),
                    'Message': data.message,
                    'OrderNumber': data.order_number,
                    'Status': data.status
                }
                notification_data.append(noti_data)
            responsedata = {
                "draw": content['draw'],
                "data": notification_data,
                "recordsTotal": no_of_records,
                "recordsFiltered": no_of_records
            }
            return jsonify(responsedata)
        elif request.method == 'DELETE':
            row_num = request.json['row_num']
            cursor = condb.cursor()
            sql = "DELETE FROM [dbo].[notification] WHERE id=?"
            value = [row_num]
            cursor.execute(sql, value)
            cursor.commit()
            rowcount = cursor.rowcount
            if rowcount > 0:
                return json.dumps({'code': 200, "message": "Deleted."})
            else:
                return json.dumps({'code': 404, "message": "Not Deleted."})
        elif request.method == 'PUT':
            import datetime
            cursor = condb.cursor()
            # getting update data from the tracking page
            updatedData = request.json
            
            newValue = updatedData['newValue']
            # print(newValue)
            parent_id = updatedData['id']
            # print(parent_id)
            columnName = updatedData['cellName']
            # print(columnName)

            # sql query for updating ordertracking status
            sql = "UPDATE [dbo].[notification] SET {}=?, Date_modify=? WHERE [id]= ?".format(
                columnName)
            # execute sql query
            val = (newValue, datetime.datetime.now(), parent_id)
            # execute sql query on the basic of gift_card_no & selected id
            cursor.execute(sql, val)
            # committing data on the database
            cursor.commit()
            rowcount = cursor.rowcount
            if rowcount > 0:
                return json.dumps({'code': 200, "message": "Status updated."})
            else:
                return json.dumps({'code': 404, "message": "Status is not updated."})
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        return render_template('notification.html', accessdata=accessdata)
    else:
        return redirect(url_for('login'))

############### ---------End Notification Page-------------  ########################

############### --------- Emails Page-------------  ########################
@app.route('/email', methods=['POST', 'PUT', 'GET', 'DELETE'])
def emails():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        if request.method == 'POST':
            import datetime
            email_obj = EmailList()
            content = request.json
            columns = content['columns']
            offset = content['start']
            length = content['length']
            search = content['search']
            searchbox = search['value'].strip()
            searchbox = "{" if searchbox.startswith("'") else searchbox
            searchbox = "{" if searchbox.startswith("-") else searchbox
            searchbox = "{" if searchbox.startswith(";") else searchbox

            columns_status = columns[7]
            columns_status_search = columns_status['search']['value']
            # print(columns_status_search)
            if columns_status_search == 'Status':
                columns_status_search = ''

            orderable = content['order']
            sorting = ["max(Date_creation)" if orderable[0]['column'] == 1 else (
                "email" if orderable[0]['column'] == 2 else (
                    'batch_status' if orderable[0]['column'] == 7 else (
                        )))]
            direction = orderable[0]['dir']

            columns_date = columns[1]
            columns_date = columns_date['search']['value']
            columns_date_search = ("" if columns_date == "DateRange" else columns_date)

            today = datetime.datetime.now()
            lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
            date1, date2 = (
                (today - datetime.timedelta(days=6)).date(), today.date()) if columns_date_search == 'Last7days' else (
                ((
                         today - datetime.timedelta(
                     days=today.weekday())).date(),
                 today.date()) if columns_date_search == "ThisWeek" else (
                    ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                     lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                        (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                            (today - datetime.timedelta(days=30)).date(),
                            today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                            datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                        datetime.date.strftime(
                                                                                            datetime.datetime.strptime(
                                                                                                columns_date_search[
                                                                                                18:28],
                                                                                                '%m-%d-%Y'),
                                                                                            "%Y-%m-%d")) if len(
                            columns_date_search) == 28 else ("", "")))))
            # date1 = str(date1)
            # date2 = str(date2)
            # print(date1, date2)

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            if columns_date_search != "":
                query_shorter.append("CAST([Date_creation] as DATE) between '" + str(
                    date1) + "' and '" + str(
                    date2) + "'")
            if columns_status_search != "":
                query_shorter.append("[emailmaster].[batch_status] = '" + str(columns_status_search) + "'")
            if len(searchbox) != 0:
                search_query = "([email] LIKE '{}%' OR CONVERT (varchar(10), Date_creation,110) LIKE '{}%' OR [batch_status] LIKE '{}%')".format(
                    searchbox, searchbox, searchbox)
                query_shorter.append(search_query)
            if len(sorting[0]) != 0:
                custom_sorting = sorting[0]
                custom_direction = direction

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            cursor = condb.cursor()
            sql = email_obj.emailqueryforcount(custom_query)
            # print(sql)
            cursor.execute(sql)
            # fetching buying details
            count = cursor.fetchall()
            # print("count", count)
            no_of_records = len(count)
            # print("no_of_records", no_of_records)

            sql = email_obj.emailquery(offset, length, custom_query, custom_sorting, custom_direction)
            # print(sql)
            cursor.execute(sql)

            tableData = cursor.fetchall()
            email_master_data = []

            for data in tableData:
                cursor = condb.cursor()
                sql = "SELECT parent_id, COUNT(id) as emailCount, sum(email_used) as email_used, sum(no_of_order) as no_of_order, sum(cancellation) as cancellation FROM [dbo].[emailmaster] where parent_id=? group by parent_id, cancel_rate"
                value = [data.parent_id]
                cursor.execute(sql,value)
                emaildata = cursor.fetchone()
                id = None
                email_used,no_of_order,cancellation,cancel_rate = 0,0,0,0
                if emaildata != None:
                    id = emaildata[0]
                    email_count = emaildata[1]
                    email_used = emaildata[2]
                    no_of_order = emaildata[3]
                    cancellation = emaildata[4]
                    if email_count != 0:
                        cancel_rate = '{0:.2f}'.format(float((cancellation/email_count) * 100))
                        cancel_rate = cancel_rate+'%'
                    else:
                        cancel_rate = '0.00%'
                email_master = {
                    'Id':id,
                    'Email_name': data.email,
                    'Email_count': email_count,
                    'Parent_id': data.parent_id,
                    'Email_used': email_used,
                    'Order_count': no_of_order,
                    'Cancel_count': cancellation,
                    'Status': data.status,
                    'Cancel_rate':cancel_rate,
                    'Date_creation': data.creationDate,
                }
                email_master_data.append(email_master)
            responsedata = {
                "draw": content['draw'],
                "data": email_master_data,
                "recordsTotal": no_of_records,
                "recordsFiltered": no_of_records
            }
            return jsonify(responsedata)
        elif request.method == 'PUT':
            # initializing cursor
            cursor = condb.cursor()
            # getting update data from the tracking page
            updatedData = request.json
            newValue = updatedData['newValue']
            print(newValue)
            parent_id = updatedData['id']
            print(parent_id)
            columnName = updatedData['cellName']
            print(columnName)

            # sql query for updating ordertracking status
            sql = "UPDATE [dbo].[emailmaster] SET {} = ? WHERE [parent_id]= ? AND email_used = 0".format(
                columnName)
            # execute sql query
            val = (newValue, parent_id)
            # execute sql query on the basic of gift_card_no & selected id
            cursor.execute(sql, val)
            # committing data on the database
            cursor.commit()
            rowcount = cursor.rowcount
            if rowcount > 0:
                sql = "UPDATE [dbo].[emailmaster] SET batch_status = ? WHERE [parent_id]= ?"
                val = (newValue, parent_id)
                cursor.execute(sql, val)
                cursor.commit()
                return json.dumps({'code':200, "column": columnName})
            else:
                return json.dumps({'code':404, "message": "Allready used, The email status can not update."})
        elif request.method == 'DELETE':
            row_num = str(request.json['row_num'])
            cursor = condb.cursor()
            sql = "SELECT parent_id, COUNT(CASE WHEN cart_id is not null then 1 ELSE null END) as total_active_email FROM [dbo].[emailmaster] WHERE parent_id=? group by parent_id"
            value = [row_num]
            cursor.execute(sql, value)
            emailstatus = cursor.fetchone()
            rowcount = 0
            if emailstatus != None:
                if emailstatus.total_active_email == 0:
                    sql = "DELETE FROM [dbo].[emailmaster] WHERE [dbo].[emailmaster].[parent_id]=?"
                    cursor.execute(sql, row_num)
                    cursor.commit()
                    rowcount = cursor.rowcount
                    if rowcount > 0:
                        message = str(rowcount) + " internal records are deleted."
                    else:
                        message = "Can not be deleted this email group."
                else:
                    message = "The email group has reserved - '" + str(emailstatus.total_active_email) + "' emails, Can'nt be deleted."
            else:
                message = "Please try again."
            if row_num:
                return json.dumps({'status': 200, 'message': message})
            return json.dumps({"status": 404, "error": "Invalid operation"})

        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        if len(accessdata) != 0:
            if accessdata[0].emailmaster == 1:
                cursor = condb.cursor()
                sql = "SELECT parent_id, count(parent_id) as total_active_email, COUNT(CASE WHEN status = 'Active' then 1 ELSE null END) as 'active_count' FROM [dbo].[emailmaster] group by parent_id"
                cursor.execute(sql)
                emailstatus = cursor.fetchall()
                rowcount = 0
                if len(emailstatus) != 0:
                    for email in emailstatus:
                        if email.active_count == 0:
                            sql = "UPDATE [dbo].[emailmaster] SET batch_status='Inactive' WHERE parent_id={}".format(email.parent_id)
                            cursor.execute(sql)
                            cursor.commit()
                        else:
                            sql = "UPDATE [dbo].[emailmaster] SET batch_status='Active' WHERE parent_id={}".format(email.parent_id)
                            cursor.execute(sql)
                            cursor.commit()

                cursor = condb.cursor()
                sql="SELECT email_id, tracking_status FROM [dbo].[ordertracking]"
                cursor.execute(sql)
                data_list = cursor.fetchall()
                cursor.execute(
                    "UPDATE [dbo].[emailmaster] SET no_of_order=0, cancellation=0 WHERE status = 'Active'")
                cursor.commit()
                if len(data_list) != 0:
                    for data in data_list:
                        order = cancelled = 0
                        if data.tracking_status != 'Cancelled':
                            order = 1
                        else:
                            cancelled = 1
                        sql = "UPDATE [dbo].[emailmaster] SET no_of_order=?, cancellation=? WHERE id=?"
                        val = (order, cancelled, data.email_id)
                        cursor.execute(sql,val)
                        cursor.commit()
                return render_template('emails.html', accessdata=accessdata)
            else:
                return redirect(url_for('index'))
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('login'))

@app.route('/emailaction', methods=['POST'])
def emailaction():
    if 'password' and 'email' in session:
        if request.method == 'POST':
            global companyid
            cursor = condb.cursor()
            companyid = session["companyid"]
            cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
            accessdata = cursor.fetchall()
            for x in accessdata:
                userid = x.userid
                companyid = x.companyid
            # catch_all_list = ['@yahoo.com','@gmail.com','@rediffmail.com','@hotmail.com','@outlook.com','@aol.com','@yandex.com','@zohomail.in','@protonmail.com','@gmx.com']
            row_count = int(request.form.get('no_row'))
            i = 0
            messages = []
            maillist = []
            emailcollection = []
            while (i < row_count):
                i += 1
                insert_count = 0
                message1, message2 = "", ""
                email_input = request.form.get('email_' + str(i))
                email_type = request.form.get('email_type_'+str(i))
                email_user = ""
                if email_input != "":
                    email_user = str(email_input).lower()

                if email_type == "gmail":
                    userpattern = emailparser(email_user)
                    email_domain = "@gmail.com"
                    emailcollection = [mail + email_domain for mail in userpattern]
                    # emailcollection = list(map(withdomainfunction,userpattern))
                    maillist.append(emailcollection)

                elif email_type == 'catchall':
                    email_domain = '@'+email_user
                    userpattern = emailparserforcatchall()
                    emailcollection = [mail + email_domain for mail in userpattern]
                    # emailcollection = [mail + domain for domain in catch_all_list for mail in userpattern if domain and mail]
                    maillist.append(emailcollection)
                if len(emailcollection)>0:
                    parent_id = None
                    import random
                    random.shuffle(emailcollection)
                    '''for j in range(len(emailcollection)):
                        if j == 0:
                            sql = "SELECT id,email_type FROM [dbo].[emailmaster] WHERE email = ?"
                            value = [emailcollection[j]]
                            cursor.execute(sql, value)
                            exist_id = cursor.fetchone()
                            status = 'Active'
                            if exist_id is None:
                                sql = "INSERT INTO [dbo].[emailmaster] (user_id, company_id, email, email_type, status, batch_status, Date_creation) OUTPUT INSERTED.ID VALUES(?,?,?,?,?,?,?)"
                                value = [userid,companyid,emailcollection[j],email_type,status,status,datetime.now()]
                                cursor.execute(sql, value)
                                parent_id = cursor.fetchone()
                                if parent_id is not None:
                                    parent_id = parent_id[0]
                                    sql = "UPDATE [dbo].[emailmaster] SET [parent_id] = ? WHERE id =?"
                                    val = (parent_id, parent_id)
                                    cursor.execute(sql, val)
                                    cursor.commit()
                                    insert_count += 1
                            elif exist_id[1] != 'catchall':
                                parent_id = exist_id[0]
                        if parent_id is not None:
                            sql = "If Not Exists(select id from [dbo].[emailmaster] where email=?) Begin INSERT INTO [dbo].[emailmaster] (user_id, company_id, email, email_type, parent_id, status, batch_status, Date_creation) VALUES(?,?,?,?,?,?,?,?); End"
                            value = [emailcollection[j], userid, companyid, emailcollection[j], email_type, parent_id, status, status,
                                     datetime.now()]
                            cursor.execute(sql, value)
                            count = cursor.rowcount
                            if count > 0:
                                cursor.commit()
                                insert_count +=1
                        else:
                            message1 = "<p style='color:white;'>'"+str(email_user) +"' email user allready exists. for your selected type - '"+email_type+"'</p>"
                            break
                    if insert_count != 0:
                        message2 = "<p>'" + str(insert_count) + "' new records are inserted for user email - '" + str(
                            email_user) + "'</p>"
                    if message1 != "":
                        messages.append(message1)
                    if message2 != "":
                        messages.append(message2)'''
            messages = (" ").join(messages)
            return json.dumps({'status': '200','messages':messages})
        else:
            return redirect(url_for('emails'))
    else:
        return redirect(url_for('login'))

@app.route('/selectemails', methods=['DELETE'])
def selectemails():
    try:
        if request.method == 'DELETE':
            cursor = condb.cursor()
            message = "Please click on at least one check box."
            message1 = message2 = ""
            delete_counter, skip_counter = 0, 0
            checkboxesArray = request.json['checkboxesArray']
            if len(checkboxesArray) != 0:
                for row in checkboxesArray:
                    sql = "SELECT parent_id, COUNT(CASE WHEN cart_id is not null then 1 ELSE null END) as total_active_email FROM [dbo].[emailmaster] WHERE parent_id=? group by parent_id"
                    value = [row]
                    cursor.execute(sql, value)
                    emailstatus = cursor.fetchone()
                    rowcount = 0
                    if emailstatus != None:
                        if emailstatus.total_active_email == 0:
                            sql = "DELETE FROM [dbo].[emailmaster] WHERE [dbo].[emailmaster].[parent_id]=?"
                            cursor.execute(sql, row)
                            cursor.commit()
                            rowcount = cursor.rowcount
                            if rowcount > 0:
                                delete_counter += rowcount
                                message1 = str(delete_counter) + " internal records are deleted."
                        else:
                            skip_counter += emailstatus.total_active_email
                            message2 = "Your selected email group has reserved - '" + str(
                                skip_counter) + "' emails, Can'nt be deleted."
                    else:
                        message = "Please try again."
            # while n < int(length):
            #     id = request.form.get("id" + str(n))
            #     n += 1
            #     if status == 'Delete':

            if message1 and message2:
                message = "(1). " + message1 + " and (2). " + message2
            elif message1:
                message = message1
            elif message2:
                message = message2
            return json.dumps({'status': 'OK', "message": message})
        else:
            return redirect(url_for('emails'))
    except Exception as e:
        print(e)
        return json.dumps({'status': 'error', "message": "Can't Deleted."})

# return 1000 of email pattern using catchall type
def emailparserforcatchall():
    import random
    names_list = [str(names.get_full_name(gender='male')).lower().replace(' ','') for name in range(0,100)]
    all_patterns = [name + str(number) for name in names_list if name for number in random.sample(range(99999), 10)]
    return all_patterns

# return n number of email pattern using gmail type
def emailparser(email_user):
    email_user_list = []
    try:
        if email_user != "":
            i=0
            strlen = len(email_user)
            email_user_list.append(email_user)
            while i<strlen:
                if i != 0 and i !=(strlen):
                    newemail = email_user[:i]+'.'+email_user[i:]
                    if newemail not in email_user_list:
                        email_user_list.append(newemail)
                    if newemail[-1]:
                        newemail1 = newemail[:i+2]+'.'+newemail[i+2:]
                        if newemail1[-1] != '.':
                            if newemail1 not in email_user_list:
                                email_user_list.append(newemail1)
                        if newemail1:
                            newemail2 = newemail1[:i+4]+'.'+newemail1[i+4:]
                            if newemail2[-1] != '.':
                                if newemail2 not in email_user_list:
                                    email_user_list.append(newemail2)
                            if newemail2:
                                newemail3 = newemail2[:i+6]+'.'+newemail2[i+6:]
                                if newemail3[-1] != '.':
                                    if newemail3 not in email_user_list:
                                        email_user_list.append(newemail3)
                                if newemail3:
                                    newemail4 = newemail3[:i + 8] + '.' + newemail3[i + 8:]
                                    if newemail4[-1] != '.':
                                        if newemail4 not in email_user_list:
                                            email_user_list.append(newemail4)
                                if newemail4:
                                    newemail5 = newemail4[:i + 10] + '.' + newemail4[i + 10:]
                                    if newemail5[-1] != '.':
                                        if newemail5 not in email_user_list:
                                            email_user_list.append(newemail5)
                                if newemail5:
                                    newemail6 = newemail5[:i + 12] + '.' + newemail5[i + 12:]
                                    if newemail6[-1] != '.':
                                        if newemail6 not in email_user_list:
                                            email_user_list.append(newemail6)
                                if newemail6:
                                    newemail7 = newemail6[:i + 14] + '.' + newemail6[i + 14:]
                                    if newemail7[-1] != '.':
                                        if newemail7 not in email_user_list:
                                            email_user_list.append(newemail7)

                i+=1
        print(email_user_list)
        email_user_list.sort(reverse=True)
        return email_user_list
    except Exception as e:
        print(e)
        return email_user_list

@app.route('/emailselectall', methods=["POST"])
def emailselectall():
    try:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # Create object for ordertracking
            email_obj = EmailList()

            # getting all json data from the datatable
            content = request.json

            get_ids = content['get_ids']
            # print('get ids', get_ids)

            unSelectArr = content['unSelectArr']
            print('unSelectArr', unSelectArr)

            if len(unSelectArr) == 1:
                unSelectArr.append('0')
            else:
                unSelectArr
            unSelectArr = tuple(unSelectArr)

            records = content['records']

            statusValue = content['statusValue']
            # print(statusValue)
            columns_status_search = ('' if statusValue == 'Status' else statusValue)

            columns_date = content['dateValue']
            # print(columns_date)
            columns_date_search = ("" if columns_date == "DateRange" else columns_date)

            today = datetime.datetime.now()
            lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
            date1, date2 = (
                (today - datetime.timedelta(days=6)).date(), today.date()) if columns_date_search == 'Last7days' else (
                ((today - datetime.timedelta(days=today.weekday())).date(),
                 today.date()) if columns_date_search == "ThisWeek" else (
                    ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                     lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                        (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                            (today - datetime.timedelta(days=30)).date(),
                            today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                            datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                        datetime.date.strftime(
                                                                                            datetime.datetime.strptime(
                                                                                                columns_date_search[
                                                                                                18:28],
                                                                                                '%m-%d-%Y'),
                                                                                            "%Y-%m-%d")) if len(
                            columns_date_search) == 28 else ("", "")))))

            searchbox = str(content['searchValue']).strip()
            # print(searchbox)

            select_all = content['selectall']
            # print(select_all)

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            if columns_date_search != "":
                query_shorter.append("CAST([Date_creation] as DATE) between '" + str(
                    date1) + "' and '" + str(
                    date2) + "'")
            if columns_status_search != "":
                query_shorter.append("[emailmaster].[batch_status] = '" + str(columns_status_search) + "'")
            if len(searchbox) != 0:
                search_query = "([email] LIKE '{}%' OR CONVERT (varchar(10), Date_creation,110) LIKE '{}%' OR [batch_status] LIKE '{}%')".format(
                    searchbox, searchbox, searchbox)
                query_shorter.append(search_query)
            if len(unSelectArr) != 0:
                query_shorter.append("id NOT IN {}".format(
                    unSelectArr))

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            cursor = condb.cursor()
            sql = email_obj.emailqueryselectall(custom_query)

            if get_ids == True:
                checkboxesArray = []
                # getting id of the selected filters
                if len(unSelectArr) == 0:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
                else:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
            else:
                cursor.execute(sql)
                # fetching giftcardl
                batch_count = cursor.fetchall()
                no_of_records = len(batch_count)

            if get_ids == True:
                return json.dumps({"arr": checkboxesArray})
            else:
                return json.dumps({'total_record': no_of_records})
    except Exception as e:
        print(e)

########################################################################
@app.route('/emaildetails', methods=['GET', 'PUT', 'POST', 'DELETE'])
def emaildetails():
    if 'password' and 'email' in session:
        import datetime
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        if request.method == "POST":
            email_id = request.args['id']
            content = request.json
            email_obj = EmailDetails()
            columns = content['columns']
            offset = content['start']
            length = content['length']
            search = content['search']
            searchbox = search['value'].strip()
            searchbox = "{" if searchbox.startswith("'") else searchbox
            searchbox = "{" if searchbox.startswith("-") else searchbox
            searchbox = "{" if searchbox.startswith(";") else searchbox

            columns_status = columns[5]
            columns_status_search = columns_status['search']['value']
            # print(columns_status_search)
            if columns_status_search == 'Status':
                columns_status_search = ''

            orderable = content['order']
            sorting = ["Date_creation" if orderable[0]['column'] == 1 else (
                "email" if orderable[0]['column'] == 2 else (
                    'no_of_order' if orderable[0]['column'] == 3 else (
                        'cancellation' if orderable[0]['column'] == 4 else (
                            'status' if orderable[0]['column'] == 5 else (
                                )))))]
            direction = orderable[0]['dir']

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            '''if columns_date_search != "":
                query_shorter.append("CAST([Date_creation] as DATE) between '" + str(
                    date1) + "' and '" + str(
                    date2) + "'")'''
            if email_id:
                query_shorter.append("parent_id = '" + str(email_id) + "'")
            if columns_status_search != "":
                query_shorter.append("[emailmaster].[status] = '" + str(columns_status_search) + "'")
            if len(searchbox) != 0:
                search_query = "([status] LIKE '{}%' OR [email] LIKE '{}%' OR  [no_of_order] LIKE '{}%' OR [cancellation] LIKE '{}%' OR CONVERT (varchar(10), Date_creation,110) LIKE '{}%')".format(
                    searchbox, searchbox, searchbox, searchbox, searchbox)
                query_shorter.append(search_query)
            if len(sorting[0]) != 0:
                custom_sorting = sorting[0]
                custom_direction = direction

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            sql = email_obj.emaildetailqueryforcount(custom_query)
            # print(sql)
            cursor.execute(sql)
            # fetching buying details
            count = cursor.fetchall()
            # print("count", count)
            try:
                no_of_records = count[0][0]
            except Exception as e:
                no_of_records = len(count)

            sql = email_obj.emaildetailquery(offset, length, custom_query, custom_sorting, custom_direction)
            # print(sql)
            cursor.execute(sql)

            tableData = cursor.fetchall()
            email_master_data = []
            for data in tableData:
                email_master = {
                    'Id': data.id,
                    'Email_name': data.email,
                    'Parent_id': data.parent_id,
                    'Status': data.status,
                    'Order_count': data.no_of_order,
                    'Cancel_count': data.cancellation,
                    'Date_creation': data.creationDate,
                }
                email_master_data.append(email_master)
            responsedata = {
                "draw": content['draw'],
                "data": email_master_data,
                "recordsTotal": no_of_records,
                "recordsFiltered": no_of_records
            }
            return jsonify(responsedata)
        elif request.method == 'PUT':
            # initializing cursor
            cursor = condb.cursor()
            # getting update data from the tracking page
            updatedData = request.json
            newValue = updatedData['newValue']
            print(newValue)
            id = updatedData['id']
            print(id)
            columnName = updatedData['cellName']
            print(columnName)

            # sql query for updating ordertracking status
            sql = "UPDATE [dbo].[emailmaster] SET {} = ? WHERE [id]= ? AND email_used = 0 AND cart_id is null".format(
                columnName)
            # execute sql query
            val = (newValue, id)
            # execute sql query on the basic of gift_card_no & selected id
            cursor.execute(sql, val)
            # committing data on the database
            cursor.commit()
            rowcount = cursor.rowcount
            if rowcount > 0:
                return json.dumps({'code': 200, "column": columnName})
            else:
                return json.dumps({'code': 404, "message": "Allready used, The email status can not update."})
        elif request.method == "DELETE":
            row_num = str(request.json['row_num'])
            sql = "DELETE FROM [dbo].[emailmaster] WHERE [dbo].[emailmaster].[id]=? and [status]='Active'"
            cursor.execute(sql, row_num)
            # committing data on the database
            cursor.commit()
            if row_num:
                return json.dumps({'status': 200,'message':"Deleted"})
            return json.dumps({"status": 400, "error": "Invalid operation"})
        cursor.execute("SELECT * FROM [dbo].[accessMaster] WHERE [dbo].[accessMaster].id=" + str(companyid))
        accessdata = cursor.fetchall()
        email_id = request.args['id']
        if len(accessdata) != 0:
            if accessdata[0].emailmaster == 1:
                cursor = condb.cursor()
                sql = "SELECT TOP 1 email, email_type FROM [dbo].[emailmaster] WHERE [dbo].[emailmaster].[parent_id]=? order by id asc"
                cursor.execute(sql, email_id)
                email_data = cursor.fetchone()
                email = email_type = ""
                if email_data:
                    email = email_data.email
                    email_type = email_data.email_type
                    if email_type == 'gmail':
                        email = email.split("@")[0]
                    elif email_type == 'catchall':
                        email = email.split("@")[1]
                        email = "@"+email
                email_info = {
                    "email":email,
                    "email_type":email_type
                }
                return render_template('emaildetails.html', accessdata=accessdata,data=email_id,email_info=email_info)
            else:
                return redirect(url_for('index'))
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('login'))

@app.route('/selectemaildetails', methods=['DELETE'])
def selectemaildetails():
    try:
        if request.method == 'DELETE':
            cursor = condb.cursor()
            message = "Please click on at least one check box."
            message1, message2 = "", ""
            delete_counter, skip_counter = 0, 0
            checkboxesArray = request.json['checkboxesArray']
            parent_id = None
            if len(checkboxesArray) != 0:
                try:
                    sql = "SELECT parent_id FROM [dbo].[emailmaster] WHERE id=?"
                    cursor.execute(sql,checkboxesArray[0])
                    parent_id = cursor.fetchone()[0]
                except Exception as e:
                    print(e)
            for row in checkboxesArray:
                sql = "DELETE FROM [dbo].[emailmaster] WHERE [dbo].[emailmaster].[id]=? and [status]='Active' AND cart_id is null"
                cursor.execute(sql, row)
                cursor.commit()
                rowcount = cursor.rowcount
                if rowcount>0:
                    delete_counter += rowcount
                    if delete_counter == 1:
                        message1 = str(delete_counter) +" record is deleted."
                    else:
                        message1 = str(delete_counter) + " records are deleted."
                else:
                    skip_counter += 1
                    if skip_counter == 1:
                        message2 = "Can't Deleted, "+str(skip_counter) + " email is used."
                    else:
                        message2 = "Can't Deleted, " + str(skip_counter) + " emails are used."
            if message1 and message2:
                message = "(1). " + message1 + " and (2). " + message2
            elif message1:
                message = message1
            elif message2:
                message = message2
            if parent_id !=None:
                sql = "SELECT parent_id FROM [dbo].[emailmaster] WHERE parent_id=?"
                cursor.execute(sql, parent_id)
                data_existance = cursor.fetchall()
                if len(data_existance) == 0:
                    return json.dumps({'status': 'Done', "message": message})
                return json.dumps({'status': 'OK', "message": message})
            return json.dumps({'status': 'OK', "message": message})
        else:
            return redirect(url_for('emaildetails'))
    except Exception as e:
        print(e)
        return json.dumps({'status': 'error', "message": "Can't Deleted."})

@app.route('/emaildetailselectall', methods=["POST"])
def emaildetailselectall():
    try:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # Create object for ordertracking
            email_obj = EmailDetails()

            # getting all json data from the datatable
            content = request.json

            email_id = content['id']

            get_ids = content['get_ids']
            # print('get ids', get_ids)

            unSelectArr = content['unSelectArr']
            # print('unSelectArr', unSelectArr)

            if len(unSelectArr) == 1:
                unSelectArr.append('0')
            else:
                unSelectArr
            unSelectArr = tuple(unSelectArr)

            records = content['records']

            statusValue = content['statusValue']
            # print(statusValue)
            columns_status_search = ('' if statusValue == 'Status' else statusValue)

            searchbox = str(content['searchValue']).strip()
            # print(searchbox)

            select_all = content['selectall']
            # print(select_all)

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            if email_id:
                query_shorter.append("parent_id = '" + str(email_id) + "'")
            if columns_status_search != "":
                query_shorter.append("[emailmaster].[status] = '" + str(columns_status_search) + "'")
            if len(searchbox) != 0:
                search_query = "([email] LIKE '{}%' OR CONVERT (varchar(10), Date_creation,110) LIKE '{}%' OR [batch_status] LIKE '{}%')".format(
                    searchbox, searchbox, searchbox)
                query_shorter.append(search_query)
            if len(unSelectArr) != 0:
                query_shorter.append("id NOT IN {}".format(
                    unSelectArr))

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            cursor = condb.cursor()
            sql = email_obj.emaildetailqueryselectall(custom_query)

            if get_ids == True:
                checkboxesArray = []
                # getting id of the selected filters
                if len(unSelectArr) == 0:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
                else:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
            else:
                cursor.execute(sql)
                # fetching giftcardl
                batch_count = cursor.fetchall()
                no_of_records = len(batch_count)

            if get_ids == True:
                return json.dumps({"arr": checkboxesArray})
            else:
                return json.dumps({'total_record': no_of_records})
    except Exception as e:
        print(e)
############### ---------End Emails Page-------------  ########################

############### --------- Addresses Page-------------  ########################
@app.route('/address', methods=['POST', 'PUT', 'GET', 'DELETE'])
def addresses():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        if request.method == 'POST':
            import datetime
            address_obj = AddressList()
            content = request.json
            columns = content['columns']
            offset = content['start']
            length = content['length']
            search = content['search']
            searchbox = search['value'].strip()
            searchbox = "{" if searchbox.startswith("'") else searchbox
            searchbox = "{" if searchbox.startswith("-") else searchbox
            searchbox = "{" if searchbox.startswith(";") else searchbox

            columns_status = columns[10]
            columns_status_search = columns_status['search']['value']
            # print(columns_status_search)
            if columns_status_search == 'Status':
                columns_status_search = ''

            orderable = content['order']
            sorting = ['max(Date_creation)' if orderable[0]['column'] == 1 else (
                'city' if orderable[0]['column'] == 3 else (
                    'batch_status' if orderable[0]['column'] == 10 else (
                        'state' if orderable[0]['column'] == 4 else (
                            'zip' if orderable[0]['column'] == 5 else (
                                )))))]
            direction = orderable[0]['dir']

            columns_date = columns[1]
            columns_date = columns_date['search']['value']
            columns_date_search = ("" if columns_date == "DateRange" else columns_date)
            today = datetime.datetime.now()
            lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
            date1, date2 = (
                (today - datetime.timedelta(days=6)).date(), today.date()) if columns_date_search == 'Last7days' else (
                ((
                         today - datetime.timedelta(
                     days=today.weekday())).date(),
                 today.date()) if columns_date_search == "ThisWeek" else (
                    ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                     lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                        (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                            (today - datetime.timedelta(days=30)).date(),
                            today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                            datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                        datetime.date.strftime(
                                                                                            datetime.datetime.strptime(
                                                                                                columns_date_search[
                                                                                                18:28],
                                                                                                '%m-%d-%Y'),
                                                                                            "%Y-%m-%d")) if len(
                            columns_date_search) == 28 else ("", "")))))
            date1 = str(date1)
            date2 = str(date2)
            # print(date1, date2)

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            if columns_date_search != "":
                query_shorter.append("CAST([Date_creation] as DATE) between '" + str(
                    date1) + "' and '" + str(
                    date2) + "'")
            if columns_status_search != "":
                query_shorter.append("[addressmaster].[batch_status] = '" + str(columns_status_search) + "'")
            if len(searchbox) != 0:
                search_query = "([city] LIKE '{}%' OR [state] LIKE '{}%' OR [zip] LIKE '{}%' OR CONVERT (varchar(10), Date_creation,110) LIKE '{}%' OR [batch_status] LIKE '{}%')".format(
                    searchbox, searchbox, searchbox, searchbox, searchbox)
                query_shorter.append(search_query)
            if len(sorting[0]) != 0:
                custom_sorting = sorting[0]
                custom_direction = direction

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            cursor = condb.cursor()
            sql = address_obj.addressqueryforcount(custom_query)
            # print(sql)
            cursor.execute(sql)
            # fetching buying details
            count = cursor.fetchall()
            # print("count", count)
            no_of_records = len(count)
            # print("no_of_records", no_of_records)

            sql = address_obj.addressquery(offset, length, custom_query, custom_sorting, custom_direction)
            # print(sql)
            cursor.execute(sql)

            tableData = cursor.fetchall()
            address_master_data = []
            for data in tableData:
                cursor = condb.cursor()
                sql = "SELECT parent_id, COUNT(id) as addressCount, sum(address_used) as address_used, sum(no_of_order) as no_of_order, sum(cancellation) as cancellation FROM [dbo].[addressmaster] where parent_id=? group by parent_id, cancel_rate"
                value = [data.parent_id]
                cursor.execute(sql, value)
                addressdata = cursor.fetchone()
                id = None
                Address_count, Address_used, Orders, Cancellation, Cancel_rate = 0, 0, 0, 0, 0
                if addressdata != None:
                    id = addressdata[0]
                    Address_count = addressdata[1]
                    Address_used = addressdata[2]
                    Orders = addressdata[3]
                    Cancellation = addressdata[4]
                    if Address_count != 0:
                        Cancel_rate = '{0:.2f}'.format(float((Cancellation/Address_count) * 100))
                        Cancel_rate = Cancel_rate+'%'
                    else:
                        Cancel_rate = '0.00%'
                address_master = {
                    'Parent_id': id,
                    'Date_creation': data.creationDate,
                    'Address_count': Address_count,
                    'Address_used': Address_used,
                    'City': data.city,
                    'State': data.state,
                    'Zip_code': data.zip,
                    'Status': data.status,
                    'Orders': Orders,
                    'Cancellation': Cancellation,
                    'Cancel_rate': Cancel_rate,
                }
                address_master_data.append(address_master)
            responsedata = {
                "draw": content['draw'],
                "data": address_master_data,
                "recordsTotal": no_of_records,
                "recordsFiltered": no_of_records
            }
            return jsonify(responsedata)
        elif request.method == 'PUT':
            # initializing cursor
            cursor = condb.cursor()
            # getting update data from the tracking page
            updatedData = request.json
            newValue = updatedData['newValue']
            # print(newValue)
            parent_id = updatedData['id']
            # print(parent_id)
            columnName = updatedData['cellName']
            # print(columnName)
            # sql query for updating ordertracking status
            sql = "UPDATE [dbo].[addressmaster] SET {} = ? WHERE [parent_id]= ? AND address_used = 0".format(
                columnName)
            # execute sql query
            val = (newValue, parent_id)
            # execute sql query on the basic of gift_card_no & selected id
            cursor.execute(sql, val)
            # committing data on the database
            cursor.commit()
            rowcount = cursor.rowcount
            if rowcount > 0:
                sql = "UPDATE [dbo].[addressmaster] SET batch_status = ? WHERE [parent_id]= ?"
                val = (newValue, parent_id)
                cursor.execute(sql, val)
                cursor.commit()
                return json.dumps({'code':200, "column": columnName})
            else:
                return json.dumps({'code':404, "message": "Allready used. The address status can not update."})
        elif request.method == 'DELETE':
            row_num = str(request.json['row_num'])
            cursor = condb.cursor()
            sql = "SELECT parent_id, COUNT(CASE WHEN cart_id is not null then 1 ELSE null END) as total_active_address FROM [dbo].[addressmaster] WHERE parent_id=? group by parent_id"
            value = [row_num]
            cursor.execute(sql, value)
            address_status = cursor.fetchone()
            rowcount = 0
            if address_status != None:
                if address_status.total_active_address == 0:
                    sql = "DELETE FROM [dbo].[addressmaster] WHERE [dbo].[addressmaster].[parent_id]=?"
                    cursor.execute(sql, row_num)
                    cursor.commit()
                    rowcount = cursor.rowcount
                    if rowcount > 0:
                        message = str(rowcount) + " internal records are deleted."
                    else:
                        message = "Can not be delete this address group."
                else:
                    message = "The address group has reserved - '" + str(
                        address_status.total_active_address) + "' address, Can'nt be deleted."
            else:
                message = "Please try again."
            if row_num:
                return json.dumps({'status': 200, 'message': message})
            return json.dumps({"status": 404, "error": "Invalid operation"})

        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        if len(accessdata) != 0:
            if accessdata[0].addressmaster == 1:
                # This method update batch_status according to address status check
                cursor = condb.cursor()
                sql = "SELECT parent_id, count(parent_id) as total_active_email, COUNT(CASE WHEN status = 'Active' then 1 ELSE null END) as 'active_count' FROM [dbo].[addressmaster] group by parent_id"
                cursor.execute(sql)
                data_list = cursor.fetchall()
                rowcount = 0
                if len(data_list) != 0:
                    for address in data_list:
                        if address.active_count == 0:
                            sql = "UPDATE [dbo].[addressmaster] SET batch_status='Inactive' WHERE parent_id={}".format(
                                address.parent_id)
                            cursor.execute(sql)
                            cursor.commit()
                        else:
                            sql = "UPDATE [dbo].[addressmaster] SET batch_status='Active' WHERE parent_id={}".format(
                                address.parent_id)
                            cursor.execute(sql)
                            cursor.commit()

                # This method update no_of_order and cancellation counts according to address status check
                cursor = condb.cursor()
                sql = "SELECT address_id, tracking_status FROM [dbo].[ordertracking]"
                cursor.execute(sql)
                data_list = cursor.fetchall()
                cursor.execute(
                    "UPDATE [dbo].[addressmaster] SET no_of_order=0, cancellation=0 WHERE status = 'Active'")
                cursor.commit()
                if len(data_list) != 0:
                    for data in data_list:
                        order = cancel = 0
                        if data.tracking_status == 'Cancelled':
                            cancel = 1
                        else:
                            order = 1
                        sql = "UPDATE [dbo].[addressmaster] SET no_of_order=?, cancellation=? WHERE id=?"
                        val = (order, cancel, data.address_id)
                        cursor.execute(sql, val)
                        cursor.commit()
                cursor.execute("SELECT * FROM [dbo].[US_STATES] ORDER BY STATE_CODE ASC")
                state_data = cursor.fetchall()
                return render_template('addresses.html', accessdata=accessdata, state_data=state_data)
            else:
                return redirect(url_for('index'))
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('login'))

@app.route('/addressaction', methods=['POST'])
def addressaction():
    if 'password' and 'email' in session:
        if request.method == 'POST':
            import random
            import string
            import time
            global companyid
            cursor = condb.cursor()
            companyid = session["companyid"]
            cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
            accessdata = cursor.fetchall()
            for x in accessdata:
                userid = x.userid
                companyid = x.companyid
            messages = []
            message1, message2 = "",""
            addresscollection = []
            numbercollection = []
            streetcollection = []
            parent_id = None
            insert_count = 0
            street = request.form.get('street')
            street = str(street).strip()
            unit = request.form.get('unit')
            city = request.form.get('city')
            state = request.form.get('state')
            zipcode = request.form.get('zip')
            address_type = request.form.get('address_type')
            # unit = random.randrange(1, 10**4) if unit == '' else unit
            if street != '':
                if len(zipcode) == 5:
                    if street != "":
                        street = str(street).strip()
                        street = str(street).title()
                    if unit != "":
                        unit = str(unit).strip()
                        unit = int(unit)
                    if city != "":
                        city = str(city).strip()
                        city = str(city).title()
                    if state != "":
                        state = str(state).strip()
                    if zipcode != "":
                        zipcode = str(zipcode).strip()
                    status = 'Active'
                    # if unit:
                    #     tempaddress = ("{0}, Unit {1}, {2}, {3}, {4}").format(street,unit,city,state,zipcode)
                    #     numbercollection.append(unit)
                    #     addresscollection.append(tempaddress)

                    numberlist = []
                    setrange = 12000
                    numberlist = random.sample(range(12999),setrange)
                    street_list = street.split(" ")
                    for no in numberlist:
                        if no != unit and no != 0:
                            street = streetmerge(street_list, address_type)
                            word = ['Unit','Apt','Suite','Ste','Build No']
                            word_coice = random.choice(word)
                            if address_type == 'hard':
                                extra_hard = ''.join(random.choices(string.ascii_letters + string.digits, k=15))
                                if unit !="":
                                    numbercollect = ("{0} {1} {2} {3}").format(word_coice, unit, no, extra_hard)
                                else:
                                    numbercollect = ("{0} {1} {2}").format(word_coice, no, extra_hard)
                            else:
                                if unit !="":
                                    numbercollect = ("{0} {1} {2}").format(word_coice, unit, no)
                                else:
                                    numbercollect = ("{0} {1}").format(word_coice, no)
                            tempaddress = ("{0}, {1}, {2}, {3}, {4}").format(street, numbercollect, city, state, zipcode)
                            print(tempaddress)
                            if tempaddress not in addresscollection:
                                addresscollection.append(tempaddress)
                                numbercollection.append(numbercollect)
                                streetcollection.append(street)
                    zipper = list(zip(addresscollection, numbercollection, streetcollection))
                    random.shuffle(zipper)
                    addresscollection, numbercollection, streetcollection = zip(*zipper)

                    for j in range(len(addresscollection)):
                        try:
                            if j == 0:
                                sql = "SELECT id FROM [dbo].[addressmaster] WHERE full_address = ?"
                                value = [addresscollection[j]]
                                cursor.execute(sql, value)
                                exist_id = cursor.fetchone()
                                if exist_id is None:
                                    sql = "INSERT INTO [dbo].[addressmaster] (user_id, company_id, street, suite, city, state, zip, full_address, status, batch_status, Date_creation) OUTPUT INSERTED.ID VALUES(?,?,?,?,?,?,?,?,?,?,?)"
                                    value = [userid, companyid, streetcollection[j], numbercollection[j], city, state,
                                             zipcode, addresscollection[j], status, status, datetime.now()]
                                    cursor.execute(sql, value)
                                    parent_id = cursor.fetchone()
                                    if parent_id is not None:
                                        parent_id = parent_id[0]
                                        sql = "UPDATE [dbo].[addressmaster] SET [parent_id] = ? WHERE id =?"
                                        val = (parent_id, parent_id)
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                        insert_count += 1
                            elif parent_id is not None:
                                sql = "If Not Exists(select id from [dbo].[addressmaster] where full_address=?) Begin INSERT INTO [dbo].[addressmaster] (user_id, company_id, parent_id, street, suite, city, state, zip, full_address, status, batch_status, Date_creation) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) End"
                                value = [addresscollection[j], userid, companyid, parent_id, streetcollection[j],
                                         numbercollection[j], city, state, zipcode,
                                         addresscollection[j], status, status, datetime.now()]
                                cursor.execute(sql, value)
                                count = cursor.rowcount
                                if count > 0:
                                    cursor.commit()
                                    insert_count += 1
                            else:
                                message1 = "<p style='color:white;'>'" + str(
                                    addresscollection[j]) + "' ---> allready exist.</p>"
                                break
                        except Exception as e:
                            print(e)
                            cursor = condb.cursor()
                            time.sleep(1)
                            cursor = condb.cursor()
                            continue

                    if insert_count != 0:
                        message2 = "<p>'" + str(insert_count) + "' new records are inserted for address - '" + str(
                            city)+" and " + str(state) + "'</p>"
                    if message1 != "":
                        messages.append(message1)
                    if message2 != "":
                        messages.append(message2)
                    messages = (" ").join(messages)
                    return json.dumps({'status': '200','messages':messages})
                else:
                    messages = "Maximum 5 digit allowed."
                    return json.dumps({'status': '400', 'messages': messages})
            else:
                messages = "Address must be required."
                return json.dumps({'status': '400', 'messages': messages})
        else:
            return redirect(url_for('addresses'))
    else:
        return redirect(url_for('login'))

def streetmerge(street_list, address_type):
    import random
    import string
    street = ""
    if address_type == '    easy':
        street = " ".join(street_list[0:len(street_list)])
    elif address_type == 'normal':
        word = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
                       'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
        if len(street_list) != 0:
            if len(street_list[1]) == 1:
                street_address = " ".join(street_list[1:len(street_list)])
                try:
                    if int(street_list[0][-1]):
                        word_coice = random.choice(word)
                        street = street_list[0] + '' + word_coice + ' ' + street_address
                except:
                    street_change = street_list[0].replace(street_list[0][-1], "")
                    word_coice = random.choice(word)
                    street = street_change + '' + word_coice + ' ' + street_address
            else:
                street_address = " ".join(street_list[1:len(street_list)])
                try:
                    if int(street_list[0][-1]):
                        word_coice = random.choice(word)
                        street = street_list[0] + '' + word_coice + ' ' + street_address
                except:
                    street_change = street_list[0].replace(street_list[0][-1], "")
                    word_coice = random.choice(word)
                    street = street_change + '' + word_coice + ' ' + street_address
    elif address_type == 'hard':
        if len(street_list) != 0:
            if len(street_list[1]) == 1:
                street_address = " ".join(street_list[1:len(street_list)])
                try:
                    if int(street_list[0][-1]):
                        random_letter = ''.join(
                            random.choice(string.ascii_letters) for x in range(4))
                        street = street_list[0] + '' + random_letter + ' ' + street_address
                except:
                    street_change = street_list[0].replace(street_list[0][-1], "")
                    random_letter = ''.join(
                        random.choice(string.ascii_letters) for x in range(4))
                    street = street_list[0] + '' + random_letter + ' ' + street_address
            else:
                street_address = " ".join(street_list[1:len(street_list)])
                try:
                    if int(street_list[0][-1]):
                        random_letter = ''.join(
                            random.choice(string.ascii_letters) for x in range(4))
                        street = street_list[0] + '' + random_letter + ' ' + street_address
                except:
                    street_change = street_list[0].replace(street_list[0][-1], "")
                    random_letter = ''.join(
                        random.choice(string.ascii_letters) for x in range(4))
                    street = street_list[0] + '' + random_letter + ' ' + street_address
    return street

@app.route('/selectaddresses', methods=['DELETE'])
def selectaddresses():
    try:
        if request.method == 'DELETE':
            cursor = condb.cursor()
            message = "Please click on at least one check box."
            message1 = message2 = ""
            delete_counter, skip_counter = 0, 0
            checkboxesArray = request.json['checkboxesArray']
            if len(checkboxesArray) != 0:
                for row in checkboxesArray:
                    sql = "SELECT parent_id, COUNT(CASE WHEN cart_id is not null then 1 ELSE null END) as total_active_address FROM [dbo].[addressmaster] WHERE parent_id=? group by parent_id"
                    cursor.execute(sql, row)
                    address_status = cursor.fetchone()
                    if address_status != None:
                        if address_status.total_active_address == 0:
                            sql = "DELETE FROM [dbo].[addressmaster] WHERE [dbo].[addressmaster].[parent_id]=?"
                            cursor.execute(sql, row)
                            cursor.commit()
                            rowcount = cursor.rowcount
                            if rowcount > 0:
                                delete_counter += rowcount
                                message1 = str(delete_counter) + " internal records are deleted."
                        else:
                            skip_counter += address_status.total_active_address
                            message2 = "Your selected address group has reserved - '" + str(
                                skip_counter) + "' address, Can'nt be deleted."
                    else:
                        message = "Please try again."

            if message1 and message2:
                message = "(1). "+message1 +" and (2). "+ message2
            elif message1:
                message = message1
            elif message2:
                message = message2

            return json.dumps({'status': 'OK', "message": message})
        else:
            return redirect(url_for('addresses'))
    except Exception as e:
        print(e)
        return json.dumps({'status': 'error', "message": "Can't Deleted."})

@app.route('/address-selectall', methods=["POST"])
def address_selectall():
    try:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # Create object for ordertracking
            address_obj = AddressList()

            # getting all json data from the datatable
            content = request.json

            get_ids = content['get_ids']
            # print('get ids', get_ids)

            unSelectArr = content['unSelectArr']
            print('unSelectArr', unSelectArr)

            if len(unSelectArr) == 1:
                unSelectArr.append('0')
            else:
                unSelectArr
            unSelectArr = tuple(unSelectArr)

            records = content['records']

            statusValue = content['statusValue']
            # print(statusValue)
            columns_status_search = ('' if statusValue == 'Status' else statusValue)

            columns_date = content['dateValue']
            # print(columns_date)
            columns_date_search = ("" if columns_date == "DateRange" else columns_date)

            today = datetime.datetime.now()
            lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
            date1, date2 = (
                (today - datetime.timedelta(days=6)).date(), today.date()) if columns_date_search == 'Last7days' else (
                ((today - datetime.timedelta(days=today.weekday())).date(),
                 today.date()) if columns_date_search == "ThisWeek" else (
                    ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                     lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                        (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                            (today - datetime.timedelta(days=30)).date(),
                            today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                            datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                        datetime.date.strftime(
                                                                                            datetime.datetime.strptime(
                                                                                                columns_date_search[
                                                                                                18:28],
                                                                                                '%m-%d-%Y'),
                                                                                            "%Y-%m-%d")) if len(
                            columns_date_search) == 28 else ("", "")))))

            searchbox = str(content['searchValue']).strip()
            # print(searchbox)

            select_all = content['selectall']
            # print(select_all)

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            if columns_date_search != "":
                query_shorter.append("CAST([Date_creation] as DATE) between '" + str(
                    date1) + "' and '" + str(
                    date2) + "'")
            if columns_status_search != "":
                query_shorter.append("[addressmaster].[batch_status] = '" + str(columns_status_search) + "'")
            if len(searchbox) != 0:
                search_query = "([city] LIKE '{}%' OR [state] LIKE '{}%' OR [zip] LIKE '{}%' OR CONVERT (varchar(10), Date_creation,110) LIKE '{}%' OR [batch_status] LIKE '{}%')".format(
                    searchbox, searchbox, searchbox, searchbox, searchbox)
                query_shorter.append(search_query)
            if len(unSelectArr) != 0:
                query_shorter.append("id NOT IN {}".format(
                    unSelectArr))

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            cursor = condb.cursor()
            sql = address_obj.addressqueryselectall(custom_query)

            if get_ids == True:
                checkboxesArray = []
                # getting id of the selected filters
                if len(unSelectArr) == 0:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
                else:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
            else:
                cursor.execute(sql)
                # fetching giftcardl
                batch_count = cursor.fetchall()
                no_of_records = len(batch_count)

            if get_ids == True:
                return json.dumps({"arr": checkboxesArray})
            else:
                return json.dumps({'total_record': no_of_records})
    except Exception as e:
        print(e)

####################################################################################################

@app.route('/addressdetails', methods=['GET', 'PUT', 'POST', 'DELETE'])
def addressdetails():
    if 'password' and 'email' in session:
        import datetime
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        if request.method == "POST":
            address_id = request.args['id']
            content = request.json
            address_obj = AddressDetails()
            columns = content['columns']
            offset = content['start']
            length = content['length']
            search = content['search']
            searchbox = search['value'].strip()
            searchbox = "{" if searchbox.startswith("'") else searchbox
            searchbox = "{" if searchbox.startswith("-") else searchbox
            searchbox = "{" if searchbox.startswith(";") else searchbox
            # filter for status using upper dropdown
            columns_status = columns[5]

            columns_status_search = columns_status['search']['value']
            # print(columns_status_search)
            if columns_status_search == 'Status':
                columns_status_search = ''
            elif columns_status_search == 'All':
                columns_status_search = ''

            orderable = content['order']
            sorting = ["Date_creation" if orderable[0]['column'] == 1 else (
                "full_address" if orderable[0]['column'] == 2 else (
                    'no_of_order' if orderable[0]['column'] == 3 else (
                        'cancellation' if orderable[0]['column'] == 4 else (
                            'status' if orderable[0]['column'] == 5 else (
                                )))))]
            direction = orderable[0]['dir']

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            '''if columns_date_search != "":
                query_shorter.append("CAST([Date_creation] as DATE) between '" + str(
                    date1) + "' and '" + str(
                    date2) + "'")'''
            if address_id:
                query_shorter.append("parent_id = '" + str(address_id) + "'")
            if columns_status_search != "":
                query_shorter.append("[addressmaster].[status] = '" + str(columns_status_search) + "'")
            if len(searchbox) != 0:
                search_query = "([status] LIKE '{}%' OR [full_address] LIKE '{}%' OR  [no_of_order] LIKE '{}%' OR [cancellation] LIKE '{}%' OR CONVERT (varchar(10), Date_creation,110) LIKE '{}%')".format(
                    searchbox, searchbox, searchbox, searchbox, searchbox)
                query_shorter.append(search_query)
            if len(sorting[0]) != 0:
                custom_sorting = sorting[0]
                custom_direction = direction

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            sql = address_obj.addressdetailqueryforcount(custom_query)
            # print(sql)
            cursor.execute(sql)
            # fetching buying details
            count = cursor.fetchall()
            # print("count", count)
            try:
                no_of_records = count[0][0]
            except Exception as e:
                no_of_records = len(count)

            sql = address_obj.addressdetailquery(offset, length, custom_query, custom_sorting, custom_direction)
            # print(sql)
            cursor.execute(sql)
            # print(sql)
            tableData = cursor.fetchall()
            address_detail_data = []
            for data in tableData:
                address_master = {
                    'Id': data.id,
                    'Parent_id': data.parent_id,
                    'Date_creation': data.creationDate,
                    'Address': data.full_address,
                    'Orders': data.no_of_order,
                    'Cancellation': data.cancellation,
                    'Status':data.status
                }
                address_detail_data.append(address_master)
            responsedata = {
                "draw": content['draw'],
                "data": address_detail_data,
                "recordsTotal": no_of_records,
                "recordsFiltered": no_of_records
            }
            return jsonify(responsedata)
        elif request.method == 'PUT':
            # initializing cursor
            cursor = condb.cursor()
            # getting update data from the tracking page
            updatedData = request.json
            newValue = updatedData['newValue']
            print(newValue)
            id = updatedData['id']
            # print(id)
            columnName = updatedData['cellName']
            # print(columnName)
            # sql query for updating ordertracking status
            sql = "UPDATE [dbo].[addressmaster] SET {} = ? WHERE [id]= ? AND address_used = 0 AND cart_id is null".format(
                columnName)
            # execute sql query
            val = (newValue, id)
            # execute sql query on the basic of gift_card_no & selected id
            cursor.execute(sql, val)
            # committing data on the database
            cursor.commit()
            rowcount = cursor.rowcount
            if rowcount > 0:
                return json.dumps({'code':200, "column": columnName})
            else:
                return json.dumps({'code':404, "message": "Allready used. The address status can not update."})
        elif request.method == "DELETE":
            row_num = str(request.json['row_num'])
            sql = "DELETE FROM [dbo].[addressmaster] WHERE [dbo].[addressmaster].[id]=? and [status]='Active'"
            cursor.execute(sql, row_num)
            # committing data on the database
            cursor.commit()
            if row_num:
                return json.dumps({'status': 200,'message':"Deleted"})
            return json.dumps({"status": 400, "error": "Invalid operation"})
        cursor.execute("SELECT * FROM [dbo].[accessMaster] WHERE [dbo].[accessMaster].id=" + str(companyid))
        accessdata = cursor.fetchall()
        address_id = request.args['id']
        if len(accessdata) != 0:
            if accessdata[0].emailmaster == 1:
                return render_template('addressdetails.html', accessdata=accessdata,data=address_id)
            else:
                return redirect(url_for('index'))
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('login'))

@app.route('/selectaddressdetails', methods=['DELETE'])
def selectaddressdetails():
    try:
        if request.method == 'DELETE':
            cursor = condb.cursor()
            message = "Please click on at least one check box."
            message1, message2 = "", ""
            delete_counter, skip_counter = 0, 0
            checkboxesArray = request.json['checkboxesArray']
            parent_id = None
            if len(checkboxesArray) != 0:
                try:
                    sql = "SELECT parent_id FROM [dbo].[addressmaster] WHERE id=?"
                    cursor.execute(sql, checkboxesArray[0])
                    parent_id = cursor.fetchone()[0]
                except Exception as e:
                    print(e)
            for row in checkboxesArray:
                sql = "DELETE FROM [dbo].[addressmaster] WHERE [dbo].[addressmaster].[id]=? and [status]='Active' AND cart_id is null"
                cursor.execute(sql, row)
                cursor.commit()
                rowcount = cursor.rowcount
                if rowcount > 0:
                    delete_counter += rowcount
                    if delete_counter == 1:
                        message1 = str(delete_counter) + " address is deleted."
                    else:
                        message1 = str(delete_counter) + " addresses are deleted."
                else:
                    skip_counter += 1
                    if skip_counter == 1:
                        message2 = "Can't Deleted, " + str(skip_counter) + " address is used."
                    else:
                        message2 = "Can't Deleted, " + str(skip_counter) + " addresses are used."
            if message1 and message2:
                message = "(1). " + message1 + " and (2). " + message2
            elif message1:
                message = message1
            elif message2:
                message = message2
            if parent_id != None:
                sql = "SELECT parent_id FROM [dbo].[addressmaster] WHERE parent_id=?"
                cursor.execute(sql, parent_id)
                data_existance = cursor.fetchall()
                if len(data_existance) == 0:
                    return json.dumps({'status': 'Done', "message": message})
                return json.dumps({'status': 'OK', "message": message})
            return json.dumps({'status': 'OK', "message": message})
        else:
            return redirect(url_for('emaildetails'))
    except Exception as e:
        print(e)
        return json.dumps({'status': 'error', "message": "Can't Deleted."})

@app.route('/addressdetail-selectall', methods=["POST"])
def addressdetail_selectall():
    try:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # Create object for ordertracking
            address_obj = AddressDetails()

            # getting all json data from the datatable
            content = request.json

            address_id = content['id']

            get_ids = content['get_ids']
            # print('get ids', get_ids)

            unSelectArr = content['unSelectArr']
            # print('unSelectArr', unSelectArr)

            if len(unSelectArr) == 1:
                unSelectArr.append('0')
            else:
                unSelectArr
            unSelectArr = tuple(unSelectArr)

            records = content['records']

            statusValue = content['statusValue']
            # print(statusValue)
            columns_status_search = ('' if statusValue == 'Status' else statusValue)

            searchbox = str(content['searchValue']).strip()
            # print(searchbox)

            select_all = content['selectall']
            # print(select_all)

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            if address_id:
                query_shorter.append("parent_id = '" + str(address_id) + "'")
            if columns_status_search != "":
                query_shorter.append("[addressmaster].[status] = '" + str(columns_status_search) + "'")
            if len(searchbox) != 0:
                search_query = "([city] LIKE '{}%' OR [state] LIKE '{}%' OR [zip] LIKE '{}%' OR CONVERT (varchar(10), Date_creation,110) LIKE '{}%' OR [batch_status] LIKE '{}%')".format(
                    searchbox, searchbox, searchbox, searchbox, searchbox)
                query_shorter.append(search_query)
            if len(unSelectArr) != 0:
                query_shorter.append("id NOT IN {}".format(
                    unSelectArr))

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            cursor = condb.cursor()
            sql = address_obj.addressdetailqueryselectall(custom_query)

            if get_ids == True:
                checkboxesArray = []
                # getting id of the selected filters
                if len(unSelectArr) == 0:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
                else:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
            else:
                cursor.execute(sql)
                # fetching giftcardl
                batch_count = cursor.fetchall()
                no_of_records = len(batch_count)

            if get_ids == True:
                return json.dumps({"arr": checkboxesArray})
            else:
                return json.dumps({'total_record': no_of_records})
    except Exception as e:
        print(e)
############### ---------End Addresses Page-------------  ########################

############### --------- Buying Page-------------  ########################
@app.route('/buying', methods=['POST', 'PUT', 'GET', 'DELETE'])
def buying():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        if len(accessdata) != 0:
            if accessdata[0].buying == 1:
                if request.method == 'POST':
                    try:
                        cart_id = None
                        loopvalue = 0
                        status = 'Active'
                        rowno = request.form.get('norow')
                        for x in accessdata:
                            userid = x.userid
                            companyid = x.companyid
                        addresslist = request.form.getlist('addresslist')
                        emaillist = request.form.getlist('emaillist')
                        total_order = int(request.form.get('buyingorder'))
                        address_collect, email_collect, phone_collect = [], [], []
                        # full_names = names.get_full_name(gender='male')
                        #### Address List
                        if addresslist[0] != 'All':
                            total = int(int(total_order)/len(addresslist))
                            reminder = int(int(total_order)%len(addresslist))
                            for parent_id in addresslist:
                                sql = "SELECT TOP ({0}) id, full_address, status, address_used, last_used from [dbo].[addressmaster] where status = '{1}' and parent_id = '{2}'".format(
                                    total, 'Active', parent_id)
                                cursor.execute(sql)
                                address_record = cursor.fetchall()
                                for rec in address_record:
                                    address_data = {}
                                    address_data.update({'id': rec.id})
                                    address_data.update({'address': rec.full_address})
                                    address_data.update({'status': rec.status})
                                    address_data.update({'address_used': rec.address_used})
                                    address_data.update({'last_used': rec.last_used})
                                    address_collect.append(address_data)
                            if reminder != 0:
                                for parent_id in addresslist:
                                    sql = "SELECT TOP({0}) id, full_address, status, address_used, last_used from [dbo].[addressmaster] where status = '{1}' and parent_id = '{2}'".format(
                                        1, 'Active', parent_id)
                                    print(sql)
                                    cursor.execute(sql)
                                    address_record = cursor.fetchall()
                                    flag = reminder - 1
                                    for rec in address_record:
                                        address_data = {}
                                        address_data.update({'id': rec.id})
                                        address_data.update({'address': rec.full_address})
                                        address_data.update({'status': rec.status})
                                        address_data.update({'address_used': rec.address_used})
                                        address_data.update({'last_used': rec.last_used})
                                        address_collect.append(address_data)
                                    if(flag==0):
                                        break
                        else:
                            sql = "SELECT TOP ({0}) id, parent_id, full_address, status, address_used, last_used from [dbo].[addressmaster] where status = '{1}'".format(
                                total_order, 'Active')
                            cursor.execute(sql)
                            address_record = cursor.fetchall()
                            parent_id_set = set()
                            for rec in address_record:
                                parent_id_set.add(str(rec.parent_id))
                                address_data = {}
                                address_data.update({'id': rec.id})
                                address_data.update({'address': rec.full_address})
                                address_data.update({'status': rec.status})
                                address_data.update({'address_used': rec.address_used})
                                address_data.update({'last_used': rec.last_used})
                                address_collect.append(address_data)
                            addresslist=list(parent_id_set)
                        #### EMAIL List
                        if emaillist[0] != 'All':
                            total = int(int(total_order) / len(emaillist))
                            reminder = int(int(total_order) % len(emaillist))
                            for parent_id in emaillist:
                                sql = "SELECT TOP ({0}) id, email, status, email_used, last_used from [dbo].[emailmaster] where status = '{1}' and parent_id = '{2}'".format(
                                    total, 'Active', parent_id)
                                cursor.execute(sql)
                                email_record = cursor.fetchall()
                                for rec in email_record:
                                    email_data = {}
                                    email_data.update({'id': rec.id})
                                    email_data.update({'email': rec.email})
                                    email_data.update({'status': rec.status})
                                    email_data.update({'email_used': rec.email_used})
                                    email_data.update({'last_used': rec.last_used})
                                    email_collect.append(email_data)
                            if reminder != 0:
                                for parent_id in emaillist:
                                    sql = "SELECT TOP({0}) id, email, status, email_used, last_used from [dbo].[emailmaster] where status = '{1}' and parent_id = '{2}'".format(
                                        1, 'Active', parent_id)
                                    cursor.execute(sql)
                                    email_record = cursor.fetchall()
                                    flag = reminder - 1
                                    for rec in email_record:
                                        email_data = {}
                                        email_data.update({'id': rec.id})
                                        email_data.update({'email': rec.email})
                                        email_data.update({'status': rec.status})
                                        email_data.update({'email_used': rec.email_used})
                                        email_data.update({'last_used': rec.last_used})
                                        email_collect.append(email_data)
                                    if(flag==0):
                                        break
                        else:
                            sql = "SELECT TOP ({0}) id, parent_id, email, status, email_used, last_used FROM [dbo].[emailmaster] where status = '{1}'".format(
                                total_order, 'Active')
                            cursor.execute(sql)
                            email_record = cursor.fetchall()
                            parent_id_set = set()
                            for rec in email_record:
                                parent_id_set.add(str(rec.parent_id))
                                email_data = {}
                                email_data.update({'id': rec.id})
                                email_data.update({'email': rec.email})
                                email_data.update({'status': rec.status})
                                email_data.update({'email_used': rec.email_used})
                                email_data.update({'last_used': rec.last_used})
                                email_collect.append(email_data)
                            emaillist = list(parent_id_set)

                        sql = "SELECT TOP ({0}) id, phone, status, phone_used, last_used from [dbo].[phonenumber] where status = '{1}'".format(
                            total_order, 'Active')
                        cursor.execute(sql)
                        phone_record = cursor.fetchall()
                        for rec in phone_record:
                            phone_data = {}
                            phone_data.update({'id': rec.id})
                            phone_data.update({'phone': rec.phone})
                            phone_data.update({'status': rec.status})
                            phone_data.update({'phone': rec.phone})
                            phone_data.update({'last_used': rec.last_used})
                            phone_collect.append(phone_data)

                        #### Check phone number list
                        if len(phone_collect) == total_order and len(phone_collect) !=0:
                            i = 0
                            while i < int(rowno):
                                i += 1
                                sku = request.form.get('sku-' + str(i))
                                price = request.form.get('price-' + str(i))
                                qtypercart = request.form.get('qtypercart-' + str(i))
                                totalunit = request.form.get('totalunit-' + str(i))
                                tax = request.form.get('tax')
                                shipping = request.form.get('shipping')
                                subtotalcart = request.form.get('subtotalcart')
                                total_item = request.form.get('buyingitem')
                                total_cost = request.form.get('buyingtotalcost')
                                loopvalue = int(totalunit) / int(qtypercart)
                                address_collect_str = ','.join(addresslist)
                                email_collect_str = ','.join(emaillist)
                                projected_cost = round((float(totalunit) * float(price)),2)
                                if tax is None:
                                    tax = 0
                                if shipping is None:
                                    shipping = 0

                                if (i == 1):
                                    sql = "INSERT INTO [dbo].[buyingmaster] (user_id, company_id, item_sku, price, qty_percart, unit_total, shipping, tax, subtotal, total_cost, projected_cost, order_count, unfulfilled, status, Date_creation) OUTPUT INSERTED.ID VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                                    value = [userid, companyid, sku, price, qtypercart, totalunit, tax,
                                             shipping, subtotalcart, total_cost, projected_cost, total_order, total_order,
                                             status, datetime.now()]
                                    cursor.execute(sql, value)
                                    cart_id = cursor.fetchone()
                                    if cart_id is not None:
                                        cart_id = cart_id[0]
                                        sql = "UPDATE [dbo].[buyingmaster] SET [cart_id] = ? WHERE id =?"
                                        val = (cart_id, cart_id)
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                if cart_id is not None:
                                    sql = "If Not Exists(select id from [dbo].[buyingmaster] where cart_id=? and item_sku=?) Begin INSERT INTO [dbo].[buyingmaster] (user_id, company_id, cart_id, item_sku, price, qty_percart, unit_total, shipping, tax, subtotal, total_cost, projected_cost, order_count, unfulfilled, status, Date_creation) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) End"
                                    value = [cart_id, sku, userid, companyid, cart_id, sku, price, qtypercart,
                                             totalunit, tax, shipping, subtotalcart, total_cost, projected_cost, total_order,
                                             total_order, status, datetime.now()]
                                    cursor.execute(sql, value)
                                    cursor.commit()

                            if len(address_collect) != 0 and len(email_collect) != 0 and len(
                                    phone_collect) != 0:
                                for x in range(0, int(1)):
                                    cart_loop = int(loopvalue)
                                    sql = "INSERT INTO [dbo].[buyingitems] (user_id,company_id,cart_id,loop_ount,working_status,loop_status,address_ids,email_ids,cart_loop,Date_creation) values(?,?,?,?,?,?,?,?,?,?)"
                                    val = [userid, companyid, cart_id, 0, status, 'Initial',
                                           address_collect_str, email_collect_str, cart_loop,
                                           datetime.now()]
                                    cursor.execute(sql, val)
                                    cursor.commit()
                                    for address in address_collect:
                                        sql = "UPDATE [dbo].[addressmaster] SET status=?, cart_id=?, last_used=? WHERE id=?"
                                        val = ('Inactive', cart_id, datetime.now(), address['id'])
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                    for email in email_collect:
                                        sql = "UPDATE [dbo].[emailmaster] SET status=?, cart_id=?, last_used=? WHERE id=?"
                                        val = ('Inactive', cart_id, datetime.now(), email['id'])
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                    for phone in phone_collect:
                                        sql = "UPDATE [dbo].[phonenumber] SET status=?, cart_id=?, last_used=? WHERE phone=?"
                                        val = ('Inactive', cart_id, datetime.now(), phone['phone'])
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                message = "Record inserted successfully."
                        else:
                            message = "Please add more phone numbers. contact admin."
                        return json.dumps({'status': 200, "messages": message})
                    except Exception as e:
                        print(e)
                        return json.dumps({'status': 400, "messages": str(e)})
                elif request.method == 'DELETE':
                    cursor = condb.cursor()
                    row_id = request.json['row_num']
                    sql = "DELETE FROM [dbo].[buyingitems] WHERE [dbo].[buyingitems].[cart_id]=?"
                    cursor.execute(sql, row_id)
                    rowcount = cursor.rowcount
                    if rowcount > 0:
                        contact_status = resetContactDetail(row_id)
                        print(contact_status)
                        sql = "DELETE FROM [dbo].[buyingmaster] WHERE [dbo].[buyingmaster].[cart_id]=?"
                        cursor.execute(sql, row_id)
                        cursor.commit()
                        rowcount = cursor.rowcount
                        if rowcount > 0:
                            return json.dumps({'status': 200})
                    if len(data_buyingitem) == 0:
                        contact_status = resetContactDetail(row_id)
                        print(contact_status)
                        sql = "DELETE FROM [dbo].[buyingmaster] WHERE [dbo].[buyingmaster].[cart_id]=?"
                        cursor.execute(sql, row_id)
                        cursor.commit()
                        rowcount = cursor.rowcount
                        if rowcount > 0:
                            return json.dumps({'status': 200})
                    return json.dumps({'status': 400})
                elif request.method == 'PUT':
                    # initializing cursor
                    cursor = condb.cursor()
                    # getting update data from the tracking page
                    updatedData = request.json
                    newValue = updatedData['newValue']
                    if newValue == 'No Status':
                        newValue = None
                    print(newValue)
                    id = updatedData['id']
                    print(id)
                    columnName = updatedData['cellName']
                    print(columnName)
                    # sql query for updating ordertracking status
                    sql = "UPDATE [dbo].[buyingmaster] SET {} = ? WHERE [cart_id]= ?".format(
                        columnName)
                    # execute sql query
                    val = (newValue, id)
                    # execute sql query on the basic of gift_card_no & selected id
                    cursor.execute(sql, val)
                    # committing data on the database
                    cursor.commit()
                    rowcount = cursor.rowcount
                    if rowcount > 0:
                        columnName = str(columnName).title()
                        return json.dumps({'code': 200, "column": columnName})
                    else:
                        return json.dumps({'code': 404, "message": "Status Not Updated."})

                cursor.execute("SELECT parent_id, full_address from [dbo].[addressmaster] as a where id=parent_id and parent_id in (SELECT parent_id from [dbo].[addressmaster] where parent_id=a.parent_id and status='Active')")
                addressdata = cursor.fetchall()
                cursor.execute("SELECT parent_id, email from [dbo].[emailmaster] as a where id=parent_id and parent_id in (SELECT parent_id from [dbo].[emailmaster] where parent_id=a.parent_id and status='Active')")
                emaildata = cursor.fetchall()

                cursor.execute("SELECT parent_id, full_address from [dbo].[addressmaster] as a where id=parent_id")
                addressdataforedit = cursor.fetchall()
                cursor.execute("SELECT parent_id, email from [dbo].[emailmaster] as a where id=parent_id")
                emaildataforedit = cursor.fetchall()

                final_cost = buyingFinalCostAdapter()
                # print(final_cost)

                cursor = condb.cursor()
                sql = "SELECT cart_id, order_count, completed_count, cancelled_count, unfulfilled FROM [dbo].[buyingmaster] group by cart_id, order_count, completed_count, cancelled_count, unfulfilled"
                cursor.execute(sql)
                data_list = cursor.fetchall()
                if len(data_list)!=0:
                    for data in data_list:
                        order_count = data.order_count
                        completed_count = data.completed_count
                        cancelled_count = data.cancelled_count
                        placed_order = int(completed_count) + int(cancelled_count)
                        unfulfilled_count = int(order_count) - placed_order
                        sql = "UPDATE [dbo].[buyingmaster] SET unfulfilled=? WHERE cart_id=? AND status !='Active'"
                        val = (unfulfilled_count, data.cart_id)
                        cursor.execute(sql, val)
                        cursor.commit()

                ##### SLider data #####
                range_slider_data = {}
                sql = "SELECT MIN(subtotal) as min_subtotal, MAX(subtotal) as max_subtotal FROM [dbo].[buyingmaster]"
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                subtotal_slider = {}
                if None not in table_Data:
                    min_subtotal = int(table_Data.min_subtotal)
                    max_subtotal = int(table_Data.max_subtotal)

                    subtotal_slider['min'] = 0
                    subtotal_slider['from'] = 0

                    if max_subtotal == 0:
                        max_subtotal += 1

                    subtotal_slider['max'] = max_subtotal
                    subtotal_slider['to'] = max_subtotal
                    range_slider_data['subtotal_slider'] = subtotal_slider
                else:
                    subtotal_slider['min'] = 0
                    subtotal_slider['from'] = 0
                    subtotal_slider['max'] = 1
                    subtotal_slider['to'] = 1
                    range_slider_data['subtotal_slider'] = subtotal_slider

                ## --------- ##
                non_cancelled_days, cancelled_days = 0, 0
                sql = "SELECT non_cancelled_order, cancelled_order, status FROM [dbo].[settings]"
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                if table_Data:
                    non_cancelled_days = table_Data.non_cancelled_order
                    cancelled_days = table_Data.cancelled_order

                available_balance = 0
                sql = "SELECT sum(A.[balance]) as giftcard_balance FROM [dbo].[giftcardlist] as A WHERE A.status in ('New', 'Balance', 'Balance Off', 'New Balance', 'Value Off') and A.balance>0 and (A.status!='Locked' or A.last_used is null)"
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                if table_Data:
                    available_balance = table_Data.giftcard_balance if table_Data.giftcard_balance else 0
                    available_balance = '{0:.2f}'.format(float(available_balance))

                queue_balance, non_cancelled_order_lock_queue_balance, cancelled_order_lock_queue_balance = 0, 0, 0
                sql = "SELECT sum(A.[balance]) as queue_balance FROM [dbo].[giftcardlist] as A INNER JOIN [dbo].[giftcardtransaction] as B ON A.gift_card_no=B.giftcard_number WHERE A.status in ('New', 'Balance', 'Balance Off', 'New Balance', 'Value Off') and B.action_type is null and B.order_purchase_status!='Cancelled' and balance>0 and (last_used >= DATEADD(day,-{}, GETDATE()) or last_used is null)".format(
                    non_cancelled_days)
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                if table_Data:
                    non_cancelled_order_lock_queue_balance = table_Data.queue_balance if table_Data.queue_balance else 0

                sql = "SELECT sum(A.[balance]) as queue_balance FROM [dbo].[giftcardlist] as A INNER JOIN [dbo].[giftcardtransaction] as B ON A.gift_card_no=B.giftcard_number WHERE A.status in ('New', 'Balance', 'Balance Off', 'New Balance', 'Value Off') and B.action_type is null and B.order_purchase_status='Cancelled' and balance>0 and (last_used >= DATEADD(day,-{}, GETDATE()) or last_used is null)".format(
                    cancelled_days)
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                if table_Data:
                    cancelled_order_lock_queue_balance = table_Data.queue_balance if table_Data.queue_balance else 0
                queue_balance = non_cancelled_order_lock_queue_balance + cancelled_order_lock_queue_balance
                queue_balance = '{0:.2f}'.format(float(queue_balance))

                giftcard_amount = {'available_balance': available_balance, 'queue_balance': queue_balance}

                ## --------- ##
                buying_obj = BuyingManager()
                today_date = buying_obj.customdaterange('Today')
                custom_query = "CAST([buyingmaster].[Date_extention] AS DATE) between '" + str(
                    today_date['date1']) + "' and '" + str(
                    today_date['date2']) + "'"

                order_count, cost, units, success_ratio, fulfillment_ratio = 0, 0, 0, 0, 0

                # sql = "SELECT count(DISTINCT (CASE WHEN tracking_status != 'Cancelled' then order_number end)) as orders, sum(qty_cart) as units, sum(cart_total) as subtotal, order_count, completed_count, unfulfilled, cancelled_count, buyingmaster.cart_id FROM [dbo].[buyingmaster] FULL OUTER JOIN [dbo].[ordertracking] ON buyingmaster.cart_id=ordertracking.cart_id WHERE {} group by buyingmaster.cart_id, order_count, completed_count, unfulfilled, cancelled_count".format(
                #     custom_query)
                sql = "SELECT count(DISTINCT (CASE WHEN tracking_status != 'Cancelled' then order_number end)) as orders, sum(qty_cart) as units, sum(cart_total) as subtotal, order_count, completed_count, unfulfilled, cancelled_count, buyingmaster.cart_id FROM [dbo].[buyingmaster] FULL OUTER JOIN [dbo].[ordertracking] ON buyingmaster.cart_id=ordertracking.cart_id WHERE {} group by buyingmaster.cart_id, order_count, completed_count, unfulfilled, cancelled_count".format(
                    custom_query)
                cursor.execute(sql)
                table_Data = cursor.fetchall()
                completed_count,unfulfilled_count,cancelled_count,total_orders=0,0,0,0
                for data in table_Data:
                    order_count += data.order_count if data.order_count else 0
                    cost += data.subtotal if data.subtotal else 0
                    completed_count += data.completed_count if data.completed_count else 0
                    unfulfilled_count += data.unfulfilled if data.unfulfilled else 0
                    cancelled_count += data.cancelled_count if data.cancelled_count else 0
                    total_orders += data.orders if data.orders else 0
                    units += data.units if data.units else 0

                if order_count != 0:
                    success_ratio = int((completed_count / order_count) * 100)
                    unfulledvalue = unfulfilled_count + cancelled_count
                    fulfillment_count = order_count - unfulledvalue
                    fulfillment_ratio = int((fulfillment_count / order_count) * 100)

                    # success_rate = order_count - unfulfilled_count
                    # success_ratio = int((success_rate / order_count) * 100)
                    # unfulledvalue = unfulfilled_count + cancelled_count
                    # fulfillment_count = order_count - unfulledvalue
                    # fulfillment_ratio = int((fulfillment_count / order_count) * 100)
                snapshot1 = {"order_count": total_orders, "cost": cost, "units": units, "success_ratio": success_ratio,
                             "fulfillment_ratio": fulfillment_ratio}
                ## --------- ##
                avail_balance= total_order= total_item= total_cost = 0
                custom_query = "CAST([buyingmaster].[Date_creation] AS DATE) between '" + str(
                    today_date['date1']) + "' and '" + str(
                    today_date['date2']) + "'"


                total_item, total_cost, total_order = 0, 0, 0
                sql = "SELECT unfulfilled, buyingmaster.subtotal, qty_percart, buyingmaster.cart_id FROM [dbo].[buyingmaster] WHERE {} AND buyingmaster.status='Active' group by buyingmaster.cart_id, unfulfilled, buyingmaster.subtotal, qty_percart".format(
                    custom_query)
                cursor.execute(sql)
                table_Data = cursor.fetchall()
                cart_id_old, cart_id_change = None, None
                for data in table_Data:
                    cart_id_old = data.cart_id
                    unfulfilled_order = data.unfulfilled if data.unfulfilled else 0
                    subtotal = data.subtotal if data.subtotal else 0
                    order_subtotal = subtotal * unfulfilled_order
                    total_cost += order_subtotal
                    total_order += unfulfilled_order
                    if cart_id_old != cart_id_change:
                        cart_id_change = cart_id_old
                        total_item = total_item + (data.qty_percart * unfulfilled_order)

                snapshot2 = {'total_order': total_order, 'total_item': total_item, 'total_cost': total_cost,
                             'avail_balance': float(available_balance)}

                cursor = condb.cursor()
                sql = "SELECT cart_id, tracking_status, order_number FROM [dbo].[ordertracking] group by order_number, tracking_status, cart_id order by cart_id asc"
                cursor.execute(sql)
                data_list = cursor.fetchall()

                cursor.execute(
                    "UPDATE [dbo].[buyingmaster] SET completed_count=0, cancelled_count=0")
                cursor.commit()

                if len(data_list) != 0:
                    master_id = 0
                    order = cancelled = 0
                    order_number = []
                    update_cart_counts = {}
                    for data in data_list:
                        bying_id = data.cart_id
                        order_no = data.order_number
                        if master_id == bying_id:
                            if order_no not in order_number:
                                if data.tracking_status != 'Cancelled':
                                    order += 1
                                else:
                                    cancelled += 1
                                order_number.append(order_no)
                        else:
                            master_id = bying_id
                            if order_no not in order_number:
                                order_number = []
                                order_number.append(order_no)
                            order = cancelled = 0
                            if data.tracking_status != 'Cancelled':
                                order += 1
                            else:
                                cancelled += 1
                        constant = (order, cancelled)
                        update_cart_counts[bying_id] = constant
                    for key, value in update_cart_counts.items():
                        sql = "UPDATE [dbo].[buyingmaster] SET completed_count=?, cancelled_count=? WHERE cart_id=?"
                        val = (value[0], value[1], key)
                        cursor.execute(sql, val)
                        cursor.commit()
                return render_template('buying.html', accessdata=accessdata, addressdata=addressdata,
                                       emaildata=emaildata, addressdataforedit=addressdataforedit,
                                       emaildataforedit=emaildataforedit, sliderdata=range_slider_data,
                                       snapshot1=snapshot1,snapshot2=snapshot2, giftcard_amount=giftcard_amount)
            else:
                return redirect(url_for('index'))
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('login'))

def buyingFinalCostAdapter():
    cursor = condb.cursor()
    sql = "SELECT cart_id FROM [dbo].[buyingmaster]"
    cursor.execute(sql)
    table_data = cursor.fetchall()
    records_update = 0

    if len(table_data) != 0:
        sql = "UPDATE [dbo].[buyingmaster] SET projected_cost=round((unit_total*price),2)"
        cursor.execute(sql)
        cursor.commit()
        for id in table_data:
            cart_id = id.cart_id
            if cart_id is not None:
                sql = "SELECT order_number, qty_cart, tracking_status, cart_id, cart_total FROM [bestbuymaster].[dbo].[ordertracking] where cart_id=? group by cart_id, cart_total, order_number, tracking_status, qty_cart"
                cursor.execute(sql,cart_id)
                order_data = cursor.fetchall()
                if len(order_data) != 0:
                    final_total = 0.0
                    unit_order, unit_cancelled = 0, 0
                    for od in order_data:
                        if od.tracking_status == 'Cancelled':
                            unit_cancelled += od.qty_cart if od.qty_cart else 0
                        else:
                            unit_order += od.qty_cart if od.qty_cart else 0
                            final_total += od.cart_total if od.cart_total else 0

                    final_total = round(final_total, 2)
                    sql = "UPDATE [dbo].[buyingmaster] SET final_cost=?, unit_ordered=?, unit_cancelled=? WHERE cart_id = ?"
                    val= (final_total, unit_order, unit_cancelled, cart_id)
                    cursor.execute(sql,val)
                    cursor.commit()
                    records_update != 1
    result = {'updated':records_update}
    return jsonify(result)

@app.route('/buyingsnapshot1', methods=['POST'])
def buyingSnapshot1():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        if request.method == 'POST':
            date_filter = request.json['data']
            buying_obj = BuyingManager()
            today_date = buying_obj.customdaterange(date_filter)
            custom_query = "CAST([buyingmaster].[Date_extention] AS DATE) between '" + str(
                today_date['date1']) + "' and '" + str(
                today_date['date2']) + "'"

            order_count, cost, units, success_ratio, fulfillment_ratio = 0,0,0,0,0

            sql = "SELECT count(DISTINCT (CASE WHEN tracking_status != 'Cancelled' then order_number end)) as orders, sum(qty_cart) as units, sum(cart_total) as subtotal, order_count, completed_count, unfulfilled, cancelled_count, buyingmaster.cart_id FROM [dbo].[buyingmaster] FULL OUTER JOIN [dbo].[ordertracking] ON buyingmaster.cart_id=ordertracking.cart_id WHERE {} group by buyingmaster.cart_id, order_count, completed_count, unfulfilled, cancelled_count".format(
                custom_query)
            cursor.execute(sql)
            table_Data = cursor.fetchall()
            completed_count, unfulfilled_count, cancelled_count, total_orders = 0,0,0,0
            for data in table_Data:
                order_count += data.order_count if data.order_count else 0
                cost += data.subtotal if data.subtotal else 0
                completed_count += data.completed_count if data.completed_count else 0
                unfulfilled_count += data.unfulfilled if data.unfulfilled else 0
                cancelled_count += data.cancelled_count if data.cancelled_count else 0
                total_orders += data.orders if data.orders else 0
                units += data.units if data.units else 0

            if order_count != 0:
                success_ratio = int((completed_count / order_count) * 100)
                unfulledvalue = unfulfilled_count + cancelled_count
                fulfillment_count = order_count - unfulledvalue
                fulfillment_ratio = int((fulfillment_count / order_count) * 100)

            cost = '{0:.2f}'.format(float(cost))
            snapshot1 = {"order_count": total_orders, "cost": cost, "units": units, "success_ratio": success_ratio,
                         "fulfillment_ratio": fulfillment_ratio}
            return jsonify(snapshot1)
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('index'))


@app.route('/buyingsnapshot2', methods=['POST'])
def buyingSnapshot2():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        if request.method == 'POST':
            date_filter = request.json['data']
            buying_obj = BuyingManager()
            today_date = buying_obj.customdaterange(date_filter)
            avail_balance = total_order = total_item = total_cost = 0
            custom_query = "CAST([Date_creation] AS DATE) between '" + str(
                today_date['date1']) + "' and '" + str(
                today_date['date2']) + "'"

            total_item, unfulfilled_order, subtotal, order_subtotal, total_cost, total_order = 0, 0, 0, 0, 0, 0
            sql = "SELECT unfulfilled, buyingmaster.subtotal, qty_percart, buyingmaster.cart_id FROM [dbo].[buyingmaster] WHERE {} AND buyingmaster.status='Active' group by buyingmaster.cart_id, qty_percart, unfulfilled, buyingmaster.subtotal".format(
                custom_query)
            cursor.execute(sql)
            table_Data = cursor.fetchall()
            cart_id_old, cart_id_change = None, None
            for data in table_Data:
                cart_id_old = data.cart_id
                unfulfilled_order = data.unfulfilled if data.unfulfilled else 0
                subtotal = data.subtotal if data.subtotal else 0
                order_subtotal = subtotal * unfulfilled_order
                total_cost += order_subtotal
                total_order += unfulfilled_order
                if cart_id_old != cart_id_change:
                    cart_id_change = cart_id_old
                    total_item = total_item + (data.qty_percart * unfulfilled_order)

            total_cost = '{0:.2f}'.format(float(total_cost))

            available_balance= 0
            sql = "SELECT sum([balance]) as giftcard_balance FROM [dbo].[giftcardlist] WHERE status='Balance' and balance>0 and (last_used <= DATEADD(day,-3, GETDATE()) or last_used is null)"
            cursor.execute(sql)
            table_Data = cursor.fetchone()
            if table_Data:
                available_balance = table_Data.giftcard_balance if table_Data.giftcard_balance else 0
                available_balance = '{0:.2f}'.format(float(available_balance))
            snapshot2 = {'total_order': total_order, 'total_item': total_item, 'total_cost': total_cost,
                         'avail_balance': available_balance}
            return jsonify(snapshot2)
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('index'))


@app.route('/buyingdatatable', methods=['POST'])
def buyingdatatable():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        if request.method == 'POST':
            import datetime
            from collections import Counter
            buying_obj = BuyingManager()
            content = request.json
            columns = content['columns']
            # initially start show 0 & on click next it will increased accroding to defined rows in the table  (Display index for the first record shown on the current page)
            offset = content['start']
            # Display length (number of records) use --> used in fetch to get no of next records from the database
            length = content['length']
            # the search field for the datatables
            search = content['search']
            searchbox = search['value'].strip()
            searchbox = "{" if searchbox.startswith("'") else searchbox
            searchbox = "{" if searchbox.startswith("-") else searchbox
            searchbox = "{" if searchbox.startswith(";") else searchbox
            # filter for status using upper dropdown
            columns_status = columns[3]
            # print('columns_status', columns_status)
            columns_status_search = columns_status['search']['value']
            # print(columns_status_search)
            if columns_status_search == 'Status':
                columns_status_search = ''
            elif columns_status_search == 'All':
                columns_status_search = ''
            columns_date = columns[2]
            # print('columns_date', columns_date)
            columns_date_search = columns_date['search']['value']
            # print(columns_date)
            if columns_date_search == 'DateRange':
                columns_date_search = ''
            elif columns_date_search == 'All':
                columns_date_search = ''

            orderable = content['order']
            sorting = ["[buyingmaster].[priority]" if orderable[0]['column'] == 1 else (
                    'max([buyingmaster].[Date_creation])' if orderable[0]['column'] == 2 else (
                        'subtotal' if orderable[0]['column'] == 5 else (
                            'count(item_sku)' if orderable[0]['column'] == 4 else (
                            'order_count' if orderable[0]['column'] == 6 else (
                                'completed_count' if orderable[0]['column'] == 7 else (
                                    'cancelled_count' if orderable[0]['column'] == 8 else (
                                        'unfulfilled' if orderable[0]['column'] == 9 else (
                                            'status' if orderable[0]['column'] == 3 else (
                                                'reason' if orderable[0]['column'] == 10 else (
                                                ))))))))))]
            direction = orderable[0]['dir']

            today = datetime.datetime.now()
            lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
            date1, date2 = (
                (today - datetime.timedelta(days=6)).date(), today.date()) if columns_date_search == 'Last7days' else (
                ((today - datetime.timedelta(days=today.weekday())).date(),
                 today.date()) if columns_date_search == "ThisWeek" else (
                    ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                     lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                        (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                            (today - datetime.timedelta(days=30)).date(),
                            today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                            datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                            datetime.date.strftime(datetime.datetime.strptime(columns_date_search[18:28],
                            '%m-%d-%Y'), "%Y-%m-%d")) if len(
                            columns_date_search) == 28 else ("", "")))))

            ### Set Priority button functionality ----->
            json_move_data = content['move_data']
            # print(json_move_data)
            if len(json_move_data) != 0:
                move_direction = json_move_data['direction']
                row_data1 = json_move_data['row_data1']
                row_data2 = json_move_data['row_data2']
                if move_direction == "up" or move_direction == "down":
                    sql = "UPDATE [dbo].[buyingmaster] SET [priority] = ? WHERE [cart_id]=?"
                    cart_id1 = row_data1['Id']
                    priority1 = row_data1['Priority']
                    cart_id2 = row_data2['Id']
                    priority2 = row_data2['Priority']
                    val = (priority1, cart_id2)
                    cursor.execute(sql, val)
                    cursor.commit()
                    sql = "UPDATE [dbo].[buyingmaster] SET [priority] = ? WHERE [cart_id]=?"
                    val = (priority2, cart_id1)
                    cursor.execute(sql, val)
                    cursor.commit()

            ## RANGE SLIDER VALUE ---- >
            custom_filter = False
            column_subtotal_range = content['subtotal_range']
            # print("Subtotal Range ", column_subtotal_range)
            column_successrate_range = content['successrate_range']
            # print("Successrate Range ", column_successrate_range)
            column_fulfillmentratio_range = content['fulfillmentratio_range']
            # print("Fulfillment Range ", column_fulfillmentratio_range)
            column_completed_range = content['completed_range']
            # print("Completed Range ", column_completed_range)
            column_item_sku_range = content['item_sku_range']
            # print("Item Sku Range ", column_item_sku_range)
            column_order_range = content['order_range']
            # print("Order Range ", column_order_range)

            custom_items = [column_subtotal_range, column_successrate_range, column_fulfillmentratio_range,
                            column_completed_range, column_item_sku_range, column_order_range]
            # print(custom_items)
            custom_filter = any(custom_items)

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            PRIORITY_TASK = True
            if columns_date_search != "":
                PRIORITY_TASK = False
                query_shorter.append("CAST([buyingmaster].[Date_creation] AS DATE) between '" + str(
                    date1) + "' and '" + str(
                    date2) + "'")
            if columns_status_search != "":
                PRIORITY_TASK = False
                query_shorter.append("[buyingmaster].[status] = '" + str(columns_status_search) + "'")
            if searchbox != "":
                PRIORITY_TASK = False
                search = "([priority] LIKE '{}%' OR [item_sku] LIKE '{}%' OR CONVERT (varchar(10), [buyingmaster].[Date_creation],110) LIKE '{}%' OR [status] LIKE '{}%' OR [reason] LIKE '{}%' OR [subtotal] LIKE '{}%' OR [order_count] LIKE '{}%' OR [completed_count] LIKE '{}%' OR [cancelled_count] LIKE '{}%' OR [unfulfilled] LIKE '{}%')".format(
                    searchbox, searchbox, searchbox, searchbox, searchbox,
                    searchbox, searchbox, searchbox, searchbox, searchbox)
                query_shorter.append(search)
            if len(sorting[0]) != 0:
                PRIORITY_TASK = False
                custom_sorting = sorting[0]
                custom_direction = direction

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            if PRIORITY_TASK:
                sql_priority = "SELECT [buyingmaster].[cart_id], [priority], [status] FROM [dbo].[buyingmaster] group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status] ORDER BY min([buyingmaster].[priority]) ASC, max([buyingmaster].[Date_creation]) DESC"
                cursor.execute(sql_priority)
                priority_data = cursor.fetchall()
                loop_locker = False
                if len(priority_data) != 0:
                    if priority_data[0].priority <= 0 or priority_data[0].priority != 1:
                        loop_locker = True
                    if loop_locker is not True:
                        priority_duplicates = dict(Counter([i[1] for i in priority_data]))
                        check_duplicates = [k for k, v in priority_duplicates.items() if v > 1]
                        get_number_list = [i[1] for i in priority_data]
                        missing_number = getMissingNo(get_number_list)
                        if len(check_duplicates) != 0:
                            loop_locker = True
                        elif int(missing_number) != 0:
                            loop_locker = True
                    if loop_locker:
                        for i in range(len(priority_data)):
                            update_sql = "UPDATE [dbo].[buyingmaster] SET [priority] = ? WHERE [cart_id]=?"
                            val = (i + 1, priority_data[i].cart_id)
                            cursor.execute(update_sql, val)
                            cursor.commit()

            if custom_filter:
                query_shorter, having_query = [], ""
                if len(column_subtotal_range) != 0:
                    query_shorter.append("subtotal BETWEEN '" + str(column_subtotal_range[0]) + "' AND '" + str(
                        column_subtotal_range[1]) + "'")
                if len(column_successrate_range) != 0:
                    query_shorter.append("completed_count BETWEEN '" + str(column_successrate_range[0]) + "' AND '" + str(
                        column_successrate_range[1]) + "'")
                if len(column_fulfillmentratio_range) != 0:
                    query_shorter.append("completed_count BETWEEN '" + str(column_fulfillmentratio_range[0]) + "' AND '" + str(
                        column_fulfillmentratio_range[1]) + "'")
                if len(column_completed_range) != 0:
                    query_shorter.append("completed_count BETWEEN '" + str(column_completed_range[0]) + "' AND '" + str(
                        column_completed_range[1]) + "'")
                if len(column_item_sku_range) != 0:
                    query_shorter.append("count(item_sku) BETWEEN '" + str(column_item_sku_range[0]) + "' AND '" + str(
                        column_item_sku_range[1]) + "'")
                if len(column_order_range) != 0:
                    query_shorter.append("order_count BETWEEN '" + str(column_order_range[0]) + "' AND '" + str(
                        column_order_range[1]) + "'")

                if len(query_shorter) == 0:
                    having_query = ''
                elif len(query_shorter) == 1:
                    having_query = ''.join(query_shorter)
                else:
                    having_query = ' AND '.join(query_shorter)

                sql = buying_obj.buyingmanagerrangequeryforcount(having_query, custom_query)
                cursor.execute(sql)
                # fetching buying details
                count = cursor.fetchall()
                # print("count", count)
                no_of_records = len(count)
                # print("no_of_records", no_of_records)

                sql = buying_obj.buyingmanagerrangequery(offset, length, having_query, custom_query, custom_sorting, custom_direction)
                print(sql)
                cursor.execute(sql)
            else:
                sql = buying_obj.buyingmanagerqueryforcount(custom_query)
                cursor.execute(sql)
                # fetching buying details
                count = cursor.fetchall()
                # print("count", count)
                no_of_records = len(count)
                # print("no_of_records", no_of_records)

                sql = buying_obj.buyingmanagerquery(offset, length, custom_query, custom_sorting, custom_direction)
                print(sql)
                cursor.execute(sql)
            tableData = cursor.fetchall()
            buying_list = []
            for buying in tableData:
                cart_id = buying.cart_id
                status = "No Status"
                if buying.status:
                    status = buying.status
                reason = "No Status"
                if buying.reason:
                    reason = buying.reason
                subtotal = 0
                if buying.subtotal:
                    subtotal = '{0:.2f}'.format(float(buying.subtotal))
                projected_cost = 0
                if buying.projected_cost:
                    projected_cost = '{0:.2f}'.format(float(buying.projected_cost))
                final_cost = 0
                if buying.final_cost:
                    final_cost = '{0:.2f}'.format(float(buying.final_cost))
                unfulfilled = 0
                if status != 'Active':
                    unfulfilled = buying.unfulfilled
                buying_data = {
                    'Id': cart_id,
                    'Edit': buying.cart_id,
                    'Priority': buying.priority,
                    'Date': buying.creationDate,
                    'Status': status,
                    'Skus': buying.skus,
                    'Subtotal': subtotal,
                    'Orders': buying.order_count,
                    'Completed': buying.completed_count,
                    'Cancelled': buying.cancelled_count,
                    'Unfulfilled': unfulfilled,
                    'Reason': reason,
                    'ProjectedCost': projected_cost,
                    'FinalCost': final_cost
                }
                buying_list.append(buying_data)
            # buying_data = [{'Id':'1','Edit':'1','Priority':'1','Date':'11-12-2020','Status':'Active','Skus':2,'Subtotal':'50.50','Orders':100,'Completed':50,'Cancelled':25,'Unfulfilled':25,'Reason':'Cancellations','ProjectedCost':'1200.45','FinalCost':'1200'},{'Id':1,'Edit':'2','Priority':'2','Date':'11-12-2020','Status':'Active','Skus':'10','Subtotal':'14000.76','Orders':'5000','Completed':'3500','Cancelled':'1200','Unfulfilled':'300','Reason':'Stock Out','ProjectedCost':'15600.09','FinalCost':'18300.75'}]
            responsedata = {
                "draw": content['draw'],
                "data": buying_list,
                "recordsTotal": no_of_records,
                "recordsFiltered": no_of_records
            }
            return jsonify(responsedata)

def getMissingNo(a):
    missing = a[-1]*(a[-1] + a[0]) / 2 - sum(a)
    return missing

def resetContactDetail(cart_id):
    cursor = condb.cursor()
    sql = "UPDATE [dbo].[addressmaster] SET status=?, last_used=?, address_used=0, is_using=0 WHERE cart_id=?"
    val = ('Active', datetime.now(), cart_id)
    cursor.execute(sql, val)
    cursor.commit()
    sql = "UPDATE [dbo].[emailmaster] SET status=?, last_used=?, email_used=0, is_using=0 WHERE cart_id=?"
    val = ('Active', datetime.now(), cart_id)
    cursor.execute(sql, val)
    cursor.commit()
    sql = "UPDATE [dbo].[phonenumber] SET status=?, last_used=?, phone_used=0, is_using=0 WHERE cart_id=?"
    val = ('Active', datetime.now(), cart_id)
    cursor.execute(sql, val)
    cursor.commit()
    sql = "UPDATE [dbo].[addressmaster] SET cart_id=? WHERE cart_id=?"
    val = (None, cart_id)
    cursor.execute(sql, val)
    cursor.commit()
    sql = "UPDATE [dbo].[emailmaster] SET cart_id=? WHERE cart_id=?"
    val = (None, cart_id)
    cursor.execute(sql, val)
    cursor.commit()
    sql = "UPDATE [dbo].[phonenumber] SET cart_id=? WHERE cart_id=?"
    val = (None, cart_id)
    cursor.execute(sql, val)
    cursor.commit()
    return True

@app.route('/selectallbuying', methods=['POST'])
def selectallBuying():
    try:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # Create object for ordertracking
            buying_obj = BuyingManager()

            # getting all json data from the datatable
            content = request.json
            print(content)

            get_ids = content['get_ids']
            # print('get ids', get_ids)

            unSelectArr = content['unSelectArr']
            # print('unSelectArr', unSelectArr)

            if len(unSelectArr) == 1:
                unSelectArr.append('0')
            else:
                unSelectArr
            unSelectArr = tuple(unSelectArr)

            records = content['records']

            statusValue = content['statusValue']
            # print(statusValue)
            columns_status_search = ('' if statusValue == 'Status' else statusValue)

            columns_date = content['dateValue']
            # print(columns_date)
            columns_date_search = ("" if columns_date == "DateRange" else columns_date)

            searchbox = str(content['searchValue']).strip()
            # print(searchbox)

            select_all = content['selectall']
            # print(select_all)

            today = datetime.datetime.now()
            lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
            date1, date2 = (
                (today - datetime.timedelta(days=6)).date(), today.date()) if columns_date_search == 'Last7days' else (
                ((today - datetime.timedelta(days=today.weekday())).date(),
                 today.date()) if columns_date_search == "ThisWeek" else (
                    ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                     lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                        (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                            (today - datetime.timedelta(days=30)).date(),
                            today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                            datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                        datetime.date.strftime(
                                                                                            datetime.datetime.strptime(
                                                                                                columns_date_search[
                                                                                                18:28],
                                                                                                '%m-%d-%Y'),
                                                                                            "%Y-%m-%d")) if len(
                            columns_date_search) == 28 else ("", "")))))

            ## RANGE SLIDER VALUE ---- >
            custom_filter = False
            column_subtotal_range = content['subtotal_range']
            # print("Subtotal Range ", column_subtotal_range)
            column_successrate_range = content['successrate_range']
            # print("Successrate Range ", column_successrate_range)
            column_fulfillmentratio_range = content['fulfillmentratio_range']
            # print("Fulfillment Range ", column_fulfillmentratio_range)
            column_completed_range = content['completed_range']
            # print("Completed Range ", column_completed_range)
            column_item_sku_range = content['item_sku_range']
            # print("Item Sku Range ", column_item_sku_range)
            column_order_range = content['order_range']
            # print("Order Range ", column_order_range)

            custom_items = [column_subtotal_range, column_successrate_range, column_fulfillmentratio_range,
                            column_completed_range, column_item_sku_range, column_order_range]
            # print(custom_items)
            custom_filter = any(custom_items)

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            if columns_date_search != "":
                query_shorter.append("CAST([buyingmaster].[Date_creation] AS DATE) between '" + str(
                    date1) + "' and '" + str(
                    date2) + "'")
            if columns_status_search != "":
                query_shorter.append("[buyingmaster].[status] = '" + str(columns_status_search) + "'")
            if searchbox != "":
                search = "([priority] LIKE '{}%' OR [item_sku] LIKE '{}%' OR CONVERT (varchar(10), [buyingmaster].[Date_creation],110) LIKE '{}%' OR [status] LIKE '{}%' OR [reason] LIKE '{}%' OR [subtotal] LIKE '{}%' OR [order_count] LIKE '{}%' OR [completed_count] LIKE '{}%' OR [cancelled_count] LIKE '{}%' OR [unfulfilled] LIKE '{}%')".format(
                    searchbox, searchbox, searchbox, searchbox, searchbox,
                    searchbox, searchbox, searchbox, searchbox, searchbox)
                query_shorter.append(search)
            if len(unSelectArr) != 0:
                query_shorter.append("order_number NOT IN {}".format(
                    unSelectArr))

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            if custom_filter:
                query_shorter, having_query = [], ""
                if len(column_subtotal_range) != 0:
                    query_shorter.append("subtotal BETWEEN '" + str(column_subtotal_range[0]) + "' AND '" + str(
                        column_subtotal_range[1]) + "'")
                if len(column_successrate_range) != 0:
                    query_shorter.append(
                        "completed_count BETWEEN '" + str(column_successrate_range[0]) + "' AND '" + str(
                            column_successrate_range[1]) + "'")
                if len(column_fulfillmentratio_range) != 0:
                    query_shorter.append(
                        "completed_count BETWEEN '" + str(column_fulfillmentratio_range[0]) + "' AND '" + str(
                            column_fulfillmentratio_range[1]) + "'")
                if len(column_completed_range) != 0:
                    query_shorter.append("completed_count BETWEEN '" + str(column_completed_range[0]) + "' AND '" + str(
                        column_completed_range[1]) + "'")
                if len(column_item_sku_range) != 0:
                    query_shorter.append("count(item_sku) BETWEEN '" + str(column_item_sku_range[0]) + "' AND '" + str(
                        column_item_sku_range[1]) + "'")
                if len(column_order_range) != 0:
                    query_shorter.append("order_count BETWEEN '" + str(column_order_range[0]) + "' AND '" + str(
                        column_order_range[1]) + "'")

                if len(query_shorter) == 0:
                    having_query = ''
                elif len(query_shorter) == 1:
                    having_query = ''.join(query_shorter)
                else:
                    having_query = ' AND '.join(query_shorter)

                sql = buying_obj.buyingmanagerselectallwithhaving(having_query, custom_query)
            else:
                sql = buying_obj.buyingmanagerselectallwithouthaving(custom_query)

            if get_ids == True:
                checkboxesArray = []
                # getting id of the selected filters
                if len(unSelectArr) == 0:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
                else:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
            else:
                cursor.execute(sql)
                # fetching giftcardl
                batch_count = cursor.fetchall()
                no_of_records = len(batch_count)

            if get_ids == True:
                return json.dumps({"arr": checkboxesArray})
            else:
                return json.dumps({'total_record': no_of_records})
    except Exception as e:
        print(e)

@app.route('/buyingdetails', methods=['POST'])
def buyingdetails():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        if request.method == 'POST':
            id = request.args['id']
            sql = "SELECT [id],[cart_id],[item_sku],[price],[qty_percart],[unit_total],[projected_cost],[final_cost],[unit_ordered],[unit_cancelled] FROM [dbo].[buyingmaster] WHERE [buyingmaster].[cart_id]=?"
            cursor.execute(sql,id)
            tableData = cursor.fetchall()
            buying_list = []
            for buying in tableData:
                price = 0
                if buying.price:
                    price = '{0:.2f}'.format(float(buying.price))
                projected_cost = 0
                if buying.projected_cost:
                    projected_cost = '{0:.2f}'.format(float(buying.projected_cost))
                final_cost = 0
                if buying.final_cost:
                    final_cost = '{0:.2f}'.format(float(buying.final_cost))
                buying_data = {
                    'Id':buying.id,
                    'Item_Sku':buying.item_sku,
                    'Price':price,
                    'Qty_Per_Cart':buying.qty_percart,
                    'Total_Unit':buying.unit_total,
                    'ProjectedCost':projected_cost,
                    'UnitOrders':buying.unit_ordered,
                    'UnitCancelled':buying.unit_cancelled,
                    'FinalCost':final_cost
                }
                buying_list.append(buying_data)
            # buying_data = [{'Id':'2','Item_Sku':'ER12224','Price':'45.76','Qty_Per_Cart':'500','Total_Unit':'350','ProjectedCost':'123.50','UnitOrders':'200','UnitCancelled':'120','FinalCost':'500'}]
            responsedata = {
            'data':buying_list
            }
            return jsonify(responsedata)

@app.route('/editbuying', methods=['POST','PUT'])
def editbuying():
    data = {}
    try:
        if 'password' and 'email' in session:
            companyid = session["companyid"]
            cursor = condb.cursor()
            cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
            accessdata = cursor.fetchall()
            if len(accessdata) != 0:
                if accessdata[0].buying == 1:
                    if request.method == 'POST':
                        cart_id = request.args['id']
                        print(cart_id)
                        sql = "SELECT [id],[item_sku],[price],[qty_percart],[unit_total] FROM [dbo].[buyingmaster] WHERE [buyingmaster].[cart_id]=?"
                        cursor.execute(sql, cart_id)
                        tableData = cursor.fetchall()
                        item_count = 0
                        product_details = []
                        for item in tableData:
                            item_detail = {}
                            item_detail['item_sku']=item.item_sku
                            item_detail['price']=item.price
                            item_detail['qty_per']=item.qty_percart
                            item_detail['tot_unit']=item.unit_total
                            item_detail['id'] = item.id
                            product_details.append(item_detail)
                            item_count += item.unit_total

                        sql = "SELECT TOP (1) shipping, tax, cart_id,subtotal,total_cost,order_count FROM [dbo].[buyingmaster] WHERE [buyingmaster].[cart_id]=?"
                        cursor.execute(sql, cart_id)
                        tableData = cursor.fetchall()
                        cart_details = {}
                        for item in tableData:
                            cart_details['cart_subtotal']=item.subtotal
                            cart_details['cart_total']=item.total_cost
                            cart_details['cart_id']=item.cart_id
                            cart_details['order_count']=item.order_count
                            cart_details['items_count'] = item_count
                            shipping,tax = False,False
                            if int(item.shipping) != 0:
                                shipping = True
                            if int(item.tax) != 0:
                                tax = True
                            cart_details['shipping'] = shipping
                            cart_details['tax'] = tax

                        sql = "SELECT id, address_ids, email_ids FROM [dbo].[buyingitems] WHERE [buyingitems].[cart_id]=?"
                        cursor.execute(sql, cart_id)
                        tableData = cursor.fetchall()
                        address_details, id_collect, email_details = [], [], []
                        phone_details = contact_details = {}
                        for item in tableData:
                            address_item = item.address_ids.split(",")
                            if type(address_item) == list:
                                address_details = address_item
                            else:
                                address_details.append(address_item)

                            email_item = item.email_ids.split(",")
                            if type(email_item) == list:
                                email_details = email_item
                            else:
                                email_details.append(email_item)
                            id_collect.append(item.id)

                        contact_details['address'] = ','.join(str(x) for x in address_details)
                        contact_details['email'] = ','.join(str(x) for x in email_details)
                        contact_details['id'] = ','.join(str(x) for x in id_collect)

                        data['status'] = 200
                        data['product_detail'] = product_details
                        data['cart_detail'] = cart_details
                        data['contact_detail'] = contact_details
                        data['address_detail'] = address_details
                        data['email_detail'] = email_details
                        return json.dumps(data)
                    elif request.method == 'PUT':
                        row_num = request.form.get('norow')
                        qtypercart = request.form.get('qtypercart-1')
                        totalunit = request.form.get('totalunit-1')
                        loopvalue = int(int(totalunit) / int(qtypercart))
                        cart_detail = request.form.get('cart_detail')
                        total_order = request.form.get('buyingorder')
                        total_item = request.form.get('buyingitem')
                        total_cost = request.form.get('buyingtotalcost')
                        subtotal = request.form.get('subtotalcart')
                        shipping = request.form.get('shipping')
                        tax = request.form.get('tax')
                        cart_id = request.form.get('cart_id')
                        resetContactDetail(cart_id)
                        if shipping is None:
                            shipping = 0
                        else:
                            shipping = int(shipping)
                        if tax is None:
                            tax = 0
                        else:
                            tax = int(tax)
                        addresslist = request.form.getlist('addresslist')
                        emaillist = request.form.getlist('emaillist')
                        address_detail = request.form.get('address_detail')
                        email_detail = request.form.get('email_detail')
                        address_collect,email_collect,phone_collect=[],[],[]
                        contact_status = False
                        #### Address List
                        if addresslist[0] != 'All':
                            total = int(int(total_order) / len(addresslist))
                            reminder = int(int(total_order) % len(addresslist))
                            for parent_id in addresslist:
                                sql = "SELECT TOP ({0}) id, full_address, status, address_used, last_used from [dbo].[addressmaster] where status = '{1}' and parent_id = '{2}'".format(
                                    total, 'Active', parent_id)
                                cursor.execute(sql)
                                address_record = cursor.fetchall()
                                for rec in address_record:
                                    address_data = {}
                                    address_data.update({'id': rec.id})
                                    address_data.update({'address': rec.full_address})
                                    address_data.update({'status': rec.status})
                                    address_data.update({'address_used': rec.address_used})
                                    address_data.update({'last_used': rec.last_used})
                                    address_collect.append(address_data)
                            if reminder != 0:
                                for parent_id in addresslist:
                                    sql = "SELECT TOP({0}) id, full_address, status, address_used, last_used from [dbo].[addressmaster] where status = '{1}' and parent_id = '{2}'".format(
                                        1, 'Active', parent_id)
                                    print(sql)
                                    cursor.execute(sql)
                                    address_record = cursor.fetchall()
                                    flag = reminder - 1
                                    for rec in address_record:
                                        address_data = {}
                                        address_data.update({'id': rec.id})
                                        address_data.update({'address': rec.full_address})
                                        address_data.update({'status': rec.status})
                                        address_data.update({'address_used': rec.address_used})
                                        address_data.update({'last_used': rec.last_used})
                                        address_collect.append(address_data)
                                    if (flag == 0):
                                        break
                        else:
                            sql = "SELECT TOP ({0}) id, parent_id, full_address, status, address_used, last_used from [dbo].[addressmaster] where status = '{1}'".format(
                                total_order, 'Active')
                            cursor.execute(sql)
                            address_record = cursor.fetchall()
                            parent_id_set = set()
                            for rec in address_record:
                                parent_id_set.add(str(rec.parent_id))
                                address_data = {}
                                address_data.update({'id': rec.id})
                                address_data.update({'address': rec.full_address})
                                address_data.update({'status': rec.status})
                                address_data.update({'address_used': rec.address_used})
                                address_data.update({'last_used': rec.last_used})
                                address_collect.append(address_data)
                            addresslist = list(parent_id_set)
                        #### EMAIL List
                        if emaillist[0] != 'All':
                            total = int(int(total_order) / len(emaillist))
                            reminder = int(int(total_order) % len(emaillist))
                            for parent_id in emaillist:
                                sql = "SELECT TOP ({0}) id, email, status, email_used, last_used from [dbo].[emailmaster] where status = '{1}' and parent_id = '{2}'".format(
                                    total, 'Active', parent_id)
                                cursor.execute(sql)
                                email_record = cursor.fetchall()
                                for rec in email_record:
                                    email_data = {}
                                    email_data.update({'id': rec.id})
                                    email_data.update({'email': rec.email})
                                    email_data.update({'status': rec.status})
                                    email_data.update({'email_used': rec.email_used})
                                    email_data.update({'last_used': rec.last_used})
                                    email_collect.append(email_data)
                            if reminder != 0:
                                for parent_id in emaillist:
                                    sql = "SELECT TOP({0}) id, email, status, email_used, last_used from [dbo].[emailmaster] where status = '{1}' and parent_id = '{2}'".format(
                                        1, 'Active', parent_id)
                                    cursor.execute(sql)
                                    email_record = cursor.fetchall()
                                    flag = reminder - 1
                                    for rec in email_record:
                                        email_data = {}
                                        email_data.update({'id': rec.id})
                                        email_data.update({'email': rec.email})
                                        email_data.update({'status': rec.status})
                                        email_data.update({'email_used': rec.email_used})
                                        email_data.update({'last_used': rec.last_used})
                                        email_collect.append(email_data)
                                    if (flag == 0):
                                        break
                        else:
                            sql = "SELECT TOP ({0}) id, parent_id, email, status, email_used, last_used FROM [dbo].[emailmaster] where status = '{1}'".format(
                                total_order, 'Active')
                            cursor.execute(sql)
                            email_record = cursor.fetchall()
                            parent_id_set = set()
                            for rec in email_record:
                                parent_id_set.add(str(rec.parent_id))
                                email_data = {}
                                email_data.update({'id': rec.id})
                                email_data.update({'email': rec.email})
                                email_data.update({'status': rec.status})
                                email_data.update({'email_used': rec.email_used})
                                email_data.update({'last_used': rec.last_used})
                                email_collect.append(email_data)
                            emaillist = list(parent_id_set)

                        sql = "SELECT TOP ({0}) id, phone, status, phone_used, last_used from [dbo].[phonenumber] where status = '{1}'".format(
                            total_order, 'Active')
                        cursor.execute(sql)
                        phone_record = cursor.fetchall()
                        for rec in phone_record:
                            phone_data = {}
                            phone_data.update({'id': rec.id})
                            phone_data.update({'phone': rec.phone})
                            phone_data.update({'status': rec.status})
                            phone_data.update({'phone': rec.phone})
                            phone_data.update({'last_used': rec.last_used})
                            phone_collect.append(phone_data)

                        update_cart_detail = False
                        i = 0
                        while i < int(row_num):
                            i += 1
                            dataID = request.form.get('dataID-' + str(i))
                            sku = request.form.get('sku-' + str(i))
                            price = request.form.get('price-' + str(i))
                            qtypercart = request.form.get('qtypercart-' + str(i))
                            totalunit = request.form.get('totalunit-' + str(i))
                            loopvalue = int(totalunit) / int(qtypercart)
                            sql = "UPDATE [dbo].[buyingmaster] SET item_sku = ?, price=?, qty_percart=?, unit_total=?, shipping=?, tax=?, subtotal=?, total_cost=?, order_count=? WHERE id =?"
                            val = (sku, price, qtypercart, totalunit, shipping, tax, subtotal, total_cost, total_order, dataID)
                            cursor.execute(sql, val)
                            cursor.commit()
                            update_cart_detail = True

                        sql = "UPDATE [dbo].[buyingmaster] SET [Date_modify] = ? WHERE cart_id =?"
                        val = (datetime.now(),cart_id)
                        cursor.execute(sql, val)
                        cursor.commit()

                        if update_cart_detail:
                            cart_loop = int(loopvalue)
                            address_collect_str = ','.join(addresslist)
                            email_collect_str = ','.join(emaillist)
                            for address in address_collect:
                                sql = "UPDATE [dbo].[addressmaster] SET status=?, cart_id=?, last_used=? WHERE id=?"
                                val = ('Inactive', cart_id, datetime.now(), address['id'])
                                cursor.execute(sql, val)
                                cursor.commit()
                            for email in email_collect:
                                sql = "UPDATE [dbo].[emailmaster] SET status=?, cart_id=?, last_used=? WHERE id=?"
                                val = ('Inactive', cart_id, datetime.now(), email['id'])
                                cursor.execute(sql, val)
                                cursor.commit()
                            for phone in phone_collect:
                                sql = "UPDATE [dbo].[phonenumber] SET status=?, cart_id=?, last_used=? WHERE phone=?"
                                val = ('Inactive', cart_id, datetime.now(), phone['phone'])
                                cursor.execute(sql, val)
                                cursor.commit()
                            sql = "UPDATE [dbo].[buyingitems] SET [address_ids]=?, [email_ids]=?, [cart_loop]=?, [loop_ount]=?, [Date_modify] = ? WHERE cart_id =?"
                            val = (address_collect_str, email_collect_str, cart_loop, 0, datetime.now(),cart_id)
                            cursor.execute(sql, val)
                            cursor.commit()
                        data['status'] = 201
                        return json.dumps(data)
                else:
                    data['status'] = 400
                    data['message'] = "You are not authorised user."
                    return json.dumps(data)
        else:
            data['status'] = 400
            data['message'] = "You are not authorised user."
            return json.dumps(data)
    except Exception as e:
        print(e)
        data['status'] = 400
        data['message'] = str(e)
        return json.dumps(data)

@app.route('/selectbuyingtable/<len>', methods=['POST', 'GET'])
def selectBuyingTableRows(len):
    status = request.form.get("status")
    cursor = condb.cursor()
    n = 0
    message = "Please click on at least one check box."
    while n < int(len):
        id = request.form.get("id" + str(n))
        type = request.form.get("type" + str(n))
        n += 1
        if status == 'Delete':
            if type == 'parent':
                sql = "SELECT cart_id FROM [dbo].[buyingmaster] where [cart_id] = ?"
            else:
                sql = "SELECT cart_id FROM [dbo].[buyingmaster] where id = ?"
            val = (id,)
            cursor.execute(sql, val)
            cart_info = cursor.fetchone()
            cart_id = None
            if cart_info != None:
                cart_id = cart_info.cart_id

            if type == 'parent':
                if cart_id != None:
                    cursor.execute("DELETE FROM [dbo].[buyingmaster] WHERE cart_id =" + str(id))
                    cursor.commit()
                    cursor.execute("DELETE FROM [dbo].[buyingitems] WHERE cart_id =" + str(cart_id))
                    cursor.commit()
                    print(resetContactDetail(cart_id))
                    message = "Record Deleted"
                else:
                    message = "Can't Deleted"
            else:
                if cart_id != None:
                    cursor.execute("DELETE FROM [dbo].[buyingmaster] WHERE id =" + str(id))
                    cursor.commit()
                    message = "Your Selected Record Deleted"
                else:
                    message = "Can't Deleted"

            if type == 'child':
                if cart_id != None:
                    cursor = condb.cursor()
                    sql = "SELECT cart_id, subtotal, total_cost, price, qty_percart, unit_total FROM [dbo].[buyingmaster] where [cart_id] =  " + str(
                        cart_id)
                    cursor.execute(sql)
                    records = cursor.fetchall()

                    if records.__len__() != 0:
                        subtotal = 0.0
                        unit_total = 0
                        for cart in records:
                            price_calculate = cart.price * cart.qty_percart
                            unit_total = cart.unit_total
                            subtotal += price_calculate
                        total_cost = subtotal * unit_total

                        if subtotal != None:
                            subtotal = float(subtotal)
                            sql = "UPDATE [dbo].[buyingmaster] SET  subtotal = ?, total_cost = ? where cart_id=?"
                            val = (subtotal, total_cost, str(cart_id),)
                            cursor.execute(sql, val)
                            cursor.commit()

                    sql = "SELECT count(id) FROM [dbo].[buyingmaster] where cart_id = ? "
                    val = (cart_id,)
                    cursor.execute(sql, val)
                    data_count = cursor.fetchone()
                    if data_count[0] <= 0:
                        print(resetContactDetail(cart_id))
                        cursor.execute("DELETE FROM [dbo].[buyingitems] WHERE cart_id =" + str(cart_id))
                        cursor.commit()
                        message = "Record Deleted"
                    else:
                        message = "Your Selected Record Deleted"
                else:
                    message = "Can't Deleted"
    return json.dumps({'status': 'OK', "message": message})

@app.route('/addressavailabity', methods=['POST'])
def addressAvailability():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        if request.method == 'POST':
            data = request.json['data']
            item = request.json['items']
            edit = request.json['edit']
            message = "Order Quantity must be required"
            code=403
            address_count = address_count_required = address_avail = 0
            if item != "":
                message = "Address must be required"
                code=402
                if len(data) !=0:
                    if data[0] == 'All':
                        sql = "SELECT count(id) as address FROM [dbo].[addressmaster] WHERE status='Active' AND address_used=0"
                        cursor.execute(sql)
                        address_data = cursor.fetchall()
                        for address in address_data:
                            address_count += address.address
                    else:
                        for dt in data:
                            sql = "SELECT count(id) as address FROM [dbo].[addressmaster] WHERE status='Active' AND address_used=0 AND parent_id={}".format(dt)
                            cursor.execute(sql)
                            address_data = cursor.fetchall()
                            for address in address_data:
                                address_count += address.address
                    if address_count >= int(item):
                        address_count = address_count - int(item)
                        code = 200
                        message = "Address Available"
                    else:
                        code = 401
                        address_count_required = int(item) - address_count
                        message = "Please add more address."
                        item = 0
            result = {"code":code,"message":message,"address_count":address_count,"address_used":item,"required":address_count_required, "edit":edit}
            return jsonify(result)
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('index'))

@app.route('/emailavailabity', methods=['POST'])
def emailAvailability():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        if request.method == 'POST':
            data = request.json['data']
            item = request.json['items']
            edit = request.json['edit']
            message = "Order Quantity must be required"
            code=403
            email_count = email_count_required = email_avail = 0
            if item != "":
                message = "Email must be required"
                code=402
                if len(data) !=0:
                    if data[0] == 'All':
                        sql = "SELECT count(id) as email FROM [dbo].[emailmaster] WHERE status='Active' AND email_used=0"
                        cursor.execute(sql)
                        email_data = cursor.fetchall()
                        for email in email_data:
                            email_count += email.email
                    else:
                        for dt in data:
                            sql = "SELECT count(id) as email FROM [dbo].[emailmaster] WHERE status='Active' AND email_used=0 AND parent_id={}".format(dt)
                            cursor.execute(sql)
                            email_data = cursor.fetchall()
                            for email in email_data:
                                email_count += email.email
                    if email_count >= int(item):
                        email_count = email_count - int(item)
                        code = 200
                        message = "Email Available"
                    else:
                        code = 401
                        email_count_required = int(item) - email_count
                        message = "Please add more email."
                        item = 0
            result = {"code":code, "message":message, "email_count":email_count, "email_used":item, "required":email_count_required, "edit":edit}
            return jsonify(result)
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('index'))

@app.route('/buying-order-detail', methods=['POST', 'GET', 'PUT'])
def buyingorder():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        if len(accessdata) != 0:
            if accessdata[0].ordertracking == 1:
                if request.method == "PUT":
                    # initializing cursor
                    cursor = condb.cursor()
                    # getting update data from the tracking page
                    updatedData = request.json
                    newValue = updatedData['newValue']
                    # print(newValue)
                    order_no = updatedData['id']
                    # print(order_no)
                    columnName = updatedData['cellName']
                    # print(columnName)

                    # sql query for updating ordertracking status
                    sql = "UPDATE [dbo].[ordertracking] SET {} = ? WHERE [dbo].[ordertracking].order_number=?".format(
                        columnName)
                    # execute sql query
                    val = (newValue, order_no)
                    # execute sql query on the basic of gift_card_no & selected id
                    cursor.execute(sql, val)
                    # committing data on the database
                    cursor.commit()
                    return json.dumps({'status': 'OK', "column": columnName})
                elif request.method == "POST":
                    try:
                        import datetime
                        # initializing cursor
                        cursor = condb.cursor()
                        # Create object for ordertracking
                        order_obj = OrderTracking()

                        arguments = request.args
                        cart_id, type = None, None
                        tracking_status = ""
                        if 'id' in arguments:
                            cart_id = arguments['id']
                        if 'type' in arguments:
                            type = arguments['type']
                            if type == '1':
                                tracking_status = "tracking_status != 'Cancelled'"
                            elif type == '2':
                                tracking_status = "tracking_status = 'Cancelled'"

                        # getting all json data from the datatable
                        content = request.json
                        # print(content)
                        # get columns from the content(json data)
                        columns = content['columns']

                        # initially start show 0 & on click next it will increased accroding to defined rows in the table  (Display index for the first record shown on the current page)
                        offset = content['start']
                        # print(offset)
                        # Display length (number of records) use --> used in fetch to get no of next records from the database
                        length = content['length']

                        # the search field for the datatables
                        search = content['search']
                        searchbox = search['value'].strip()
                        searchbox = "{" if searchbox.startswith("'") else searchbox
                        searchbox = "{" if searchbox.startswith("-") else searchbox
                        searchbox = "{" if searchbox.startswith(";") else searchbox
                        # print(search['value'])
                        # print(len(search['value']))

                        # filter for status using upper dropdown
                        columns_status = columns[6]
                        # print('columns_status', columns_status)
                        columns_status_search = columns_status['search']['value']
                        # print(columns_status_search)
                        columns_status_search = ('' if columns_status_search == 'Status' else columns_status_search)
                        print(columns_status_search)

                        orderable = content['order']
                        sorting = ["max(orderedDate)" if orderable[0]['column'] == 1 else (
                            "order_number" if orderable[0]['column'] == 2 else (
                                'sum(qty_cart)' if orderable[0]['column'] == 3 else (
                                    'cart_total' if orderable[0]['column'] == 4 else (
                                        'no_of_gc' if orderable[0]['column'] == 5 else (
                                            'tracking_status' if orderable[0]['column'] == 6 else "")))))]
                        direction = orderable[0]['dir']

                        # filter for date range using upper dropdown
                        columns_date = columns[1]
                        # print('columns_date', columns_date)
                        columns_date = columns_date['search']['value']
                        # print(columns_date)
                        columns_date_search = ("" if columns_date == "DateRange" else columns_date)
                        # print(columns_date_search)
                        # print(len(columns_date_search))

                        today = datetime.datetime.now()
                        lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
                        date1, date2 = (
                            (today - datetime.timedelta(days=6)).date(), today.date()) if columns_date_search == 'Last7days' else (
                            ((today - datetime.timedelta(days=today.weekday())).date(),
                             today.date()) if columns_date_search == "ThisWeek" else (
                                ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                                 lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                                    (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                                        (today - datetime.timedelta(days=30)).date(),
                                        today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                                        datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                                    datetime.date.strftime(
                                                                                                        datetime.datetime.strptime(
                                                                                                            columns_date_search[
                                                                                                            18:28],
                                                                                                            '%m-%d-%Y'),
                                                                                                        "%Y-%m-%d")) if len(
                                        columns_date_search) == 28 else ("", "")))))
                        date1 = str(date1)
                        date2 = str(date2)
                        print(date1, date2)

                        ## RANGE SLIDER VALUE ---- >
                        custom_filter = False
                        column_total_range = content['total_range']
                        # print("Total Range ", column_total_range)
                        column_gc_range = content['gc_range']
                        # print("GC Range ", column_gc_range)
                        column_item_range = content['item_range']
                        # print("Item Range ", column_item_range)
                        custom_items = [column_total_range, column_gc_range, column_item_range]
                        # print(custom_items)
                        custom_filter = any(custom_items)

                        query_shorter, custom_query = [], ""
                        custom_sorting, custom_direction = None, None
                        if columns_date_search != "":
                            query_shorter.append("CAST([orderedDate] AS DATE) between '" + str(
                                date1) + "' and '" + str(
                                date2) + "'")
                        if cart_id != "":
                            query_shorter.append("cart_id = '" +str(cart_id)+ "'")

                        if columns_status_search != "":
                            query_shorter.append("tracking_status = '" + str(columns_status_search) + "'")
                        elif tracking_status !="":
                            query_shorter.append(tracking_status)
                        if len(searchbox) != 0:
                            search_query = "([order_number] LIKE '{}%' OR [cart_total] LIKE '{}%' OR CONVERT (varchar(10), orderedDate,110) LIKE '{}%' OR [tracking_status] LIKE '{}%' OR [no_of_gc] LIKE '{}%' OR [qty_cart] LIKE '{}%')".format(
                                searchbox,searchbox,searchbox,
                                searchbox,searchbox,searchbox)
                            query_shorter.append(search_query)
                        if len(sorting[0]) != 0:
                            custom_sorting = sorting[0]
                            custom_direction = direction

                        if len(query_shorter) == 0:
                            custom_query = ''
                        elif len(query_shorter) == 1:
                            custom_query = ''.join(query_shorter)
                        else:
                            custom_query = ' AND '.join(query_shorter)

                        if custom_filter:
                            query_shorter = []
                            if len(column_total_range) != 0:
                                query_shorter.append("cart_total BETWEEN '" + str(column_total_range[0]) + "' AND '" + str(
                                    column_total_range[1]) + "'")
                            if len(column_gc_range) != 0:
                                query_shorter.append("no_of_gc BETWEEN '" + str(column_gc_range[0]) + "' AND '" + str(
                                    column_gc_range[1]) + "'")
                            if len(column_item_range) != 0:
                                query_shorter.append("sum(qty_cart) BETWEEN '" + str(column_item_range[0]) + "' AND '" + str(
                                    column_item_range[1]) + "'")

                            if len(query_shorter) == 0:
                                having_query = ''
                            elif len(query_shorter) == 1:
                                having_query = ''.join(query_shorter)
                            else:
                                having_query = ' AND '.join(query_shorter)

                            sql = order_obj.ordertrackingrangequeryforcount(having_query, custom_query)
                            # print(sql)
                            cursor.execute(sql)
                            # fetching buying details
                            count = cursor.fetchall()
                            # print("count", count)
                            no_of_records = len(count)
                            # print("no_of_records", no_of_records)

                            sql = order_obj.ordertrackingrangequery(offset, length, having_query, custom_query, custom_sorting, custom_direction)

                            # print(sql)
                            cursor.execute(sql)
                        else:
                            sql = order_obj.ordertrackingqueryforcount(custom_query)
                            # print(sql)
                            cursor.execute(sql)
                            # fetching buying details
                            count = cursor.fetchall()
                            # print("count", count)
                            no_of_records = len(count)
                            # print("no_of_records", no_of_records)

                            sql = order_obj.ordertrackingquery(offset, length, custom_query, custom_sorting, custom_direction)
                            # print(sql)
                            cursor.execute(sql)

                        tableData = cursor.fetchall()
                        # print(tableData)
                        ordertracking_list = []
                        for ot in tableData:
                            cart_total = (0 if ot.cart_total == None else ot.cart_total)
                            sql = "SELECT tracking_status FROM [dbo].[ordertracking] WHERE order_number='" + str(
                                ot.order_number) + "'"
                            cursor.execute(sql)
                            order_status = cursor.fetchall()
                            status_set = set()
                            for ors in order_status:
                                status_set.add(ors.tracking_status)
                            tracking_status = ", ".join(list(status_set))
                            tracking_data = {
                                "id": ot.order_number,
                                "qty_gc": ot.no_of_gc,
                                "qty_cart": ot.qty_cart,
                                "cart_total": round(cart_total, 2),
                                "order_number": ot.order_number,
                                "tracking_status": tracking_status,
                                "Date_creation": ot.creationDate,
                                "view": "view"
                            }
                            ordertracking_list.append(tracking_data)
                        # print(ordertracking_list)

                        responsedata = {
                            "draw": content['draw'],
                            "data": ordertracking_list,
                            "recordsTotal": no_of_records,
                            "recordsFiltered": no_of_records
                        }
                        print(responsedata)
                        return jsonify(responsedata)
                    except Exception as e:
                        print(e)

                arguments = request.args
                cart_id = type = None
                tracking_status = ""
                if 'id' in arguments:
                    cart_id = arguments['id']
                if 'type' in arguments:
                    type = arguments['type']
                    if type == '1':
                        tracking_status = " AND tracking_status != 'Cancelled'"
                    elif type == '2':
                        tracking_status = " AND tracking_status = 'Cancelled'"
                    elif type == 'all':
                        tracking_status = ""
                    else:
                        return redirect(url_for('buying'))
                if 'orderdetail' in arguments:
                    if arguments['orderdetail'] == 'true':
                        pass
                    else:
                        return redirect(url_for('buying'))
                order_obj = OrderTracking()

                ##### SLider data #####
                range_slider_data = {}
                sql = "SELECT MIN([cart_total]) as min_total, MAX([cart_total]) as max_total FROM [dbo].[ordertracking] WHERE cart_id='{0}'{1}".format(cart_id,tracking_status)
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                total_slider = {}
                if None not in table_Data:
                    min_total = int(table_Data.min_total)
                    max_total = int(table_Data.max_total)

                    total_slider['min'] = 0
                    total_slider['from'] = 0

                    if max_total == 0:
                        max_total += 1

                    total_slider['max'] = max_total
                    total_slider['to'] = max_total
                    range_slider_data['total_slider'] = total_slider
                else:
                    total_slider['min'] = 0
                    total_slider['from'] = 0
                    total_slider['max'] = 1
                    total_slider['to'] = 1
                    range_slider_data['total_slider'] = total_slider
                return render_template('orderbuying.html', accessdata=accessdata,
                                       sliderdata=range_slider_data, cart_id=cart_id, type=type)
            else:
                return redirect(url_for('index'))
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('login'))

############### ---------End Buying Page-------------  ########################

############### --------- Order Tracking Page-------------  ########################
@app.route('/ordertracking', methods=['POST', 'GET', 'PUT'])
def ordertracking():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        if len(accessdata) != 0:
            if accessdata[0].ordertracking == 1:
                if request.method == "PUT":
                    # initializing cursor
                    cursor = condb.cursor()
                    # getting update data from the tracking page
                    updatedData = request.json
                    newValue = updatedData['newValue']
                    print(newValue)
                    order_no = updatedData['id']
                    print(order_no)
                    columnName = updatedData['cellName']
                    print(columnName)

                    # sql query for updating ordertracking status
                    sql = "UPDATE [dbo].[ordertracking] SET {} = ? WHERE [dbo].[ordertracking].order_number=?".format(
                        columnName)
                    # execute sql query
                    val = (newValue, order_no)
                    # execute sql query on the basic of gift_card_no & selected id
                    cursor.execute(sql, val)
                    # committing data on the database
                    cursor.commit()
                    if newValue == 'Cancelled':
                        cancelled_status = cancelledOrderForCheckingQueueGC(order_no, newValue)
                    else:
                        sql = "UPDATE [dbo].[giftcardtransaction] SET {} = ? WHERE [dbo].[giftcardtransaction].ordernumber=?".format(
                            "order_purchase_status")
                        # execute sql query
                        val = (newValue, order_no)
                        cursor.execute(sql, val)
                        # committing data on the database
                        cursor.commit()
                    # sql = "SELECT count(DISTINCT order_number) as total_order, COALESCE(SUM(CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Ordered') THEN [ordertracking].[qty_cart] END) END),0) as order_qty, COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Ordered') THEN [ordertracking].[order_number] END) END),0) as order_count, COALESCE(SUM(CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Shipped') THEN [ordertracking].[qty_cart] END) END),0) as shipped_qty, COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Shipped') THEN [ordertracking].[order_number] END) END),0) as shipped_count, COALESCE(SUM(CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Processed') THEN [ordertracking].[qty_cart] END) END),0) as inbound_qty, COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Processed') THEN [ordertracking].[order_number] END) END),0) as inbound_count, COALESCE(SUM(CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Delivered' or [ordertracking].tracking_status='Received') THEN [ordertracking].[qty_cart] END) END),0) as delivered_qty, COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Delivered' or [ordertracking].tracking_status='Received') THEN [ordertracking].[order_number] END) END),0) as delivered_count FROM [dbo].[ordertracking]"
                    order_obj = OrderTracking()
                    today_date = order_obj.customdaterange('Today')
                    custom_query = "CAST([ordertracking].[orderedDate] AS DATE) between '" + str(
                        today_date['date1']) + "' and '" + str(
                        today_date['date2']) + "'"

                    sql = "SELECT count(DISTINCT order_number) as total_order, COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Ordered') THEN [ordertracking].[order_number] END) END),0) as order_count, " \
                          "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Shipped') THEN [ordertracking].[order_number] END) END),0) as shipped_count, " \
                          "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Received') THEN [ordertracking].[order_number] END) END),0) as recieved_count, " \
                          "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Processed') THEN [ordertracking].[order_number] END) END),0) as processed_count, " \
                          "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Cancelled') THEN [ordertracking].[order_number] END) END),0) as cancelled_count, " \
                          "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Delivered') THEN [ordertracking].[order_number] END) END),0) as delivered_count " \
                          "FROM [dbo].[ordertracking]  WHERE {}".format(
                        custom_query)
                    print(sql)
                    cursor.execute(sql)
                    snapshots = cursor.fetchall()
                    json_data = {}
                    for data in snapshots:
                        json_data['total_order'] = data.total_order
                        json_data['order_count'] = data.order_count
                        json_data['shipped_count'] = data.shipped_count
                        json_data['recieved_count'] = data.recieved_count
                        json_data['delivered_count'] = data.delivered_count
                        json_data['processed_count'] = data.processed_count
                        json_data['cancelled_count'] = data.cancelled_count
                    return json.dumps({'status': 'OK', "column": columnName, "data":json_data})

                order_obj = OrderTracking()
                today_date = order_obj.customdaterange('Today')
                custom_query = "CAST([ordertracking].[orderedDate] AS DATE) between '" + str(
                    today_date['date1']) + "' and '" + str(
                    today_date['date2']) + "'"

                sql = "SELECT count(DISTINCT order_number) as total_order, COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Ordered') THEN [ordertracking].[order_number] END) END),0) as order_count, " \
                      "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Shipped') THEN [ordertracking].[order_number] END) END),0) as shipped_count, " \
                      "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Received') THEN [ordertracking].[order_number] END) END),0) as recieved_count, " \
                      "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Processed') THEN [ordertracking].[order_number] END) END),0) as processed_count, " \
                      "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Cancelled') THEN [ordertracking].[order_number] END) END),0) as cancelled_count, " \
                      "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Delivered') THEN [ordertracking].[order_number] END) END),0) as delivered_count " \
                      "FROM [dbo].[ordertracking]  WHERE {}".format(
                    custom_query)
                # print(sql)
                cursor.execute(sql)
                snapshots = cursor.fetchone()

                ##### SLider data #####
                range_slider_data = {}
                sql = "SELECT MIN([cart_total]) as min_total, MAX([cart_total]) as max_total FROM [dbo].[ordertracking]"
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                total_slider = {}
                if None not in table_Data:
                    min_total = int(table_Data.min_total)
                    max_total = int(table_Data.max_total)

                    total_slider['min'] = 0
                    total_slider['from'] = 0

                    if max_total == 0:
                        max_total += 1

                    total_slider['max'] = max_total
                    total_slider['to'] = max_total
                    range_slider_data['total_slider'] = total_slider
                else:
                    total_slider['min'] = 0
                    total_slider['from'] = 0
                    total_slider['max'] = 1
                    total_slider['to'] = 1
                    range_slider_data['total_slider'] = total_slider
                return render_template('order.html', accessdata=accessdata, snapshots=snapshots, sliderdata = range_slider_data)
            else:
                return redirect(url_for('index'))
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('login'))

def cancelledOrderForCheckingQueueGC(order_no=None, status=None):
    cursor = condb.cursor()
    status_count = 0
    sql = "SELECT giftcard_number FROM [dbo].[giftcardtransaction] WHERE ordernumber=?"
    val = (order_no)
    cursor.execute(sql, val)
    giftcard_data = cursor.fetchall()
    if len(giftcard_data)!=0:
        sql = "UPDATE [dbo].[giftcardtransaction] SET order_purchase_status = ?, check_balance = 1  WHERE [dbo].[giftcardtransaction].ordernumber=?"
        # execute sql query
        val = (status, order_no)
        cursor.execute(sql, val)
        # committing data on the database
        cursor.commit()

        sql = "SELECT Max(queue_id) FROM [dbo].[giftcardlist]"
        cursor.execute(sql)
        data = cursor.fetchall()
        queue_id = data[0][0]
        queue_id = queue_id + 1 if queue_id else 1

        for gc_number in giftcard_data:
            sql = "UPDATE [dbo].[giftcardlist] SET [queue_status] = ?, [queue_date] = ?, [queue_id] = ?, [check_balance_status] = ? WHERE [gift_card_no]=?"
            val = ("que", datetime.now(), queue_id, None, gc_number.giftcard_number)
            cursor.execute(sql, val)
            cursor.commit()
            status_count += cursor.rowcount
    return {'status': status_count}


@app.route('/ordertrackingsnapshot', methods=['POST'])
def ordertrackingSnapshot():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        if request.method == 'POST':
            date_filter = request.json['data']
            order_obj = OrderTracking()
            today_date = order_obj.customdaterange(date_filter)
            custom_query = "CAST([ordertracking].[orderedDate] AS DATE) between '" + str(
                today_date['date1']) + "' and '" + str(
                today_date['date2']) + "'"

            sql = "SELECT count(DISTINCT order_number) as total_order, COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Ordered') THEN [ordertracking].[order_number] END) END),0) as order_count, " \
                  "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Shipped') THEN [ordertracking].[order_number] END) END),0) as shipped_count, " \
                  "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Received') THEN [ordertracking].[order_number] END) END),0) as recieved_count, " \
                  "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Processed') THEN [ordertracking].[order_number] END) END),0) as processed_count, " \
                  "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Cancelled') THEN [ordertracking].[order_number] END) END),0) as cancelled_count, " \
                  "COALESCE(COUNT(DISTINCT CASE WHEN [ordertracking].[order_number]!='' THEN (CASE WHEN ([ordertracking].tracking_status='Delivered') THEN [ordertracking].[order_number] END) END),0) as delivered_count " \
                  "FROM [dbo].[ordertracking]  WHERE {}".format(
                custom_query)
            print(sql)
            cursor.execute(sql)
            snapshots = cursor.fetchall()
            snapshot = {'total_order':0,'order_count':0,'shipped_count':0,'recieved_count':0,'delivered_count':0,'processed_count':0,'cancelled_count':0}
            for data in snapshots:
                snapshot['total_order'] = data.total_order
                snapshot['order_count'] = data.order_count
                snapshot['shipped_count'] = data.shipped_count
                snapshot['recieved_count'] = data.recieved_count
                snapshot['delivered_count'] = data.delivered_count
                snapshot['processed_count'] = data.processed_count
                snapshot['cancelled_count'] = data.cancelled_count
            return jsonify(snapshot)
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('index'))

@app.route('/otdatatable', methods=["POST"])
def ordertrackdatatable():
    try:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # Create object for ordertracking
            order_obj = OrderTracking()

            # getting all json data from the datatable
            content = request.json
            # print(content)
            # get columns from the content(json data)
            columns = content['columns']

            # initially start show 0 & on click next it will increased accroding to defined rows in the table  (Display index for the first record shown on the current page)
            offset = content['start']
            # print(offset)
            # Display length (number of records) use --> used in fetch to get no of next records from the database
            length = content['length']

            # the search field for the datatables
            search = content['search']
            searchbox = search['value'].strip()
            searchbox = "{" if searchbox.startswith("'") else searchbox
            searchbox = "{" if searchbox.startswith("-") else searchbox
            searchbox = "{" if searchbox.startswith(";") else searchbox
            # print(search['value'])
            # print(len(search['value']))

            # filter for status using upper dropdown
            columns_status = columns[6]
            # print('columns_status', columns_status)
            columns_status_search = columns_status['search']['value']
            # print(columns_status_search)
            columns_status_search = ('' if columns_status_search == 'Status' else columns_status_search)
            # print(columns_status_search)

            orderable = content['order']
            sorting = ["max(orderedDate)" if orderable[0]['column'] == 1 else (
                "order_number" if orderable[0]['column'] == 2 else (
                    'sum(qty_cart)' if orderable[0]['column'] == 3 else (
                        'cart_total' if orderable[0]['column'] == 4 else (
                            'no_of_gc' if orderable[0]['column'] == 5 else (
                                'tracking_status' if orderable[0]['column'] == 6 else "")))))]
            direction = orderable[0]['dir']

            # filter for date range using upper dropdown
            columns_date = columns[1]
            # print('columns_date', columns_date)
            columns_date = columns_date['search']['value']
            # print(columns_date)
            columns_date_search = ("" if columns_date == "Date Range" else columns_date)
            # print(columns_date_search)
            # print(len(columns_date_search))

            today = datetime.datetime.now()
            lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
            date1, date2 = (
                (today - datetime.timedelta(days=6)).date(), today.date()) if columns_date_search == 'Last7days' else (
                ((today - datetime.timedelta(days=today.weekday())).date(),
                 today.date()) if columns_date_search == "ThisWeek" else (
                    ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                     lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                        (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                            (today - datetime.timedelta(days=30)).date(),
                            today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                            datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                        datetime.date.strftime(
                                                                                            datetime.datetime.strptime(
                                                                                                columns_date_search[
                                                                                                18:28],
                                                                                                '%m-%d-%Y'),
                                                                                            "%Y-%m-%d")) if len(
                            columns_date_search) == 28 else ("", "")))))
            date1 = str(date1)
            date2 = str(date2)
            # print(date1, date2)

            ## RANGE SLIDER VALUE ---- >
            custom_filter = False
            column_total_range = content['total_range']
            # print("Total Range ", column_total_range)
            column_gc_range = content['gc_range']
            # print("GC Range ", column_gc_range)
            column_item_range = content['item_range']
            # print("Item Range ", column_item_range)
            custom_items = [column_total_range, column_gc_range, column_item_range]
            # print(custom_items)
            custom_filter = any(custom_items)

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            if columns_date_search != "":
                query_shorter.append("CAST([orderedDate] AS DATE) between '" + str(
                    date1) + "' and '" + str(
                    date2) + "'")
            if columns_status_search != "":
                query_shorter.append("tracking_status = '" + str(columns_status_search) + "'")
            if len(searchbox) != 0:
                search_query = "([order_number] LIKE '{}%' OR [cart_total] LIKE '{}%' OR CONVERT (varchar(10), orderedDate,110) LIKE '{}%' OR [tracking_status] LIKE '{}%' OR [no_of_gc] LIKE '{}%' OR [qty_cart] LIKE '{}%' OR [carrier] LIKE '{}%' OR [tracking_number] LIKE '{}%')".format(
                    searchbox,searchbox,searchbox,searchbox,
                    searchbox,searchbox,searchbox,searchbox)
                query_shorter.append(search_query)
            if len(sorting[0]) != 0:
                custom_sorting = sorting[0]
                custom_direction = direction

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            if custom_filter:
                query_shorter = []
                if len(column_total_range) != 0:
                    query_shorter.append("cart_total BETWEEN '" + str(column_total_range[0]) + "' AND '" + str(
                        column_total_range[1]) + "'")
                if len(column_gc_range) != 0:
                    query_shorter.append("no_of_gc BETWEEN '" + str(column_gc_range[0]) + "' AND '" + str(
                        column_gc_range[1]) + "'")
                if len(column_item_range) != 0:
                    query_shorter.append("sum(qty_cart) BETWEEN '" + str(column_item_range[0]) + "' AND '" + str(
                        column_item_range[1]) + "'")

                if len(query_shorter) == 0:
                    having_query = ''
                elif len(query_shorter) == 1:
                    having_query = ''.join(query_shorter)
                else:
                    having_query = ' AND '.join(query_shorter)

                sql = order_obj.ordertrackingrangequeryforcount(having_query, custom_query)
                # print(sql)
                cursor.execute(sql)
                # fetching buying details
                count = cursor.fetchall()
                # print("count", count)
                no_of_records = len(count)
                # print("no_of_records", no_of_records)

                sql = order_obj.ordertrackingrangequery(offset, length, having_query, custom_query, custom_sorting, custom_direction)

                # print(sql)
                cursor.execute(sql)
            else:
                sql = order_obj.ordertrackingqueryforcount(custom_query)
                # print(sql)
                cursor.execute(sql)
                # fetching buying details
                count = cursor.fetchall()
                # print("count", count)
                no_of_records = len(count)
                # print("no_of_records", no_of_records)

                sql = order_obj.ordertrackingquery(offset, length, custom_query, custom_sorting, custom_direction)
                # print(sql)
                cursor.execute(sql)

            tableData = cursor.fetchall()
            # print(tableData)
            ordertracking_list = []
            for ot in tableData:
                cart_total = (0 if ot.cart_total == None else ot.cart_total)
                # print(ot)
                sql = "SELECT tracking_status FROM [dbo].[ordertracking] WHERE order_number='"+str(ot.order_number)+"'"
                cursor.execute(sql)
                order_status = cursor.fetchall()
                status_set = set()
                for ors in order_status:
                    status_set.add(ors.tracking_status)
                tracking_status = ", ".join(list(status_set))
                tracking_data = {
                    "id": ot.order_number,
                    "qty_gc": ot.no_of_gc,
                    "qty_cart": ot.qty_cart,
                    "cart_total": '{0:.2f}'.format(float(cart_total)),
                    "order_number": ot.order_number,
                    "tracking_status": tracking_status,
                    "Date_creation": ot.creationDate,
                    "view": "view"
                }
                ordertracking_list.append(tracking_data)
            # print(ordertracking_list)

            responsedata = {
                "draw": content['draw'],
                "data": ordertracking_list,
                "recordsTotal": no_of_records,
                "recordsFiltered": no_of_records
            }
            # print(responsedata)
            return jsonify(responsedata)
    except Exception as e:
        print(e)

# api for deleting the row from the ordertracking table
@app.route('/deletetrackingrows', methods=['DELETE'])
def deleteTrackingRows():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        cursor.execute("SELECT * FROM [dbo].[accessMaster] WHERE [dbo].[accessMaster].id=" + str(companyid))
        accessdata = cursor.fetchall()
        if len(accessdata) != 0:
            if accessdata[0].ordertracking == 1:
                try:
                    if request.method == "DELETE":
                        # initializing cursor
                        cursor = condb.cursor()
                        # getting id of the selected filters
                        checkboxesArray = request.json['checkboxesArray']
                        # print(checkboxesArray)
                        if len(checkboxesArray) != 0:
                            for row in checkboxesArray:
                                sql = "SELECT TOP (1) cart_id, address_id, email_id, phone FROM [dbo].[ordertracking] WHERE order_number=?"
                                # execute sql query
                                cursor.execute(sql, row)
                                records = cursor.fetchone()
                                if records is not None:
                                    cart_id = records.cart_id
                                    address_id = records.address_id
                                    email_id = records.email_id
                                    phone = records.phone
                                    if address_id !="" and address_id != None:
                                        sql = "UPDATE [dbo].[addressmaster] SET address_used=0, is_using=0, last_used=? WHERE id=? and cart_id=?"
                                        val = (datetime.now(), address_id, cart_id)
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                    if email_id !="" and email_id != None:
                                        sql = "UPDATE [dbo].[emailmaster] SET email_used=0, is_using=0, last_used=? WHERE id=? and cart_id=?"
                                        val = (datetime.now(), email_id, cart_id)
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                    if phone !="" and phone != None:
                                        sql = "UPDATE [dbo].[phonenumber] SET phone_used=0, is_using=0, last_used=? WHERE phone=? and cart_id=?"
                                        val = (datetime.now(), phone, cart_id)
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                sql = "DELETE FROM [dbo].[ordertracking] WHERE [dbo].[ordertracking].order_number=?"
                                # execute sql query
                                cursor.execute(sql, row)
                                # committing data on the database
                                cursor.commit()
                                sql = "DELETE FROM [dbo].[giftcardtransaction] WHERE [dbo].[giftcardtransaction].[ordernumber]=?"
                                cursor.execute(sql, row)
                                # committing da`ta on the database
                                cursor.commit()
                            return json.dumps({'status': 'OK'})
                        else:
                            return json.dumps({"code": 404, "error": "Detail not available"})
                except Exception as e:
                    print(e)
            else:
                return redirect(url_for('login'))
        else:
            return redirect(url_for('login'))
    else:
        return redirect(url_for('login'))

@app.route('/ordertrackingselectall', methods=["POST"])
def orderTrackingSelectall():
    try:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # Create object for ordertracking
            order_obj = OrderTracking()

            # getting all json data from the datatable
            content = request.json
            # print(content)

            cart_id, type = None, None
            tracking_status = ""
            if 'cart_id' in content:
                cart_id = content['cart_id']
            if 'type' in content:
                type = content['type']
                if type == '1':
                    tracking_status = "tracking_status != 'Cancelled'"
                elif type == '2':
                    tracking_status = "tracking_status = 'Cancelled'"


            get_ids = content['get_ids']
            # print('get ids', get_ids)

            unSelectArr = content['unSelectArr']
            print('unSelectArr', unSelectArr)

            if len(unSelectArr) == 1:
                unSelectArr.append('0')
            else:
                unSelectArr
            unSelectArr = tuple(unSelectArr)

            records = content['records']

            statusValue = content['statusValue']
            # print(statusValue)
            columns_status_search = ('' if statusValue == 'Status' else statusValue)

            columns_date = content['dateValue']
            # print(columns_date)
            columns_date_search = ("" if columns_date == "DateRange" else columns_date)

            today = datetime.datetime.now()
            lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
            date1, date2 = (
                (today - datetime.timedelta(days=6)).date(), today.date()) if columns_date_search == 'Last7days' else (
                ((today - datetime.timedelta(days=today.weekday())).date(),
                 today.date()) if columns_date_search == "ThisWeek" else (
                    ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                     lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                        (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                            (today - datetime.timedelta(days=30)).date(),
                            today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                            datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                        datetime.date.strftime(
                                                                                            datetime.datetime.strptime(
                                                                                                columns_date_search[
                                                                                                18:28],
                                                                                                '%m-%d-%Y'),
                                                                                            "%Y-%m-%d")) if len(
                            columns_date_search) == 28 else ("", "")))))

            searchbox = str(content['searchValue']).strip()
            # print(searchbox)

            select_all = content['selectall']
            # print(select_all)

            ## RANGE SLIDER VALUE ---- >
            custom_filter = False
            column_total_range = content['total_range']
            # print("Total Range ", column_total_range)
            column_gc_range = content['gc_range']
            # print("GC Range ", column_gc_range)
            column_item_range = content['item_range']
            # print("Item Range ", column_item_range)
            custom_items = [column_total_range, column_gc_range, column_item_range]
            # print(custom_items)
            custom_filter = any(custom_items)

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            if columns_date_search != "":
                query_shorter.append("CAST([orderedDate] AS DATE) between '" + str(
                    date1) + "' and '" + str(
                    date2) + "'")
            if cart_id != "" and cart_id is not None:
                query_shorter.append("cart_id = '" + str(cart_id) + "'")
            if columns_status_search != "":
                query_shorter.append("tracking_status = '" + str(columns_status_search) + "'")
            elif tracking_status != "" and tracking_status is not None:
                query_shorter.append(tracking_status)
            if len(searchbox) != 0:
                search_query = "([order_number] LIKE '{}%' OR [cart_total] LIKE '{}%' OR CONVERT (varchar(10), orderedDate,110) LIKE '{}%' OR [tracking_status] LIKE '{}%' OR [no_of_gc] LIKE '{}%' OR [qty_cart] LIKE '{}%')".format(
                    searchbox, searchbox, searchbox,
                    searchbox, searchbox, searchbox)
                query_shorter.append(search_query)
            if len(unSelectArr) != 0:
                query_shorter.append("order_number NOT IN {}".format(
                    unSelectArr))

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            if custom_filter:
                query_shorter = []
                if len(column_total_range) != 0:
                    query_shorter.append("cart_total BETWEEN '" + str(column_total_range[0]) + "' AND '" + str(
                        column_total_range[1]) + "'")
                if len(column_gc_range) != 0:
                    query_shorter.append("no_of_gc BETWEEN '" + str(column_gc_range[0]) + "' AND '" + str(
                        column_gc_range[1]) + "'")
                if len(column_item_range) != 0:
                    query_shorter.append("sum(qty_cart) BETWEEN '" + str(column_item_range[0]) + "' AND '" + str(
                        column_item_range[1]) + "'")

                if len(query_shorter) == 0:
                    having_query = ''
                elif len(query_shorter) == 1:
                    having_query = ''.join(query_shorter)
                else:
                    having_query = ' AND '.join(query_shorter)
                sql = order_obj.ordertrackingquerywithhaving(havingquery, custom_query)
            else:
                sql = order_obj.ordertrackingquerywithouthaving(custom_query)

            if get_ids == True:
                checkboxesArray = []
                # getting id of the selected filters
                if len(unSelectArr) == 0:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
                else:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
            else:
                cursor.execute(sql)
                # fetching giftcardl
                batch_count = cursor.fetchall()
                no_of_records = len(batch_count)

            if get_ids == True:
                return json.dumps({"arr": checkboxesArray})
            else:
                return json.dumps({'total_record': no_of_records})
    except Exception as e:
        print(e)

@app.route('/exportordertrackinglist', methods=["POST", "GET"])
def exportOrderTrackingList():
    try:
        file_path1 = "./report/ordertracking.xlsx"
        file_path2 = "./report/ordertracking.csv"
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # Create object for ordertracking
            order_obj = OrderTracking()

            # getting all json data from the datatable
            content = request.json
            # print(content)
            cart_id, type = None, None
            tracking_status = ""
            if 'cart_id' in content:
                cart_id = content['cart_id']
            if 'type' in content:
                type = content['type']
                if type == '1':
                    tracking_status = "tracking_status != 'Cancelled'"
                elif type == '2':
                    tracking_status = "tracking_status = 'Cancelled'"

            select_all = content['selectall']
            # print(select_all)

            checkboxesArray = request.json['checkboxesArray']

            reportFormat = request.json['report_format']

            if select_all == 'allrecords':
                unSelectArr = content['unSelectArr']
                # print('unSelectArr', unSelectArr)

                if len(unSelectArr) == 1:
                    unSelectArr.append('0')
                else:
                    unSelectArr
                unSelectArr = tuple(unSelectArr)

                statusValue = content['statusValue']
                # print(statusValue)
                columns_status_search = ('' if statusValue == 'Status' else statusValue)

                columns_date = content['dateValue']
                # print(columns_date)
                columns_date_search = ("" if columns_date == "DateRange" else columns_date)

                today = datetime.datetime.now()
                lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
                date1, date2 = (
                    (today - datetime.timedelta(days=6)).date(),
                    today.date()) if columns_date_search == 'Last7days' else (
                    ((today - datetime.timedelta(days=today.weekday())).date(),
                     today.date()) if columns_date_search == "ThisWeek" else (
                        ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                         lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                            (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                                (today - datetime.timedelta(days=30)).date(),
                                today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                                datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                            datetime.date.strftime(
                                                                                                datetime.datetime.strptime(
                                                                                                    columns_date_search[
                                                                                                    18:28],
                                                                                                    '%m-%d-%Y'),
                                                                                                "%Y-%m-%d")) if len(
                                columns_date_search) == 28 else ("", "")))))

                searchbox = str(content['searchValue']).strip()
                # print(searchbox)

                ## RANGE SLIDER VALUE ---- >
                custom_filter = False
                column_total_range = content['total_range']
                # print("Total Range ", column_total_range)
                column_gc_range = content['gc_range']
                # print("GC Range ", column_gc_range)
                column_item_range = content['item_range']
                # print("Item Range ", column_item_range)
                custom_items = [column_total_range, column_gc_range, column_item_range]
                # print(custom_items)
                custom_filter = any(custom_items)

                query_shorter, custom_query = [], ""
                custom_sorting, custom_direction = None, None
                if columns_date_search != "":
                    query_shorter.append("CAST([orderedDate] AS DATE) between '" + str(
                        date1) + "' and '" + str(
                        date2) + "'")
                if cart_id != "" and cart_id is not None:
                    query_shorter.append("cart_id = '" + str(cart_id) + "'")
                if columns_status_search != "":
                    query_shorter.append("tracking_status = '" + str(columns_status_search) + "'")
                elif tracking_status != "" and tracking_status is not None:
                    query_shorter.append(tracking_status)
                if len(searchbox) != 0:
                    search_query = "([order_number] LIKE '{}%' OR [cart_total] LIKE '{}%' OR CONVERT (varchar(10), orderedDate,110) LIKE '{}%' OR [tracking_status] LIKE '{}%' OR [no_of_gc] LIKE '{}%' OR [qty_cart] LIKE '{}%')".format(
                        searchbox, searchbox, searchbox,
                        searchbox, searchbox, searchbox)
                    query_shorter.append(search_query)
                if len(unSelectArr) != 0:
                    query_shorter.append("order_number NOT IN {}".format(
                        unSelectArr))

                if len(query_shorter) == 0:
                    custom_query = ''
                elif len(query_shorter) == 1:
                    custom_query = ''.join(query_shorter)
                else:
                    custom_query = ' AND '.join(query_shorter)

                if custom_filter:
                    query_shorter = []
                    if len(column_total_range) != 0:
                        query_shorter.append("cart_total BETWEEN '" + str(column_total_range[0]) + "' AND '" + str(
                            column_total_range[1]) + "'")
                    if len(column_gc_range) != 0:
                        query_shorter.append("no_of_gc BETWEEN '" + str(column_gc_range[0]) + "' AND '" + str(
                            column_gc_range[1]) + "'")
                    if len(column_item_range) != 0:
                        query_shorter.append("sum(qty_cart) BETWEEN '" + str(column_item_range[0]) + "' AND '" + str(
                            column_item_range[1]) + "'")

                    if len(query_shorter) == 0:
                        having_query = ''
                    elif len(query_shorter) == 1:
                        having_query = ''.join(query_shorter)
                    else:
                        having_query = ' AND '.join(query_shorter)

                    sql = order_obj.ordertrackingdownloadwithhaving(having_query, custom_query)
                    cursor.execute(sql)
                else:
                    sql = order_obj.ordertrackingdownloadwithouthaving(custom_query)
                    cursor.execute(sql)

            elif len(checkboxesArray) != 0:
                # addding dictionary data into the list
                list_of_orders = []
                for order_id in checkboxesArray:
                    # getting data by joining 2 tables giftcardtransactionlist & giftcardlist
                    sql = "SELECT [order_number], [cart_total], [tracking_status], [no_of_gc], sum(qty_cart) as qty_cart, CONVERT (varchar(10), max(orderedDate) ,110) 'creationDate' FROM [dbo].[ordertracking] WHERE order_number=? group by order_number, no_of_gc, cart_total, tracking_status ORDER BY max(orderedDate) DESC"
                    # execute sql query
                    cursor.execute(sql, order_id)

                    # fetching giftcardlist data from the database
                    ordertracking_data = cursor.fetchone()

                    if ordertracking_data:
                        orderdict = {
                            "DOP": ordertracking_data.creationDate,
                            "Order#": ordertracking_data.order_number,
                            "Items#": ordertracking_data.qty_cart,
                            "Total": ordertracking_data.cart_total,
                            "# of GCs": ordertracking_data.no_of_gc,
                            "Status": ordertracking_data.tracking_status
                        }
                        list_of_orders.append(orderdict)

                    # creating a dataframe of sql records
                df = pd.DataFrame(list_of_orders,
                                  columns=['DOP', 'Order#', 'Items#', 'Total', '# of GCs', 'Status'])

                if reportFormat == "excel":
                    # create the excel file using pandas
                    df.to_excel(file_path1, index=False)
                    # remove the excel file if exist
                    os.remove(file_path2) if os.path.exists(
                        file_path2) else None
                else:
                    # create the excel file using pandas
                    df.to_excel(file_path2, index=False)
                    # remove the excel file if exist
                    os.remove(file_path1) if os.path.exists(
                        file_path1) else None
                return jsonify({"code": 200, "success": "true"})

            # fetching list_of_orders data from the database
            list_of_orders_data = cursor.fetchall()
            # print(list_of_orders_data)

            # addding dictionary data into the list
            list_of_orders = []
            for ordertracking_data in list_of_orders_data:
                orderdict = {
                    "DOP": ordertracking_data.creationDate,
                    "Order#": ordertracking_data.order_number,
                    "Items#": ordertracking_data.qty_cart,
                    "Total": ordertracking_data.cart_total,
                    "# of GCs": ordertracking_data.no_of_gc,
                    "Status": ordertracking_data.tracking_status
                }
                list_of_orders.append(orderdict)

                # creating a dataframe of sql records
            df = pd.DataFrame(list_of_orders,
                              columns=['DOP', 'Order#', 'Items#', 'Total', '# of GCs', 'Status'])

            if reportFormat == "excel":
                # create the excel file using pandas
                df.to_excel(file_path1, index=False)
                # remove the excel file if exist
                os.remove(file_path2) if os.path.exists(
                    file_path2) else None
            else:
                # create the excel file using pandas
                df.to_excel(file_path2, index=False)
                # remove the excel file if exist
                os.remove(file_path1) if os.path.exists(
                    file_path1) else None

            return jsonify({"code": 200, "success": "true"})
        else:
            return send_file(file_path1, mimetype='text/csv',
                             attachment_filename=file_path1,
                             as_attachment=True, cache_timeout=0)
    except Exception as e:
        print(e)
############### ---------End Order Tracking Page-------------  ########################

############### --------- Order Detail Page-------------  ########################
@app.route('/orderdetails', methods=['GET', 'POST', 'DELETE', 'PUT'])
def orderdetails():
    if 'password' and 'email' in session:
        global companyid
        import datetime
        companyid = session["companyid"]
        cursor = condb.cursor()
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        if len(accessdata) != 0:
            if accessdata[0].ordertracking == 1:
                if request.method == "POST":
                    orderNumber = request.args['id']
                    value = (orderNumber)
                    sql = "SELECT COUNT(*) as count FROM [dbo].[ordertracking] where order_number =?"
                    cursor.execute(sql, value)
                    # fetching giftcardl
                    count = cursor.fetchall()
                    no_of_records = len(count)
                    sql = 'SELECT  [id],[item_sku],[price],[qty_cart],[title],[tracking_status],[carrier],[tracking_number] FROM [dbo].[ordertracking] where order_number =?'
                    cursor.execute(sql, value)
                    tableData = cursor.fetchall()
                    print(tableData)
                    order_details = []
                    counter = 0
                    for orderdt in tableData:
                        counter += 1
                        order_id = str(orderdt.id)
                        tracking_record = ""
                        if orderdt.tracking_number:
                            tracking_record = str(orderdt.tracking_number)
                        if orderdt.carrier:
                            if 'UPS' == orderdt.carrier:
                                tracking_number = '<a href="https://www.ups.com/track?loc=en_US&tracknum=' + tracking_record + '&requester=WEMS_1Z/trackdetails" target="_blank">' + tracking_record + '</a><span onclick="edit_tracking(this)" data-toggle="modal" data-target="#con-close-modal-3" data-id="' + order_id + '" data-tracking-number="' + tracking_record + '"> <i class="icon-pencil d-print-none" style="color:blue;"></i> </span>'
                            elif 'FedEx' == orderdt.carrier:
                                tracking_number = '<a href="https://www.fedex.com/fedextrack/?trknbr=' + tracking_record + '" target="_blank">' + tracking_record + '</a><span onclick="edit_tracking(this)" data-toggle="modal" data-target="#con-close-modal-3" data-id="' + order_id + '" data-tracking-number="' + tracking_record + '"> <i class="icon-pencil d-print-none" style="color:blue;"></i> </span>'
                            elif 'USPS' == orderdt.carrier:
                                tracking_number = '<a href="https://tools.usps.com/go/TrackConfirmAction?qtc_tLabels1=' + tracking_record + '" target="_blank">' + tracking_record + '</a><span onclick="edit_tracking(this)" data-toggle="modal" data-target="#con-close-modal-3" data-id="' + order_id + '" data-tracking-number="' + tracking_record + '"> <i class="icon-pencil d-print-none" style="color:blue;"></i> </span>'
                            elif 'Best Buy' == orderdt.carrier:
                                tracking_number = '<a href="https://www.bestbuy.com/profile/ss/guestorderlookup" target="_blank">' + tracking_record + '</a><span onclick="edit_tracking(this)" data-toggle="modal" data-target="#con-close-modal-3" data-id="' + order_id + '" data-tracking-number="' + tracking_record + '"> <i class="icon-pencil d-print-none" style="color:blue;"></i> </span>'
                            else:
                                if tracking_record:
                                    tracking_number = tracking_record + '&nbsp;<span onclick="edit_tracking(this)" data-toggle="modal" data-target="#con-close-modal-3" data-id="' + order_id + '" data-tracking-number="' + tracking_record + '"><i class="icon-pencil d-print-none" style="color:blue;"></i> </span>'
                                else:
                                    tracking_number = 'Click on edit&nbsp;<span onclick="edit_tracking(this)" data-toggle="modal" data-target="#con-close-modal-3" data-id="' + order_id + '" data-tracking-number="' + tracking_record + '"><i class="icon-pencil d-print-none" style="color:blue;"></i> </span>'
                        else:
                            if tracking_record:
                                tracking_number = tracking_record + '&nbsp;<span onclick="edit_tracking(this)" data-toggle="modal" data-target="#con-close-modal-3" data-id="' + order_id + '" data-tracking-number="' + tracking_record + '"><i class="icon-pencil d-print-none" style="color:blue;"></i> </span>'
                            else:
                                tracking_number = 'Click on edit&nbsp;<span onclick="edit_tracking(this)" data-toggle="modal" data-target="#con-close-modal-3" data-id="' + order_id + '" data-tracking-number="' + tracking_record + '"><i class="icon-pencil d-print-none" style="color:blue;"></i> </span>'
                        price = 0.0
                        cost = 0.0
                        if orderdt.price:
                            price = round(orderdt.price, 2)
                        if orderdt.qty_cart:
                            qty_cart = orderdt.qty_cart
                            cost = qty_cart*price
                            cost = round(cost, 2)
                        order_detail_dict = {
                            "counter": counter,
                            "sku": orderdt.item_sku,
                            "price": '{0:.2f}'.format(float(price)),
                            "qty": qty_cart,
                            "cost":'{0:.2f}'.format(float(cost)),
                            "title": orderdt.title,
                            "status": 'Null' if orderdt.tracking_status == None else orderdt.tracking_status,
                            "carrier": orderdt.carrier,
                            "tracking_number": tracking_number,
                            "id": orderdt.id,
                        }
                        order_details.append(order_detail_dict)

                    responsedata = {
                        "data": order_details,
                        "recordsTotal": no_of_records
                    }
                    return jsonify(responsedata)

                elif request.method == "DELETE":
                    records = None
                    try:
                        row_num = str(request.json['row_num'])
                        try:
                            update_time = datetime.datetime.now()
                            sql = "SELECT [order_number], [price], [qty_cart], [subtotal], [cart_total] FROM [dbo].[ordertracking] where id=?"
                            cursor.execute(sql, row_num)
                            order_tracking = cursor.fetchone()
                            order_number = order_tracking.order_number
                            old_price = order_tracking.price
                            old_qty_cart = order_tracking.qty_cart
                            old_sub_total = order_tracking.subtotal
                            old_cart_total = order_tracking.cart_total
                            if not old_sub_total:
                                old_sub_total = 0
                            if not old_cart_total:
                                old_cart_total = 0
                            stotal = float(float(old_price) * int(old_qty_cart))
                            updated_stotal = abs(float(old_sub_total) - float(stotal))
                            updated_ctotal = abs(float(old_cart_total) - float(stotal))
                            updated_stotal = round(updated_stotal, 2)
                            updated_ctotal = round(updated_ctotal, 2)
                            sql = "UPDATE [dbo].[ordertracking] SET [subtotal]=?, [cart_total]=?, [dbo].[ordertracking].[Date_modify] = ? WHERE [dbo].[ordertracking].[order_number]=?"
                            val = (updated_stotal, updated_ctotal, update_time, order_number)
                            cursor.execute(sql, val)
                            cursor.commit()
                        except Exception as e:
                            print(e)
                        sql = "SELECT TOP (1) cart_id, address_id, email_id, phone FROM [dbo].[ordertracking] WHERE order_number=?"
                        # execute sql query
                        cursor.execute(sql, order_number)
                        records = cursor.fetchone()
                        cart_id = None
                        address_id = email_id = phone = 0
                        if records is not None:
                            cart_id = records.cart_id
                            address_id = records.address_id
                            email_id = records.email_id
                            phone = records.phone
                        sql = "DELETE FROM [dbo].[ordertracking] WHERE [dbo].[ordertracking].[id]=?"
                        # execute sql query
                        cursor.execute(sql, row_num)
                        # committing data on the database
                        cursor.commit()
                        if row_num:
                            sql = "SELECT [order_number], [id] FROM [dbo].[ordertracking] where order_number=?"
                            cursor.execute(sql, order_number)
                            order_tracking = cursor.fetchall()
                            if len(order_tracking) == 0:
                                if cart_id is not None:
                                    if address_id != "" and address_id != None:
                                        sql = "UPDATE [dbo].[addressmaster] SET address_used=0, is_using=0, last_used=? WHERE id=? and cart_id=?"
                                        val = (datetime.datetime.now(), address_id, cart_id)
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                    if email_id != "" and email_id != None:
                                        sql = "UPDATE [dbo].[emailmaster] SET email_used=0, is_using=0, last_used=? WHERE id=? and cart_id=?"
                                        val = (datetime.datetime.now(), email_id, cart_id)
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                    if phone != "" and phone != None:
                                        sql = "UPDATE [dbo].[phonenumber] SET phone_used=0, is_using=0, last_used=? WHERE phone=? and cart_id=?"
                                        val = (datetime.datetime.now(), phone, cart_id)
                                        cursor.execute(sql, val)
                                        cursor.commit()
                                sql = "DELETE FROM [dbo].[giftcardtransaction] WHERE [dbo].[giftcardtransaction].[ordernumber]=?"
                                cursor.execute(sql, order_number)
                                # committing data on the database
                                cursor.commit()
                            return json.dumps({'status': 'OK'})
                        return json.dumps({"code": 400, "error": "data not found"})
                    except Exception as e:
                        print(e)
                        return json.dumps({"code": 400, "error": str(e)})

                elif request.method == "PUT":
                    try:
                        selected_id = request.json['id']
                        update_time = datetime.datetime.now()
                        print(selected_id)
                        # get python current time
                        cell_name = request.json['cellName']
                        column_name = cell_name
                        if cell_name == "sku":
                            cell_name = "item_sku"
                        elif cell_name == "qty":
                            cell_name = "qty_cart"
                        new_value = request.json['newValue']
                        if '$' in new_value:
                            new_value = round(float(new_value.replace('$', '')), 2)
                        # sql query for updating date of the giftcard list on the basis of id
                        sql = "UPDATE [dbo].[ordertracking] SET [ordertracking].[{}] = ?, [ordertracking].[Date_modify] = ? WHERE [ordertracking].[id]=?".format(
                            cell_name)
                        val = (new_value, update_time, selected_id)
                        cursor.execute(sql, val)
                        # committing data on the database
                        cursor.commit()
                        if cell_name == "qty_cart" or cell_name == "price":
                            try:
                                sql = "SELECT [order_number] FROM [dbo].[ordertracking] where  id=?"
                                cursor.execute(sql, selected_id)
                                order_data = cursor.fetchone()
                                order_number = None
                                if order_data != None:
                                    order_number = order_data.order_number
                                sql = "SELECT [order_number], [price], [qty_cart], [tax_cost], [shipping_cost], [subtotal], [cart_total] FROM [dbo].[ordertracking] where  order_number=?"
                                cursor.execute(sql, order_number)
                                order_tracking = cursor.fetchall()
                                update_subtotal, update_cart_total = 0, 0
                                order_number = None
                                for ot in order_tracking:
                                    subtotal = float(ot.price) * int(ot.qty_cart)
                                    update_subtotal += subtotal
                                if len(order_tracking) != 0:
                                    order_number = order_tracking[0].order_number
                                    extra_cost = float(order_tracking[0].tax_cost) + float(order_tracking[0].shipping_cost)
                                    update_subtotal = round(update_subtotal, 2)
                                    update_cart_total = round(float(update_subtotal) + float(extra_cost),2)
                                sql = "UPDATE [dbo].[ordertracking] SET [subtotal]=?, [cart_total]=?, [Date_modify] = ? WHERE [dbo].[ordertracking].[order_number]=?"
                                val = (update_subtotal, update_cart_total, update_time, order_number)
                                cursor.execute(sql, val)
                                cursor.commit()
                            except Exception as e:
                                print(e)
                                return json.dumps({'status': 'ERROR', "column": str(e)})
                        return json.dumps({'status': 'OK', "column": column_name})
                    except Exception as e:
                        return json.dumps({'status': 'ERROR', "column": str(e)})

                orderNumber = request.args['id']
                sql = "SELECT  *, CONVERT (varchar(10), [orderedDate],110) 'creationDate' FROM [dbo].[ordertracking] where order_number = ?"
                value = (orderNumber)
                cursor.execute(sql, value)
                listData = cursor.fetchall()
                sub_total, cart_tax, cart_total, shipping_cost = 0.0, 0.0, 0.0, 0.0
                shipping_count = 0
                shipping_address, shipping_email, shipping_mobile, dop, order_no, status, retailer, full_name = None, None, None, None, None, None, None, None
                data = {}
                status_set = set()
                for fields in listData:
                    try:
                        if fields.tracking_status:
                            status = fields.tracking_status
                            status_set.add(status)
                        if fields.qty_cart:
                            if fields.tracking_status == 'Delivered':
                                shipping_count += 1
                                if fields.tracking_status:
                                    status = fields.tracking_status
                            elif fields.tracking_status == 'Shipped':
                                shipping_count += 1
                                if fields.tracking_status:
                                    status = fields.tracking_status
                            elif fields.tracking_status == 'Received':
                                shipping_count += 1
                                if fields.tracking_status:
                                    status = fields.tracking_status

                        if sub_total == None or int(sub_total) == 0:
                            if fields.subtotal:
                                sub_total = fields.subtotal
                        if cart_total == None or int(cart_total) == 0:
                            if fields.cart_total:
                                cart_total = fields.cart_total
                        if cart_tax == None or int(cart_tax) == 0:
                            if fields.tax_cost:
                                cart_tax = fields.tax_cost
                        if shipping_cost == None or int(shipping_cost) == 0:
                            if fields.shipping_cost:
                                shipping_cost = fields.shipping_cost
                        if shipping_address == None:
                            if fields.address_id:
                                sql = "SELECT id, street, suite, city, state, zip from [dbo].[addressmaster] where id=?"
                                cursor.execute(sql, fields.address_id)
                                shipping_address = cursor.fetchone()
                        if shipping_email == None:
                            if fields.email_id:
                                sql = "SELECT id, email from [dbo].[emailmaster] where id=?"
                                cursor.execute(sql, fields.email_id)
                                shipping_email = cursor.fetchone()
                        if shipping_mobile == None:
                            if fields.phone:
                                shipping_mobile = fields.phone
                                if len(shipping_mobile) == 10:
                                    shipping_mobile = shipping_mobile[:3] + '-' + shipping_mobile[3:6] + '-' + shipping_mobile[6:]
                        if dop == None:
                            if fields.creationDate:
                                dop = fields.creationDate
                        if order_no == None:
                            if fields.order_number:
                                order_no = fields.order_number
                        if retailer == None:
                            if fields.retailer:
                                retailer = fields.retailer
                        if full_name == None:
                            if fields.fullname:
                                full_name = fields.fullname
                    except Exception as e:
                        print(e)
                        pass

                status = ", ".join(list(status_set))
                r_cart_total = 0
                if (cart_total < sub_total):
                    r_cart_total = sub_total
                if cart_total:
                    r_cart_total = round(cart_total, 2)
                r_sub_total = 0
                if sub_total:
                    n_sub_total = round(sub_total, 2)
                r_shipping_cost = 0
                if shipping_cost:
                    r_shipping_cost = round(shipping_cost, 2)
                r_cart_tax = 0
                if cart_tax:
                    r_cart_tax = round(cart_tax, 2)
                data['cart_total'] = r_cart_total
                data['sub_total'] = sub_total  # r_sub_total is there change by rahul sub_total
                data['shipping_cost'] = r_shipping_cost
                data['cart_tax'] = r_cart_tax
                data['shipping_count'] = shipping_count
                data['shipping_address'] = shipping_address
                data['shipping_email'] = shipping_email
                data['shipping_mobile'] = shipping_mobile
                data['order_no'] = order_no
                data['dop'] = dop
                data['status'] = status
                data['retailer'] = retailer
                data['full_name'] = full_name

                sql = "SELECT [id], [giftcard_number], [amount], [cost], [gift_card_value]  FROM [dbo].[giftcardtransaction] where ordernumber =? and action_type is null"
                value = (orderNumber)
                cursor.execute(sql, value)
                gcData = cursor.fetchall()
                print(gcData)
                giftcard_data = []
                total_amount, total_disc, total_cost = 0, 0, 0
                for gcd in gcData:
                    amount = gcd.amount
                    gc_value = gcd.gift_card_value
                    gc_cost = gcd.cost
                    cost = amount
                    discount, refund = 0, 0
                    if gc_value != 0:
                        discount = round((((gc_value - gc_cost)*100)/gc_value),2)
                        refund = round(((discount * amount)/100),2)
                        cost = amount - refund
                    # refund = 0
                    # if int(gcd.cost) != 0:
                    #     cost = gcd.cost
                    # else:
                    #     disc_cal = discount * 100
                    #     discount_amount = amount * disc_cal
                    #     cost = amount - discount_amount
                    #     refund = discount_amount
                    #     if int(refund) == 0:
                    #         refund = int(refund)
                    #     else:
                    #         refund = "{:.2f}".format(round(refund, 2))
                    total_amount += amount
                    total_disc += discount
                    total_cost += cost

                    giftcard_dict = {
                        'id':gcd.id,
                        'gc_num':gcd.giftcard_number,
                        'amount': "{:.2f}".format(round(amount, 2)),
                        'discount': "{:.2f}".format(round(discount, 2)),
                        'cost': "{:.2f}".format(round(cost, 2)),
                        'refund': refund
                    }
                    giftcard_data.append(giftcard_dict)

                gc_total_data = {
                    'total_amount': "{:.2f}".format(round(total_amount, 2)),
                    'total_disc': "{:.2f}".format(round(total_disc, 2)),
                    'total_cost': "{:.2f}".format(round(total_cost, 2))
                }
                return render_template('orderdetails.html', data=orderNumber, accessdata=accessdata, order_Detail=data, gcData=giftcard_data, gc_total_data=gc_total_data)
            else:
                return redirect(url_for('index'))
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('login'))

@app.route('/orderdetailstatus', methods=['PUT','POST'])
def orderdetailstatus():
    if 'password' and 'email' in session:
        global companyid
        import datetime
        companyid = session["companyid"]
        cursor = condb.cursor()
        if request.method == "PUT":
            try:
                import datetime
                selected_id = request.json['id']
                print(selected_id)
                # get python current time
                cell_name = request.json['cellName']
                column_name = cell_name
                if cell_name == "status":
                    cell_name = "tracking_status"
                elif cell_name == 'tracking_carrier':
                    cell_name = "carrier"
                new_value = request.json['newValue']
                update_time = datetime.datetime.now()
                # sql query for updating date of the giftcard list on the basis of id
                sql = "UPDATE [dbo].[ordertracking] SET [dbo].[ordertracking].[{}] = ?, [dbo].[ordertracking].[Date_modify] = ? WHERE [dbo].[ordertracking].[id]=?".format(
                    cell_name)
                val = (new_value, update_time, selected_id)
                cursor.execute(sql, val)
                # committing data on the database
                cursor.commit()
                if new_value == 'Cancelled':
                    sql = "SELECT order_number FROM [dbo].[ordertracking] WHERE id=?"
                    val = (selected_id)
                    cursor.execute(sql, val)
                    order_data = cursor.fetchone()
                    if order_data:
                        order_no = order_data.order_number
                        cancelledOrderForCheckingQueueGC(order_no, new_value)

                return json.dumps({'status': 'OK', "column": column_name})
            except Exception as e:
                return json.dumps({'status': 'ERROR', "column": str(e)})
        elif request.method == "POST":
            order_number = request.form.get("product_number")
            order_id = str(request.form.get("tracking_id"))
            tracking_number = request.form.get("tracking_number")
            update_time = datetime.datetime.now()
            # sql query for updating date of the giftcard list on the basis of id
            sql = "UPDATE [dbo].[ordertracking] SET [dbo].[ordertracking].[tracking_number] = ?, [dbo].[ordertracking].[Date_modify] = ? WHERE [dbo].[ordertracking].[id]=?"
            val = (tracking_number, update_time, order_id)
            cursor.execute(sql, val)
            cursor.commit()
            return "Tracking Number Succesfully Updated"
        else:
            return json.dumps({'status': 'ERROR', "column": "Invalid Operation"})

@app.route('/checkorderstatus', methods=['GET','POST'])
def checkstatus():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        if request.method == "POST":
            try:
                import datetime
                import requests
                selected_id = request.json['id']
                selected_name = request.json['name']
                selected_phone = request.json['phone']
                last_name = selected_name.split(" ")[1]
                data = {
                    "order_number": selected_id,
                    "last_name": last_name,
                    "mobile": selected_phone
                }
                # data={
                #  "order_number": "BBY01-806282707265",
                #  "last_name": "Mauricio",
                #  "mobile": "9817667660"
                # }
                # result = requests.post("http://45.138.27.169:8081/statusdetails", json=data)
                # result = requests.post("http://188.227.58.19:82/statusdetails", json=data)
                result = requests.post("http://127.0.0.1:5001/statusdetails", json=data)
                print(result.json())
                result_data = json.loads(result.text)
                response_status = False
                if result_data != None:
                    if 'success' in result_data:
                        response_status = result_data['success']
                        if response_status:
                            message = "Successfully fetched live status."
                        else:
                            message = "The order number did not matched."
                    elif 'error' in result_data:
                        response_status = result_data['error']
                        message = "Having some issue with order number for live status."
                else:
                    response_status = False
                    message = "The order number did not matched."
                response = {
                    'code':200,
                    'data':response_status,
                    'message': message
                }
                return json.dumps(response)
            except Exception as e:
                print(e)
                response = {
                    'code': 404,
                    'data': str(e),
                    'message': "Sorry, the server is busy. Please try again later"
                }
                return json.dumps(response)
        elif request.method == "GET":
            id = request.args['id']
            download_invoice = "./report/invocies/{}.pdf".format(id)
            if os.path.exists(download_invoice):
                return send_file(download_invoice, mimetype='text/pdf',
                                 attachment_filename=download_invoice,
                                 as_attachment=True, cache_timeout=0)

############### ---------End Order Detail Page-------------  ########################

############### --------- Gift Card Page-------------  ########################
@app.route('/giftcard', methods=['POST', 'GET', 'PUT'])
def giftcardlist():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        giftcard_obj = GiftCardClass()
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        if len(accessdata) != 0:
            if accessdata[0].giftcard == 1:
                if request.method == "POST":
                    pass
                elif request.method == "PUT":
                    columnName = ""
                    try:
                        cursor = condb.cursor()
                        updatedData = request.json
                        print(updatedData)
                        newValue = updatedData['newValue']
                        print(newValue)
                        selectedId = updatedData['id']
                        print(selectedId)
                        columnName = updatedData['cellName']
                        print(columnName)
                        updatedColumnName = ""
                        checkBalance = False

                        if columnName == "balance":
                            newValue = str(newValue).replace("$","")
                            checkBalance = True
                            if newValue == "":
                                newValue = 0
                        if columnName == "cost":
                            newValue = str(newValue).replace("$","")
                            if newValue == "":
                                newValue = 0
                        if columnName == "value":
                            newValue = str(newValue).replace("$", "")
                            if newValue == "":
                                newValue = 0
                        if columnName == "gift_card_pin":
                            checkBalance = True
                            newValue = str(newValue).replace(" ", "")
                            if newValue == "":
                                newValue = 0
                            elif len(newValue) != 4:
                                return json.dumps({'status': 400, "error": "You have entered invalid pin."})
                        if columnName == "gift_card_no":
                            checkBalance = True
                            newValue = str(newValue).replace(" ", "")
                            if newValue == "":
                                newValue = None
                            elif len(newValue) != 16:
                                return json.dumps({'status': 400, "error": "You have entered invalid giftcard."})
                        if columnName == "vendor":
                            if newValue == "":
                                newValue = None
                            else:
                                newValue = str(newValue).title()
                        try:
                            if columnName == "date_of_creation":
                                columnName = "date_of_purchase"
                                current_time = pd.to_datetime('now').time()
                                date_time = pd.to_datetime(str(newValue) + ' ' + str(current_time))
                                newValue = (date_time if newValue != "" else None)
                                if newValue == "":
                                    newValue = None
                            if columnName == "last_used":
                                current_time = pd.to_datetime('now').time()
                                date_time = pd.to_datetime(str(newValue) + ' ' + str(current_time))
                                newValue = (date_time if newValue != "" else None)
                                if newValue == "":
                                    newValue = None
                        except Exception as e:
                            return json.dumps({'status': 400, "error": "Please use valid date format - MM-DD-YYYY"})

                        if columnName != "":
                            # sql query for updating fields of the giftcard list on the basis of id
                            sql = "UPDATE [dbo].[giftcardlist] SET {} = ?, Date_modify=? WHERE [dbo].[giftcardlist].id=?".format(
                                columnName)
                            # execute sql query
                            val = (newValue, datetime.now(), selectedId)
                            # print(val)
                            # execute sql query on the basic of gift_card_no & selected id
                            cursor.execute(sql, val)
                            # committing data on the database
                            cursor.commit()
                            if checkBalance:
                                sql = "SELECT Max(queue_id) FROM [dbo].[giftcardlist]"
                                cursor.execute(sql)
                                data = cursor.fetchall()
                                queue_id = data[0][0]
                                queue_id = queue_id if queue_id else 0
                                queue_id = queue_id + 1
                                sql = "UPDATE [dbo].[giftcardlist] SET [status]=?, [queue_status] = ?, [queue_date] = ?, [queue_id] = ?, [check_balance_status] = ? WHERE [dbo].[giftcardlist].id=?"
                                val = ("Replaced","que", datetime.now(), queue_id, None, selectedId)
                                cursor.execute(sql, val)
                                cursor.commit()

                            return json.dumps({'status': 200, "column": columnName})
                        return json.dumps({'status': 400, "error": "Value not update."})
                    except Exception as e:
                        print(e)
                        return json.dumps({'status': 400, "error": "Please use valid data."})

                ## Update status range if below thirty days show bad in the place of bad and after 30 days if bad then it show invlid
                sql = "UPDATE [dbo].[giftcardlist] SET status='Bad' WHERE DATEDIFF(day,date_of_purchase,GETDATE()) < 31 AND status='Invalid'"
                cursor.execute(sql)
                cursor.commit()

                sql = "UPDATE [dbo].[giftcardlist] SET status='Invalid' WHERE DATEDIFF(day,date_of_purchase,GETDATE()) > 31 AND status='Bad'"
                cursor.execute(sql)
                cursor.commit()

                sql = "UPDATE [dbo].[giftcardtransaction] set order_purchase_status = null where action_type is not null"
                cursor.execute(sql)
                cursor.commit()

                sql = "UPDATE [dbo].[giftcardlist] SET discount=round((((gift_card_value-amount_paid)*100)/gift_card_value),2)"
                cursor.execute(sql)
                cursor.commit()

                range_slider_data = {}
                sql = "SELECT MIN(balance) as min_balance, MAX(balance) as max_balance, MIN(amount_paid) as min_cost, MAX(amount_paid) as max_cost, MIN(gift_card_value) as min_value, MAX(gift_card_value) as max_value FROM [dbo].[giftcardlist]"
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                balance_slider, cost_slider, value_slider = {},{},{}
                if None not in table_Data:
                    min_balance = int(table_Data.min_balance)
                    max_balance = int(table_Data.max_balance)
                    min_cost = int(table_Data.min_cost)
                    max_cost = int(table_Data.max_cost)
                    min_value = int(table_Data.min_value)
                    max_value = int(table_Data.max_value)


                    min_balance = (0 if min_balance >= 0 else min_balance)
                    min_cost = (0 if min_cost >= 0 else min_cost)
                    min_value = (0 if min_value >= 0 else min_value)
                    balance_slider['min'] = min_balance
                    balance_slider['from'] = min_balance
                    cost_slider['min'] = min_cost
                    cost_slider['from'] = min_cost
                    value_slider['min'] = min_value
                    value_slider['from'] = min_value
                    if max_balance == 0:
                        max_balance += 1

                    if max_cost == 0:
                        max_cost += 1

                    if max_value == 0:
                        max_value += 1

                    balance_slider['max'] = max_balance
                    balance_slider['to'] = max_balance
                    cost_slider['max'] = max_cost
                    cost_slider['to'] = max_cost
                    value_slider['max'] = max_value
                    value_slider['to'] = max_value
                    range_slider_data['balance_slider'] = balance_slider
                    range_slider_data['cost_slider'] = cost_slider
                    range_slider_data['value_slider'] = value_slider
                else:
                    balance_slider['min'], balance_slider['from'] = 0, 0
                    cost_slider['min'], cost_slider['from'] = 0, 0
                    value_slider['min'], value_slider['from'] = 0, 0
                    balance_slider['max'], balance_slider['to'] = 1, 1
                    cost_slider['max'], cost_slider['to'] = 1, 1
                    value_slider['max'], value_slider['to'] = 1, 1
                    range_slider_data['balance_slider'] = balance_slider
                    range_slider_data['cost_slider'] = cost_slider
                    range_slider_data['value_slider'] = value_slider

                balance_snapshot = {}
                balance_snapshot.update({'balance_count':0,'total_balance':0,'new_count':0,'new_balance':0,'used_count':0,'used_balance':0,'lock_count':0,'lock_balance':0})
                sql = "SELECT count(balance) as balance_count, sum(balance) as total_balance FROM [dbo].[giftcardlist] where status IN ('Balance','New','Balance Off','Value Off','New Balance','Locked')"
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                if table_Data:
                    total_balance = table_Data.total_balance if table_Data.total_balance else 0
                    balance_snapshot.update({'balance_count':table_Data.balance_count,'total_balance':total_balance})

                sql = "SELECT count(balance) as new_count, sum(balance) as new_balance FROM [bestbuymaster].[dbo].[giftcardlist] where status in ('Balance','New','New Balance','Value Off') and balance>0 and id not in (SELECT B.id FROM [dbo].[giftcardtransaction] AS A INNER JOIN [bestbuymaster].[dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no)"
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                if table_Data:
                    new_balance = table_Data.new_balance if table_Data.new_balance else 0
                    balance_snapshot.update({'new_count':table_Data.new_count,'new_balance':new_balance})

                # sql = "SELECT count(B.gift_card_no) as used_count, sum(B.balance) as used_balance FROM [dbo].[giftcardtransaction] AS A INNER JOIN [dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no WHERE A.action_type is null"
                sql = "SELECT count(B.gift_card_no) as used_count, sum(B.balance) as used_balance, sum(B.gift_card_value) as gc_value FROM [dbo].[giftcardtransaction] AS A INNER JOIN [dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no WHERE A.action_type is null"
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                if table_Data:
                    gc_value = table_Data.gc_value if table_Data.gc_value else 0
                    used_balance = table_Data.used_balance if table_Data.used_balance else 0
                    # used_balance = gc_value - used_balance
                balance_snapshot.update({'used_count':table_Data.used_count,'used_balance':used_balance})

                non_cancelled_days, cancelled_days = 0, 0
                sql = "SELECT non_cancelled_order, cancelled_order, status FROM [dbo].[settings]"
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                if table_Data:
                    non_cancelled_days = table_Data.non_cancelled_order
                    cancelled_days = table_Data.cancelled_order

                non_cancelled_order_lock_balance, non_cancelled_order_lock_count = 0, 0
                sql = "SELECT count(B.gift_card_no) as lock_count, sum(B.balance) as lock_balance FROM [dbo].[giftcardtransaction] AS A INNER JOIN [dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no where A.[Date_creation] >= DATEADD(day,-{}, GETDATE()) and A.order_purchase_status!='Cancelled' and A.action_type is null".format(non_cancelled_days)
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                if table_Data:
                    non_cancelled_order_lock_balance = table_Data.lock_balance if table_Data.lock_balance else 0
                    non_cancelled_order_lock_count = table_Data.lock_count if table_Data.lock_count else 0

                cancelled_order_lock_balance, cancelled_order_lock_count = 0, 0
                sql = "SELECT count(B.gift_card_no) as lock_count, sum(B.balance) as lock_balance FROM [dbo].[giftcardtransaction] AS A INNER JOIN [dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no where A.[Date_creation] >= DATEADD(day,-{}, GETDATE()) and A.order_purchase_status='Cancelled' and A.action_type is null".format(cancelled_days)
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                if table_Data:
                    cancelled_order_lock_balance = table_Data.lock_balance if table_Data.lock_balance else 0
                    cancelled_order_lock_count = table_Data.lock_count if table_Data.lock_count else 0

                balance_snapshot.update({'lock_count': (non_cancelled_order_lock_count+cancelled_order_lock_count), 'lock_balance': (non_cancelled_order_lock_balance+cancelled_order_lock_balance)})

                sql = "SELECT B.id, B.gift_card_no FROM [dbo].[giftcardtransaction] AS A INNER JOIN [dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no where A.[Date_creation] >= DATEADD(day,-{}, GETDATE()) and A.order_purchase_status!='Cancelled' and A.action_type is null".format(
                    non_cancelled_days)
                cursor.execute(sql)
                table_Data = cursor.fetchall()
                for data in table_Data:
                    sql = "UPDATE [dbo].[giftcardlist] SET status = 'Locked' WHERE id={}".format(data.id)
                    cursor.execute(sql)
                    cursor.commit()

                sql = "SELECT B.id, B.gift_card_no FROM [dbo].[giftcardtransaction] AS A INNER JOIN [dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no where A.[Date_creation] >= DATEADD(day,-{}, GETDATE()) and A.order_purchase_status='Cancelled' and A.action_type is null".format(
                    cancelled_days)
                cursor.execute(sql)
                table_Data = cursor.fetchall()
                for data in table_Data:
                    sql = "UPDATE [dbo].[giftcardlist] SET status = 'Locked' WHERE id={}".format(data.id)
                    cursor.execute(sql)
                    cursor.commit()

                bad_card_snapshot = {}
                today_data, last_7_data, last_30_data = {'invalid_count':0, 'bad_count':0, 'amount':0}, {'invalid_count':0, 'bad_count':0, 'amount':0}, {'invalid_count':0, 'bad_count':0, 'amount':0}
                bad_card_snapshot.update({'bad_card_amount': 0, 'today': today_data, 'last_7_days': last_7_data,'last_30_days':last_30_data})
                sql = "SELECT sum(balance) as bad_card_amount FROM [dbo].[giftcardlist] where status IN ('Invalid','Bad','Error')"
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                if table_Data:
                    bad_card_amount = table_Data.bad_card_amount if table_Data.bad_card_amount else 0
                    bad_card_snapshot.update({'bad_card_amount': bad_card_amount})

                today_date = giftcard_obj.customdaterange('Today')
                sql = "SELECT count(CASE WHEN status = 'Invalid' Then 1 End) as invalid_count, count(CASE WHEN status = 'Bad' Then 1 End) as bad_count, sum(balance) as amount FROM [dbo].[giftcardlist] where status IN ('Invalid','Bad') AND CAST([giftcardlist].[date_of_purchase] AS DATE) between '" + str(today_date['date1']) + "' and '" + str(today_date['date2']) + "'"
                print(sql)
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                if table_Data:
                    amount = table_Data.amount if table_Data.amount else 0
                    today_data.update({'invalid_count': table_Data.invalid_count, 'bad_count':table_Data.bad_count, 'amount':amount})
                    bad_card_snapshot.update({'today':today_data})

                last_7_days = giftcard_obj.customdaterange('Last7days')
                sql = "SELECT count(CASE WHEN status = 'Invalid' Then 1 End) as invalid_count, count(CASE WHEN status = 'Bad' Then 1 End) as bad_count, sum(balance) as amount FROM [dbo].[giftcardlist] where status IN ('Invalid','Bad') AND CAST([giftcardlist].[date_of_purchase] AS DATE) between '" + str(
                    last_7_days['date1']) + "' and '" + str(last_7_days['date2']) + "'"
                print(sql)
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                if table_Data:
                    amount = table_Data.amount if table_Data.amount else 0
                    last_7_data.update({'invalid_count': table_Data.invalid_count, 'bad_count':table_Data.bad_count, 'amount':amount})
                    bad_card_snapshot.update({'last_7_days': last_7_data})

                last_30_days = giftcard_obj.customdaterange('Last30days')
                sql = "SELECT count(CASE WHEN status = 'Invalid' Then 1 End) as invalid_count, count(CASE WHEN status = 'Bad' Then 1 End) as bad_count, sum(balance) as amount FROM [dbo].[giftcardlist] where status IN ('Invalid','Bad') AND CAST([giftcardlist].[date_of_purchase] AS DATE) between '" + str(
                    last_30_days['date1']) + "' and '" + str(last_30_days['date2']) + "'"
                print(sql)
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                if table_Data:
                    amount = table_Data.amount if table_Data.amount else 0
                    last_30_data.update({'invalid_count': table_Data.invalid_count, 'bad_count':table_Data.bad_count, 'amount':amount})
                    bad_card_snapshot.update({'last_30_days': last_30_data})

                sql = "SELECT DISTINCT vendor FROM [dbo].[giftcardlist]"
                cursor.execute(sql)
                vendor_Data = cursor.fetchall()

                return render_template('giftcard.html', accessdata=accessdata, sliderdata=range_slider_data, balance_snapshot=balance_snapshot, bad_card_snapshot=bad_card_snapshot, vendor = vendor_Data)
            else:
                return redirect(url_for('index'))
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('login'))

@app.route('/getsnapshot', methods=['POST'])
def getsnapshots():
    if 'password' and 'email' in session:
        import locale
        locale.setlocale(locale.LC_ALL, 'en_US')
        cursor = condb.cursor()
        giftcard_obj = GiftCardClass()
        responsedata = {}
        balance_snapshot = {}
        balance_snapshot.update(
            {'snapshot_balance': 0, 'new_count': 0, 'new_balance': 0, 'used_count': 0, 'used_balance': 0,
             'lock_count': 0, 'lock_balance': 0})
        sql = "SELECT count(balance) as balance_count, sum(balance) as total_balance FROM [dbo].[giftcardlist] where status IN ('Balance','New','Balance Off','Value Off','New Balance','Locked')"
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        if table_Data:
            total_balance = table_Data.total_balance if table_Data.total_balance else 0
            total_balance = locale.format_string("%.2f", total_balance, grouping=True)
            snapshot_balance = "{0} (${1})".format(str(table_Data.balance_count),str(total_balance))
            balance_snapshot.update({'snapshot_balance': snapshot_balance})

        # sql = "SELECT count(balance) as new_count, sum(balance) as new_balance FROM [bestbuymaster].[dbo].[giftcardlist] where status in ('Balance','New','New Balance') and id not in (SELECT B.id FROM [bestbuymaster].[dbo].[giftcardtransaction] AS A INNER JOIN [bestbuymaster].[dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no)"
        sql = "SELECT count(balance) as new_count, sum(balance) as new_balance FROM [bestbuymaster].[dbo].[giftcardlist] where status in ('Balance','New','New Balance','Value Off') and balance>0 and id not in (SELECT B.id FROM [dbo].[giftcardtransaction] AS A INNER JOIN [bestbuymaster].[dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no)"
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        if table_Data:
            new_balance = table_Data.new_balance if table_Data.new_balance else 0
            new_balance = locale.format_string("%.2f", new_balance, grouping=True)
            balance_snapshot.update({'new_count': table_Data.new_count, 'new_balance': '$'+new_balance})

        # sql = "SELECT count(balance) as used_count, sum(balance) as used_balance FROM [dbo].[giftcardlist] where status = 'Balance' AND check_balance_status IS NOT NULL"
        sql = "SELECT count(B.gift_card_no) as used_count, sum(B.balance) as used_balance, sum(B.gift_card_value) as gc_value FROM [dbo].[giftcardtransaction] AS A INNER JOIN [dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no WHERE A.action_type is null"
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        if table_Data:
            gc_value = table_Data.gc_value if table_Data.gc_value else 0
            used_balance = table_Data.used_balance if table_Data.used_balance else 0
            # used_balance = gc_value - used_balance
            used_balance = locale.format_string("%.2f", used_balance, grouping=True)
            balance_snapshot.update({'used_count': table_Data.used_count, 'used_balance': '$'+used_balance})

        non_cancelled_days, cancelled_days = 0, 0
        sql = "SELECT non_cancelled_order, cancelled_order, status FROM [dbo].[settings]"
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        if table_Data:
            non_cancelled_days = table_Data.non_cancelled_order
            cancelled_days = table_Data.cancelled_order

        non_cancelled_order_lock_balance, non_cancelled_order_lock_count = 0, 0
        sql = "SELECT count(B.gift_card_no) as lock_count, sum(B.balance) as lock_balance FROM [dbo].[giftcardtransaction] AS A INNER JOIN [dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no where A.[Date_creation] >= DATEADD(day,-{}, GETDATE()) and A.order_purchase_status!='Cancelled' and A.action_type is null".format(
            non_cancelled_days)
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        if table_Data:
            non_cancelled_order_lock_balance = table_Data.lock_balance if table_Data.lock_balance else 0
            non_cancelled_order_lock_count = table_Data.lock_count if table_Data.lock_count else 0

        cancelled_order_lock_balance, cancelled_order_lock_count = 0, 0
        sql = "SELECT count(B.gift_card_no) as lock_count, sum(B.balance) as lock_balance FROM [dbo].[giftcardtransaction] AS A INNER JOIN [dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no where A.[Date_creation] >= DATEADD(day,-{}, GETDATE()) and A.order_purchase_status='Cancelled' and A.action_type is null".format(
            cancelled_days)
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        if table_Data:
            cancelled_order_lock_balance = table_Data.lock_balance if table_Data.lock_balance else 0
            cancelled_order_lock_count = table_Data.lock_count if table_Data.lock_count else 0

        lock_balance = non_cancelled_order_lock_balance + cancelled_order_lock_balance
        lock_balance = locale.format_string("%.2f", lock_balance, grouping=True)
        balance_snapshot.update({'lock_count': (non_cancelled_order_lock_count + cancelled_order_lock_count),
                                 'lock_balance': '$'+lock_balance})
        # sql = "SELECT count(B.gift_card_no) as lock_count, sum(B.balance) as lock_balance FROM [dbo].[giftcardtransaction] AS A INNER JOIN [dbo].[giftcardlist] AS B ON A.giftcard_number=B.gift_card_no where A.[Date_creation] >= DATEADD(day,-3, GETDATE()) and A.action_type is null"
        # cursor.execute(sql)
        # table_Data = cursor.fetchone()
        # if table_Data:
        #     lock_balance = table_Data.lock_balance if table_Data.lock_balance else 0
        #     lock_balance = locale.format_string("%.2f", lock_balance, grouping=True)
        #     balance_snapshot.update({'lock_count': table_Data.lock_count, 'lock_balance': '$'+lock_balance})

        bad_card_snapshot = {}
        today_data, last_7_data, last_30_data = {'invalid_count': 0, 'bad_count': 0, 'amount': 0}, {'invalid_count': 0,
                                                                                                    'bad_count': 0,
                                                                                                    'amount': 0}, {
                                                    'invalid_count': 0, 'bad_count': 0, 'amount': 0}
        bad_card_snapshot.update(
            {'bad_card_amount': 0, 'today': today_data, 'last_7_days': last_7_data, 'last_30_days': last_30_data})
        sql = "SELECT sum(balance) as bad_card_amount FROM [dbo].[giftcardlist] where status IN ('Invalid','Bad')"
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        if table_Data:
            bad_card_amount = table_Data.bad_card_amount if table_Data.bad_card_amount else 0
            bad_card_amount = locale.format_string("%.2f", bad_card_amount, grouping=True)
            bad_card_snapshot.update({'bad_card_amount': '$'+bad_card_amount})

        today_date = giftcard_obj.customdaterange('Today')
        sql = "SELECT count(CASE WHEN status = 'Invalid' Then 1 End) as invalid_count, count(CASE WHEN status = 'Bad' Then 1 End) as bad_count, sum(balance) as amount FROM [dbo].[giftcardlist] where status IN ('Invalid','Bad') AND CAST([giftcardlist].[date_of_purchase] AS DATE) between '" + str(
            today_date['date1']) + "' and '" + str(today_date['date2']) + "'"
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        if table_Data:
            amount = table_Data.amount if table_Data.amount else 0
            amount = locale.format_string("%.2f", amount, grouping=True)
            today_data.update(
                {'invalid_count': table_Data.invalid_count, 'bad_count': table_Data.bad_count, 'amount': '$'+amount})
            bad_card_snapshot.update({'today': today_data})

        last_7_days = giftcard_obj.customdaterange('Last7days')
        sql = "SELECT count(CASE WHEN status = 'Invalid' Then 1 End) as invalid_count, count(CASE WHEN status = 'Bad' Then 1 End) as bad_count, sum(balance) as amount FROM [dbo].[giftcardlist] where status IN ('Invalid','Bad') AND CAST([giftcardlist].[date_of_purchase] AS DATE) between '" + str(
            last_7_days['date1']) + "' and '" + str(last_7_days['date2']) + "'"
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        if table_Data:
            amount = table_Data.amount if table_Data.amount else 0
            amount = locale.format_string("%.2f", amount, grouping=True)
            last_7_data.update(
                {'invalid_count': table_Data.invalid_count, 'bad_count': table_Data.bad_count, 'amount': '$'+amount})
            bad_card_snapshot.update({'last_7_days': last_7_data})

        last_30_days = giftcard_obj.customdaterange('Last30days')
        sql = "SELECT count(CASE WHEN status = 'Invalid' Then 1 End) as invalid_count, count(CASE WHEN status = 'Bad' Then 1 End) as bad_count, sum(balance) as amount FROM [dbo].[giftcardlist] where status IN ('Invalid','Bad') AND CAST([giftcardlist].[date_of_purchase] AS DATE) between '" + str(
            last_30_days['date1']) + "' and '" + str(last_30_days['date2']) + "'"
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        if table_Data:
            amount = table_Data.amount if table_Data.amount else 0
            amount = locale.format_string("%.2f", amount, grouping=True)
            last_30_data.update(
                {'invalid_count': table_Data.invalid_count, 'bad_count': table_Data.bad_count, 'amount': '$'+amount})
            bad_card_snapshot.update({'last_30_days': last_30_data})
        responsedata['bad_card_snapshot'] = bad_card_snapshot
        responsedata['balance_snapshot'] = balance_snapshot
        responsedata['code'] = 200
        return jsonify(responsedata)
    else:
        return redirect(url_for('login'))

@app.route('/giftcarddatatable', methods=['POST'])
def giftcarddatatable():
    try:
        if 'password' and 'email' in session:
            companyid = session["companyid"]
            cursor = condb.cursor()
            giftcard_obj = GiftCardClass()
            if request.method == 'POST':
                import datetime
                content = request.json
                columns = content['columns']
                # initially start show 0 & on click next it will increased accroding to defined rows in the table  (Display index for the first record shown on the current page)
                offset = content['start']
                # Display length (number of records) use --> used in fetch to get no of next records from the database
                length = content['length']
                # the search field for the datatables
                search = content['search']
                searchbox = search['value'].strip()
                searchbox = "{" if searchbox.startswith("'") else searchbox
                searchbox = "{" if searchbox.startswith("-") else searchbox
                searchbox = "{" if searchbox.startswith(";") else searchbox
                # Sorting datatable
                orderable = content['order']

                sorting = ["giftcardlist.date_of_purchase" if orderable[0]['column'] == 1 else (
                    "giftcardlist.status" if orderable[0]['column'] == 2 else (
                        'giftcardlist.batch_id' if orderable[0]['column'] == 3 else (
                        'giftcardlist.gift_card_no' if orderable[0]['column'] == 4 else (
                            'giftcardlist.gift_card_pin' if orderable[0]['column'] == 5 else (
                                'giftcardlist.balance' if orderable[0]['column'] == 6 else (
                                    'no_of_order' if orderable[0]['column'] == 7 else (
                                        'cancellation_count' if orderable[0]['column'] == 8 else (
                                            'giftcardlist.last_used' if orderable[0]['column'] == 9 else (
                                                'giftcardlist.amount_paid' if orderable[0]['column'] == 10 else (
                                                    'giftcardlist.gift_card_value' if orderable[0]['column'] == 11 else(
                                                        'giftcardlist.vendor' if orderable[0]['column'] == 12 else
                                                        "")))))))))))]
                direction = orderable[0]['dir']
                # print(sorting)
                # print(direction)

                # filter for status using upper dropdown
                columns_status = columns[2]
                # print('columns_status', columns_status)
                columns_status_search = columns_status['search']['value']
                # print(columns_status_search)
                if columns_status_search == 'Status':
                    columns_status_search = ''
                elif columns_status_search == 'All':
                    columns_status_search = ''

                columns_date = columns[1]
                # print('columns_date', columns_date)
                columns_date_search = columns_date['search']['value']
                # print(columns_date_search)
                if columns_date_search == 'DateRange':
                    columns_date_search = ''

                columns_last_used = columns[8]
                # print('columns_date', columns_last_used)
                columns_last_used_search = columns_last_used['search']['value']
                # print(columns_last_used_search)
                if columns_last_used_search == 'LastUsed':
                    columns_last_used_search = ''

                today = datetime.datetime.now()
                lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
                date1, date2 = ((today - datetime.timedelta(days=6)).date(), today.date()) if columns_date_search == 'Last7days' else (((today - datetime.timedelta(days=today.weekday())).date(),today.date()) if columns_date_search == "ThisWeek" else (((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),lastMonthdate.date()) if columns_date_search == "LastMonth" else ((today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else ((today - datetime.timedelta(days=30)).date(),today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),datetime.date.strftime(datetime.datetime.strptime(columns_date_search[18:28],'%m-%d-%Y'),"%Y-%m-%d")) if len(columns_date_search) == 28 else ("", "")))))
                # print(date1, date2)
                date3, date4 = ((today - datetime.timedelta(days=6)).date(), today.date()) if columns_last_used_search == 'Last7days' else (((today - datetime.timedelta(days=today.weekday())).date(),today.date()) if columns_last_used_search == "ThisWeek" else (((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),lastMonthdate.date()) if columns_last_used_search == "LastMonth" else ((today.replace(day=1).date(), today.date()) if columns_last_used_search == "ThisMonth" else ((today - datetime.timedelta(days=30)).date(),today.date()) if columns_last_used_search == "Last30days" else ((datetime.date.strftime(datetime.datetime.strptime(columns_last_used_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),datetime.date.strftime(datetime.datetime.strptime(columns_last_used_search[18:28],'%m-%d-%Y'),"%Y-%m-%d")) if len(columns_last_used_search) == 28 else ("", "")))))
                # print(date3, date4)

                columns_vendor = columns[11]

                columns_vendor_search = columns_vendor['search']['value']
                if columns_vendor_search == "Vendor":
                    columns_vendor_search = ""

                columns_archived = content['archive']

                ## RANGE SLIDER VALUE ---- >
                custom_filter = False
                column_order_range = content['order_range']
                # print("Order Range ", column_order_range)
                column_cancellation_range = content['cancellation_range']
                # print("Cancellation Range ", column_cancellation_range)
                column_balance_range = content['balance_range']
                # print("Balance Range ", column_balance_range)
                column_cost_range = content['cost_range']
                # print("Cost Range ", column_cost_range)
                column_value_range = content['value_range']
                #########################################################################################
                custom_items = [columns_vendor_search,columns_last_used_search,column_order_range,column_cancellation_range,column_balance_range,column_cost_range,column_value_range]
                # print(custom_items)
                custom_filter = any(custom_items)
                # custom_searchbox, custom_status, is_archived, custom_dtrange, custom_sorting, custom_direction = None, None, None, None, None, None
                query_shorter, custom_query = [], ""
                custom_sorting, custom_direction = None, None
                if columns_date_search != "":
                    custom_dtrange = "CAST([giftcardlist].[date_of_purchase] AS DATE) between '" + str(
                        date1) + "' and '" + str(date2) + "'"
                    query_shorter.append(custom_dtrange)
                if columns_status_search != "":
                    status_tuple = tuple(columns_status_search.split(","))
                    status_tuple = '{}'.format(status_tuple)
                    status_tuple = status_tuple.replace(",)",")")
                    custom_status = "[giftcardlist].[status] IN {}".format(status_tuple)
                    query_shorter.append(custom_status)
                if len(searchbox) != 0:
                    # custom_searchbox = searchbox
                    custom_searchbox = "(giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR CONVERT (varchar(10), giftcardlist.date_of_purchase,110) LIKE '{}%' OR CONVERT (varchar(10), last_used,110) LIKE '{}%' OR amount_paid LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%' OR giftcardlist.batch_id LIKE '{}%')".format(
                        searchbox, searchbox, searchbox,
                        searchbox, searchbox, searchbox,
                        searchbox, searchbox, searchbox,
                        searchbox
                    )
                    query_shorter.append(custom_searchbox)
                if columns_archived:
                    is_archived = "((YEAR(giftcardlist.date_of_purchase) < YEAR(GETDATE()) and giftcardlist.balance > 0) or (YEAR(giftcardlist.date_of_purchase) = YEAR(GETDATE())))"
                    query_shorter.append(is_archived)
                if len(sorting[0]) != 0:
                    custom_sorting = sorting[0]
                    custom_direction = direction

                if len(query_shorter) == 0:
                    custom_query = ''
                elif len(query_shorter) == 1:
                    custom_query = ''.join(query_shorter)
                else:
                    custom_query = ' AND '.join(query_shorter)

                if custom_filter:
                    query_shorter_having = []
                    if len(column_order_range) != 0:
                        query_shorter_having.append("count([giftcardtransaction].[ordernumber]) BETWEEN '"+str(column_order_range[0])+"' AND '"+str(column_order_range[1])+"'")
                    if len(column_cancellation_range) != 0:
                        query_shorter_having.append("sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) BETWEEN '"+str(column_cancellation_range[0])+"' AND '"+str(column_cancellation_range[1])+"'")
                    if len(column_balance_range) != 0:
                        query_shorter_having.append("[giftcardlist].[balance] BETWEEN '"+str(column_balance_range[0])+"' AND '"+str(column_balance_range[1])+"'")
                    if len(column_cost_range) != 0:
                        query_shorter_having.append("[giftcardlist].[amount_paid] BETWEEN '"+str(column_cost_range[0])+"' AND '"+str(column_cost_range[1])+"'")
                    if len(column_value_range) != 0:
                        query_shorter_having.append("[giftcardlist].[gift_card_value] BETWEEN '"+str(column_value_range[0])+"' AND '"+str(column_value_range[1])+"'")
                    if columns_last_used_search !='':
                        query_shorter_having.append("CAST([giftcardlist].[last_used] AS DATE) between '" + str(date3) + "' and '" + str(date4) + "'")
                    if columns_vendor_search != '':
                        query_shorter_having.append("[giftcardlist].[vendor] = '"+str(columns_vendor_search)+"'")

                    if len(query_shorter_having) == 0:
                        custom_query_having = ''
                    elif len(query_shorter_having) == 1:
                        custom_query_having = ''.join(query_shorter_having)
                    else:
                        custom_query_having = ' AND '.join(query_shorter_having)

                    sql = giftcard_obj.giftcardrangecount(custom_query_having, custom_query)
                    cursor.execute(sql)
                    # fetching buying details
                    count = cursor.fetchall()
                    # print("count", count)
                    try:
                        no_of_records = len(count)
                    except Exception as e:
                        no_of_records = count[0][0]
                    # print("no_of_records", no_of_records)

                    sql = giftcard_obj.giftcardrangequery(offset, length, custom_query_having, custom_query,
                                                        custom_sorting, custom_direction)
                    # print(sql)
                    cursor.execute(sql)
                else:
                    sql = giftcard_obj.giftcardqueryforcount(custom_query)
                    print(sql)
                    cursor.execute(sql)
                    # fetching buying details
                    count = cursor.fetchall()
                    # print("count", count)
                    try:
                        no_of_records = len(count)
                    except Exception as e:
                        no_of_records = count[0][0]

                    # print("no_of_records", no_of_records)
                    sql = giftcard_obj.giftcardquery(offset, length, custom_query,
                                        custom_sorting, custom_direction)
                    print(sql)
                    cursor.execute(sql)

                giftcardlist_data = cursor.fetchall()
                # print(giftcardlist_data)

                # addding dictionary data into the list
                list_of_giftcard = []
                # convert giftcardlist data into dictionary
                for giftcardlist in giftcardlist_data:
                    balance = '{0:.2f}'.format(round(giftcardlist.balance,2))
                    cost = '{0:.2f}'.format(round(giftcardlist.amount_paid,2))
                    value = '{0:.2f}'.format(round(giftcardlist.gift_card_value,2))
                    giftdict = {
                        "vendor": giftcardlist.vendor,
                        "gift_card_no": giftcardlist.gift_card_no,
                        "gift_card_pin": giftcardlist.gift_card_pin,
                        "status": giftcardlist.status,
                        "balance": balance,
                        "last_used": giftcardlist.last_used,
                        "no_of_order": giftcardlist.no_of_order,
                        "no_of_cancellation": giftcardlist.cancellation_count,
                        "date_of_creation": giftcardlist.date_of_purchase,
                        "cost": cost,
                        "value": value,
                        "batch": giftcardlist.batch_id,
                        "id": giftcardlist.id,
                        "orderhistory": "orderhistory"
                    }
                    list_of_giftcard.append(giftdict)
                responsedata = {
                    "draw": content['draw'],
                    "data": list_of_giftcard,
                    "recordsTotal": no_of_records,
                    "recordsFiltered": no_of_records
                }
                print(responsedata)
                return jsonify(responsedata)
    except Exception as e:
        print(e)

# upload a giftcard csv
@app.route('/uploadgiftcard', methods=['POST'])
def uploadgiftcard():
    try:
        if 'password' and 'email' in session:
            global companyid
            email = session["email"]
            # print(email)
            companyid = session["companyid"]
            cursor = condb.cursor()
            cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].id=" + str(companyid))
            accessdata = cursor.fetchall()

            gc_inserted, gc_updated, gc_error = 0, 0, 0
            if request.method == 'POST':
                # python date time module
                import datetime
                import numpy as np

                # calculating date older than last 7 i.e 8th days starting from todays and the 30th days starting from today
                today = datetime.datetime.now()
                last_7_days, last_30_days = (
                (today - datetime.timedelta(days=7)).date(), (today - datetime.timedelta(days=29)).date())
                # print(last_7_days, last_30_days)
                # getting csv file from import button on giftcard page
                f = request.files['uploadFile']
                # reading csv file
                # the entire Excel file is read in during the ExcelFile()
                xls = pd.ExcelFile(f)
                df = pd.read_excel(xls, dtype=str)

                new_batch_queue = []
                new_batch_queue_presence = False
                invalid_cards_list = []
                # columns= [date_of_purchase, batch_orderno, vendor, batch_status, giftcard_number, giftcard_pin, giftcard_value, amount_paid, retailer, balance,	status, last_checked, payment_type,	issuer_type, last_4_digit, payment_date]
                for i in range(len(df)):
                    dop = str(df.values[i][0])
                    # print("dop", dop)
                    dop = (pd.to_datetime(dop) if dop != "nan" else None)
                    if dop:
                        date_of_purchase = (dop.date() if dop != "nan" else None)
                        python_dop = date_of_purchase
                        current_time = pd.to_datetime('now').time()
                        date_of_purchase = pd.to_datetime(str(date_of_purchase)+' '+str(current_time))
                    else:
                        date_of_purchase = None
                        python_dop = None

                    orderno = str(df.values[i][1]).replace(" ", "") if str(df.values[i][1]) != "nan" else None
                    # print("orderno", orderno)
                    vendor = str(df.values[i][2]).strip() if str(df.values[i][2]) != "nan" else None
                    # print("vendor", vendor)
                    retailer = str(df.values[i][3]).strip() if str(df.values[i][3]) != "nan" else None
                    # print("retailer", retailer)
                    lower_retailer = ""
                    if retailer:
                        lower_retailer = retailer.lower()
                    giftcardno = str(df.values[i][4]).replace(" ", "") if str(df.values[i][4]) != "nan" else None
                    if giftcardno:
                        giftcardno = str(giftcardno).strip()
                    # print("giftcardno", giftcardno)
                    giftcard_pin = str((df.values[i][5])).replace(" ", "") if str(df.values[i][5]) != "nan" else None
                    if giftcard_pin:
                        giftcard_pin = str(giftcard_pin).strip()
                    # print("giftcard_pin", giftcard_pin)
                    # print(type(giftcard_pin))
                    giftcard_value = float(df.values[i][6]) if str(df.values[i][6]) != "nan" else 0
                    # print("giftcard_value", giftcard_value)
                    amount_paid = float(df.values[i][7]) if str(df.values[i][7]) != "nan" else 0
                    # print("amount_paid", amount_paid)
                    balance = float(df.values[i][8]) if str(df.values[i][8]) != "nan" else 0
                    # print("balance", balance)
                    status = str(df.values[i][9]).strip() if str(df.values[i][9]) != "nan" else None
                    # print("status", status)
                    last_checked = str(df.values[i][10])
                    last_checked = (pd.to_datetime(last_checked) if last_checked != "nan" else None)
                    date_of_creation = datetime.datetime.now()
                    date_of_modification = datetime.datetime.now()
                    discount = 0
                    if giftcard_value != 0:
                        discount = round((((giftcard_value - amount_paid) * 100) / giftcard_value), 2)

                    last_used = None
                    if last_checked:
                        last_used = (last_checked.date() if last_checked != "nan" else None)
                        last_used = pd.to_datetime(last_used)
                        if str(status).lower() == 'new':
                            last_used = None
                        # ## Date difference
                        # date_diff = pd.to_datetime('now') - last_used
                        # day_diff = date_diff // np.timedelta64(1, 'D')
                        # if day_diff < 3:
                        #     last_used = None

                    # print("last_used", last_used)
                    if orderno != None and len(orderno) != 0 and giftcardno != None and giftcardno[
                                                                                        -4:-2] != 'e+' and giftcardno[
                                                                                                           -4:-2] != 'E+' and giftcardno[
                                                                                                                              -2:] != '.0' and date_of_purchase != None:
                        if len(giftcardno) != 16 or len(giftcard_pin) !=4:
                            giftdict = {
                                "date_of_purchase": df.values[i][0],
                                "batch_orderno": df.values[i][1],
                                "vendor": df.values[i][2],
                                "retailer": df.values[i][3],
                                "giftcard_number": df.values[i][4],
                                "giftcard_pin": df.values[i][5],
                                "giftcard_value": df.values[i][6],
                                "amount_paid": df.values[i][7],
                                "balance": df.values[i][8],
                                "status": df.values[i][9],
                                "last_checked": df.values[i][10]
                            }
                            invalid_cards_list.append(giftdict)
                            gc_error += 1
                            continue

                        if python_dop <= datetime.date.today():
                            # checking wheather the giftcardno is already exists
                            # becs to avoid duplicacy of data
                            if giftcardno:
                                giftcardno = str(giftcardno).strip()
                            sql = "SELECT [id], [gift_card_no] FROM [dbo].[giftcardlist] WHERE [dbo].[giftcardlist].gift_card_no=?"
                            cursor.execute(sql, giftcardno)
                            giftcard_no = cursor.fetchall()
                            # when giftcard not exist
                            if len(giftcard_no) == 0:
                                # checking wheather the orderno is already exists
                                # becs to avoid duplicacy of data
                                # getting order no from the batchlist table
                                # getting login mail id to save in a database as a registered mail id
                                sql = "SELECT [id], [companyid] FROM [dbo].[usermaster] WHERE [dbo].[usermaster].[email]=?"
                                cursor.execute(sql, email)
                                data = cursor.fetchall()
                                    # Checking registered mail id exist or not
                                if len(data) != 0:
                                    # getting userid & companyid from the usermaster table
                                    user_id = data[0][0]
                                    companyid = data[0][1]
                                    # python date time module
                                    date_of_creation = datetime.datetime.now()
                                    date_of_modification = datetime.datetime.now()
                                    # if userid exist
                                    if user_id !=None and lower_retailer =="best buy":
                                        # if there will be a date in last_used then check_balance_status will be checked otherwise null
                                        if last_used != None:
                                            check_balance = int(balance)
                                            status = ("Balance" if check_balance > 0 and status == None else (
                                                "No Balance" if check_balance == 0 and status == None else status))
                                            # sql query for inserting data in giftcardlist table i.e gift_card_no, gift_card_pin, gift_card_value, amount_paid, retailer, batch_id, status, balance, userid, companyid, Date_creation, Date_modify

                                            sql = "INSERT INTO [dbo].[giftcardlist] (gift_card_no, gift_card_pin, gift_card_value, amount_paid, retailer, vendor, batch_id, date_of_purchase, balance, status, user_id, company_id, Date_creation, Date_modify, is_imported, last_used,discount, check_balance_status) OUTPUT INSERTED.ID VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);"
                                            val = [giftcardno, giftcard_pin, giftcard_value, amount_paid, retailer, vendor,
                                                   orderno, date_of_purchase, balance, status, user_id, companyid,
                                                   date_of_creation, date_of_modification, 1, last_used, discount, 'checked']
                                            cursor.execute(sql, val)
                                            giftcard_id = cursor.fetchone()[0]
                                            cursor.commit()
                                            gc_inserted += 1
                                            if status == 'New':
                                                if giftcard_id not in new_batch_queue:
                                                    new_batch_queue.append(giftcard_id)
                                                    new_batch_queue_presence = True
                                        else:
                                            # print(balance)
                                            # order_number_match = orderno
                                            check_balance = int(balance)
                                            status = ("New" if check_balance > 0 and status == None else (
                                                "No Balance" if check_balance == 0 and status == None else status))
                                            status = ("New" if check_balance > 0 else status)
                                            # sql query for inserting data in giftcardlist table i.e gift_card_no, gift_card_pin, gift_card_value, amount_paid, retailer, batch_id, status, balance, userid, companyid, Date_creation, Date_modify
                                            sql = "INSERT INTO [dbo].[giftcardlist] (gift_card_no, gift_card_pin, gift_card_value, amount_paid, retailer, vendor, batch_id, date_of_purchase, balance, status, user_id, company_id, last_used, discount, Date_creation, Date_modify, is_imported) OUTPUT INSERTED.ID VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);"
                                            val = [giftcardno, giftcard_pin, giftcard_value, amount_paid, retailer, vendor,
                                                   orderno, date_of_purchase, balance, status, user_id, companyid, last_used, discount,
                                                   date_of_creation, date_of_modification, 1]
                                            cursor.execute(sql, val)
                                            giftcard_id = cursor.fetchone()[0]
                                            cursor.commit()
                                            gc_inserted += 1

                                            # print("giftcard_id",giftcard_id)
                                            if giftcard_id not in new_batch_queue:
                                                new_batch_queue.append(giftcard_id)
                                                new_batch_queue_presence= True

                            # when giftcard already exist then it will update the data
                            else:
                                sql = "SELECT [id], [companyid] FROM [dbo].[usermaster] WHERE [dbo].[usermaster].[email]=?"
                                cursor.execute(sql, email)
                                data = cursor.fetchall()
                                if len(data) != 0:
                                    # getting userid & companyid from the usermaster table
                                    user_id = data[0][0]
                                    companyid = data[0][1]
                                    date_of_modification = datetime.datetime.now()
                                    if user_id != None and lower_retailer == "best buy":
                                        # if there will be a date in last_used then check_balance_status will be checked otherwise null
                                        if last_used != None:
                                            check_balance = int(balance)
                                            status = ("Balance" if  check_balance > 0 and status == None else (
                                                "No Balance" if check_balance == 0 and status == None else status))
                                            # updating giftcardlist
                                            sql = "UPDATE [dbo].[giftcardlist] SET [gift_card_pin] = ?, [gift_card_value] = ?, [amount_paid] = ?, [retailer] = ?, [vendor] = ?, [balance] = ?, [status] = ?, [date_of_purchase] = ?, [last_used] = ?, [discount] = ?, [is_imported] =?, [Date_modify] = ?, check_balance_status = ? WHERE [dbo].[giftcardlist].gift_card_no=?"
                                            val = [giftcard_pin, giftcard_value, amount_paid, retailer, vendor, balance, status,
                                                   date_of_purchase, last_used, discount, 1, date_of_modification, 'checked',
                                                   giftcardno]
                                            cursor.execute(sql, val)
                                            cursor.commit()
                                            gc_updated += 1
                                            if status == 'New':
                                                giftcard_id = giftcard_no[0][0]
                                                if giftcard_id not in new_batch_queue:
                                                    new_batch_queue.append(giftcard_id)
                                                    new_batch_queue_presence = True

                                        else:
                                            # updating giftcardlist
                                            check_balance = int(balance)
                                            status = ("New" if check_balance > 0 and status == None else (
                                                "No Balance" if check_balance == 0 and status == None else status))
                                            status = ("New" if check_balance > 0 else status)
                                            sql = "UPDATE [dbo].[giftcardlist] SET [gift_card_pin] = ?, [gift_card_value] = ?, [amount_paid] = ?, [retailer] = ?, [vendor]=?, [balance] = ?, [status] = ?, [check_balance_status] = ?, [date_of_purchase] = ?, [last_used] = ?, [discount] = ?, [is_imported] =?, [Date_modify] = ? WHERE [dbo].[giftcardlist].gift_card_no=?"
                                            val = [giftcard_pin, giftcard_value, amount_paid, retailer, vendor, balance, status,
                                                   None, date_of_purchase, last_used, discount, 1, date_of_modification,
                                                   giftcardno]
                                            cursor.execute(sql, val)
                                            cursor.commit()
                                            gc_updated += 1
                                            if status == 'New':
                                                giftcard_id = giftcard_no[0][0]
                                                if giftcard_id not in new_batch_queue:
                                                    new_batch_queue.append(giftcard_id)
                                                    new_batch_queue_presence = True

                        # if python_dop <= datetime.date.today():
                        #     print(giftdict)
                        else:
                            flash("Please check for the date of purchase should not be greater than current date.")
                            return redirect(url_for('giftcardlist'))
                    else:
                        flash("Please check for the Batch Number, GiftCard Number or Date of Purchase")
                        return redirect(url_for('giftcardlist'))

                if new_batch_queue_presence:
                    cursor = condb.cursor()
                    sql = "UPDATE [dbo].[giftcardlist] SET discount=(CASE WHEN gift_card_value!=0 THEN round(((gift_card_value-amount_paid)*100/amount_paid),2) else 0 END) WHERE gift_card_value>0"
                    cursor.execute(sql)
                    cursor.commit()

                    cursor = condb.cursor()
                    sql = "SELECT Max(queue_id) FROM [dbo].[giftcardlist]"
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    queue_id = data[0][0]
                    queue_id = queue_id if queue_id else 0
                    if queue_id != None:
                        giftcard_batch_list = tuple(new_batch_queue)
                        cursor = condb.cursor()
                        sql = "SELECT id, batch_id FROM [bestbuymaster].[dbo].[giftcardlist] where id in {0} group by batch_id,id order by id asc, batch_id asc".format(giftcard_batch_list)
                        cursor.execute(sql)
                        table_data = cursor.fetchall()
                        batch_id = ""
                        for data in table_data:
                            if str(batch_id).lower() != str(data[1]).lower():
                                batch_id = data[1]
                                queue_id = queue_id + 1
                            sql = "UPDATE [dbo].[giftcardlist] SET [queue_status] = ?, [queue_date] = ?, [queue_id] = ?, [check_balance_status] = ? WHERE [dbo].[giftcardlist].id=?"
                            val = ("que", datetime.datetime.now(), queue_id, None, data[0])
                            cursor.execute(sql, val)
                            cursor.commit()
                if len(invalid_cards_list) != 0:
                    os.remove('./report/invalidcards.xlsx') if os.path.exists(
                        './report/invalidcards.xlsx') else None
                    df = pd.DataFrame(invalid_cards_list,
                                      columns=['date_of_purchase', 'batch_orderno', 'vendor', 'retailer', 'giftcard_number', 'giftcard_pin', 'giftcard_value',
                                               'amount_paid', 'balance', 'status', 'last_checked'])
                    coldict = {'E': 'red'}
                    df.style.apply(highlight_cols, coldict=coldict)
                    df.to_excel('./report/invalidcards.xlsx', index=False)
                    if gc_error != 0:
                        message = "'{}' - Gift card have issued. Please check in downloaded Excelsheet. Please fix and upload again".format(
                            gc_error)
                    return redirect(url_for('downloadinvalidcards'))
                else:
                    os.remove('./report/invalidcards.xlsx') if os.path.exists(
                        './report/invalidcards.xlsx') else None

            if gc_inserted != 0:
                message = "'{}' - Gift card added.".format(gc_inserted)
                flash(message)
            if gc_updated != 0:
                message = "'{}' - Gift card updated.".format(gc_updated)
                flash(message)
            if gc_error != 0:
                message = "'{}' - Gift card have issued. Please check in downloaded Excelsheet. Please fix and upload again".format(gc_error)
                flash(message)
            if gc_inserted == 0 and gc_updated == 0 and gc_error == 0:
                flash("Please check the file, the data should not be empty")
            return redirect(url_for('giftcardlist'))
        else:
            return redirect(url_for('login'))

    except Exception as e:
        print(e)
        error = str(e)
        if '42000' in error:
            flash("Please check the file, the data should not be empty")
            return redirect(url_for('giftcardlist'))
        flash(error)
        return redirect(url_for('giftcardlist'))

def highlight_cols(s, coldict):
    if s.name in coldict.keys():
        return ['background-color: {}'.format(coldict[s.name])] * len(s)
    return [''] * len(s)

@app.route('/downloadinvalidcards', methods=["GET"])
def downloadinvalidcards():
    file_path = "./report/invalidcards.xlsx" if os.path.exists(
                        './report/invalidcards.xlsx') else None
    if file_path:
        return send_file(file_path, mimetype='text/csv',
                     attachment_filename=file_path,
                     as_attachment=True, cache_timeout=0)
    else:
        return redirect(url_for('giftcardlist'))

@app.route('/cardsrows', methods=['DELETE','PUT'])
def deleteCardsRows():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        cursor.execute("SELECT * FROM [dbo].[accessMaster] WHERE [dbo].[accessMaster].id=" + str(companyid))
        accessdata = cursor.fetchall()
        if len(accessdata) != 0:
            if accessdata[0].giftcard == 1:
                try:
                    if request.method == "DELETE":
                        # initializing cursor
                        cursor = condb.cursor()
                        # getting id of the selected filters
                        checkboxesArray = request.json['checkboxesArray']
                        # print(checkboxesArray)
                        if len(checkboxesArray) != 0:
                            for row in checkboxesArray:
                                sql = "SELECT gift_card_no FROM [dbo].[giftcardlist] where id= ?"
                                cursor.execute(sql, row)
                                card_data = cursor.fetchone()
                                if card_data != None:
                                    sql = "DELETE FROM [dbo].[giftcardlist] WHERE [dbo].[giftcardlist].gift_card_no=?"
                                    # execute sql query
                                    cursor.execute(sql, card_data.gift_card_no)
                                    # committing data on the database
                                    cursor.commit()
                                    sql = "DELETE FROM [dbo].[checkingqueuegiftcard] WHERE [dbo].[checkingqueuegiftcard].gift_card_no=?"
                                    # execute sql query
                                    cursor.execute(sql, card_data.gift_card_no)
                                    # committing data on the database
                                    cursor.commit()

                            return json.dumps({'status': 'OK'})
                        else:
                            return json.dumps({"code": 404, "error": "data not found"})
                    elif request.method == 'PUT':
                        # initializing cursor
                        cursor = condb.cursor()
                        # getting update data from the tracking page
                        updatedData = request.json
                        newValue = updatedData['newValue']
                        print(newValue)
                        id = updatedData['id']
                        print(id)
                        columnName = updatedData['cellName']
                        print(columnName)
                        # sql query for updating ordertracking status
                        sql = "UPDATE [dbo].[giftcardlist] SET {} = ? WHERE [id]= ?".format(
                            columnName)
                        # execute sql query
                        val = (newValue, id)
                        # execute sql query on the basic of gift_card_no & selected id
                        cursor.execute(sql, val)
                        # committing data on the database
                        cursor.commit()
                        rowcount = cursor.rowcount
                        if rowcount > 0:
                            columnName = str(columnName).title()
                            return json.dumps({'code': 200, "column": columnName})
                        else:
                            return json.dumps({'code': 404, "message": "Status Not Updated."})
                except Exception as e:
                    print(e)
            else:
                return redirect(url_for('login'))
        else:
            return redirect(url_for('login'))
    else:
        return redirect(url_for('login'))

# blank csv template download
@app.route('/downloadcsv', methods=["GET", "POST"])
def downloadCSV():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        cursor.execute("SELECT * FROM [dbo].[accessMaster] WHERE [dbo].[accessMaster].id=" + str(companyid))
        accessdata = cursor.fetchall()
        file_name = ""
        if 'download' in request.form:
            download = request.form['download']
            if download == '1':
                file_name = 'giftcard.xlsx'
            elif download == '2':
                file_name = 'ordertracking.xlsx'
        return send_file(file_name, mimetype='text/csv', attachment_filename=file_name, as_attachment=True,
                         cache_timeout=0)
    else:
        return redirect(url_for('login'))

@app.route('/giftcardcheckbalance', methods=['GET', 'POST'])
def giftcardCheckBalance():
    try:
        # initializing cursor import datetime
        import datetime
        cursor = condb.cursor()
        giftcardId = request.json['arr']

        if len(giftcardId) != 0:
            if len(giftcardId) == 1:
                giftcardId.append('0')
            else:
                giftcardId
            gitcard_ids = tuple(giftcardId)
            sql = "SELECT DISTINCT vendor FROM [bestbuymaster].[dbo].[giftcardlist] WHERE id in {0}".format(gitcard_ids)
            cursor.execute(sql)
            vendor_duplicate = cursor.fetchall()
            if(len(vendor_duplicate) == 1):
                sql = "SELECT Max(queue_id) FROM [dbo].[giftcardlist]"
                cursor.execute(sql)
                data = cursor.fetchall()

                queue_id = data[0][0]
                queue_id = queue_id if queue_id else 0

                cursor = condb.cursor()
                sql = "SELECT id, batch_id FROM [bestbuymaster].[dbo].[giftcardlist] where id in {0} group by batch_id, id order by id asc, batch_id asc".format(
                    gitcard_ids)
                cursor.execute(sql)
                table_data = cursor.fetchall()
                batch_id = ""

                # this contion run when 1 is already exist in queue id
                for data in table_data:
                    if str(batch_id).lower() != str(data[1]).lower():
                        batch_id = data[1]
                        queue_id = queue_id + 1
                    sql = "UPDATE [dbo].[giftcardlist] SET [queue_status] = ?, [queue_date] = ?, [queue_id] = ?, [check_balance_status] = ? WHERE [dbo].[giftcardlist].id=?"
                    val = ("que", datetime.datetime.now(), queue_id, None, data[0])
                    cursor.execute(sql, val)
                    cursor.commit()
                return json.dumps({'status': 'OK'})
            else:
                return json.dumps({"code": 400, "error": "Please choose one vendor at a time"})
        else:
            return json.dumps({"code": 400, "error": "You have not selected any item."})
    except Exception as e:
        print(e)
        return json.dumps({"code": 400, "error": str(e)})

@app.route('/exportgiftcardlist', methods=["GET", "POST"])
def exportgiftcardlist():
    try:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # getting data from checkboxes
            checkboxesArray = request.json['checkboxesArray']
            selectall_records = request.json['selectall']
            # getting json format i.e excel or csv
            reportFormat = request.json['report_format']
            giftcard_obj = GiftCardClass()
            if selectall_records == "allrecords":
                unSelectArr = request.json['unSelectArr']
                # print('unSelectArr',unSelectArr)
                if len(unSelectArr) == 1:
                    unSelectArr.append('0')
                else:
                    unSelectArr
                unSelectArr = tuple(unSelectArr)

                # getting status
                status_search = request.json['statusValue']
                columns_status_search = ("" if status_search == "Status" else status_search)

                statusValue = request.json['statusValue']
                # print(statusValue)
                columns_status_search = ("" if statusValue == "Status" else statusValue)

                searchbox = str(request.json['searchValue']).strip()

                dateValue = request.json['dateValue']
                # print(dateValue)

                columns_date_search = ("" if dateValue == "DateRange" else dateValue)

                today = datetime.datetime.now()
                lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
                date1, date2 = (
                    (today - datetime.timedelta(days=6)).date(),
                    today.date()) if columns_date_search == 'Last7days' else (
                    ((
                             today - datetime.timedelta(
                         days=today.weekday())).date(),
                     today.date()) if columns_date_search == "ThisWeek" else (
                        ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                         lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                            (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                                (today - datetime.timedelta(days=30)).date(),
                                today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                                datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                            datetime.date.strftime(
                                                                                                datetime.datetime.strptime(
                                                                                                    columns_date_search[
                                                                                                    18:28],
                                                                                                    '%m-%d-%Y'),
                                                                                                "%Y-%m-%d")) if len(
                                columns_date_search) == 28 else ("", "")))))
                # print(date1, date2)

                ################## CUSTOM FILTER SECTION ##################
                custom_filter = False

                lastUsed = request.json['lastUsed']
                # print(lastUsed)
                columns_last_used_search = ("" if lastUsed == "LastUsed" else dateValue)
                # print(columns_last_used_search)

                date3, date4 = (
                    (today - datetime.timedelta(days=6)).date(),
                    today.date()) if columns_last_used_search == 'Last7days' else (
                    ((today - datetime.timedelta(days=today.weekday())).date(),
                     today.date()) if columns_last_used_search == "ThisWeek" else (((today.replace(
                        day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                                                                                    lastMonthdate.date()) if columns_last_used_search == "LastMonth" else (
                        (today.replace(day=1).date(), today.date()) if columns_last_used_search == "ThisMonth" else (
                            (today - datetime.timedelta(days=30)).date(),
                            today.date()) if columns_last_used_search == "Last30days" else ((datetime.date.strftime(
                            datetime.datetime.strptime(columns_last_used_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                             datetime.date.strftime(
                                                                                                 datetime.datetime.strptime(
                                                                                                     columns_last_used_search[
                                                                                                     18:28],
                                                                                                     '%m-%d-%Y'),
                                                                                                 "%Y-%m-%d")) if len(
                            columns_last_used_search) == 28 else ("", "")))))

                columns_archived = request.json['archive']

                vendorValue = request.json['vendorValue']
                # print(vendorValue)
                columns_vendor_search = ("" if vendorValue == "Vendor" else vendorValue)

                column_order_range = request.json['order_range']
                column_cancellation_range = request.json['cancellation_range']
                column_balance_range = request.json['balance_range']
                column_cost_range = request.json['cost_range']
                column_value_range = request.json['value_range']
                #########################################################################################
                custom_items = [columns_vendor_search, columns_last_used_search, column_order_range,
                                column_cancellation_range, column_balance_range, column_cost_range, column_value_range]
                # print(custom_items)
                custom_filter = any(custom_items)
                # print(custom_filter)
                status_tuple = ()
                query_shorter, custom_query = [], ""
                if columns_date_search != "":
                    custom_dtrange = "CAST([giftcardlist].[date_of_purchase] AS DATE) between '" + str(
                        date1) + "' and '" + str(date2) + "'"
                    query_shorter.append(custom_dtrange)
                if columns_status_search != "":
                    status_tuple = tuple(columns_status_search.split(","))
                    status_tuple = '{}'.format(status_tuple)
                    status_tuple = status_tuple.replace(",)", ")")
                    custom_status = "[giftcardlist].[status] IN {}".format(status_tuple)
                    query_shorter.append(custom_status)
                if len(searchbox) != 0:
                    # custom_searchbox = searchbox
                    custom_searchbox = "(giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR CONVERT (varchar(10), giftcardlist.date_of_purchase,110) LIKE '{}%' OR CONVERT (varchar(10), last_used,110) LIKE '{}%' OR amount_paid LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%' OR giftcardlist.batch_id LIKE '{}%')".format(
                        searchbox, searchbox, searchbox,
                        searchbox, searchbox, searchbox,
                        searchbox, searchbox, searchbox,
                        searchbox
                    )
                    query_shorter.append(custom_searchbox)
                if columns_archived:
                    is_archived = "((YEAR(giftcardlist.date_of_purchase) < YEAR(GETDATE()) and giftcardlist.balance > 0) or (YEAR(giftcardlist.date_of_purchase) = YEAR(GETDATE())))"
                    query_shorter.append(is_archived)
                if len(unSelectArr) != 0:
                    unSlectedArray = "giftcardlist.[id] NOT IN {}".format(
                        unSelectArr)
                    query_shorter.append(unSlectedArray)

                if len(query_shorter) == 0:
                    custom_query = ''
                elif len(query_shorter) == 1:
                    custom_query = ''.join(query_shorter)
                else:
                    custom_query = ' AND '.join(query_shorter)

                if custom_filter:
                    query_shorter_having = []
                    if len(column_order_range) != 0:
                        query_shorter_having.append("count([giftcardtransaction].[ordernumber]) BETWEEN '" + str(
                            column_order_range[0]) + "' AND '" + str(column_order_range[1]) + "'")
                    if len(column_cancellation_range) != 0:
                        query_shorter_having.append(
                            "sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) BETWEEN '" + str(
                                column_cancellation_range[0]) + "' AND '" + str(column_cancellation_range[1]) + "'")
                    if len(column_balance_range) != 0:
                        query_shorter_having.append(
                            "[giftcardlist].[balance] BETWEEN '" + str(column_balance_range[0]) + "' AND '" + str(
                                column_balance_range[1]) + "'")
                    if len(column_cost_range) != 0:
                        query_shorter_having.append(
                            "[giftcardlist].[amount_paid] BETWEEN '" + str(column_cost_range[0]) + "' AND '" + str(
                                column_cost_range[1]) + "'")
                    if len(column_value_range) != 0:
                        query_shorter_having.append(
                            "[giftcardlist].[gift_card_value] BETWEEN '" + str(column_value_range[0]) + "' AND '" + str(
                                column_value_range[1]) + "'")
                    if columns_last_used_search != '':
                        query_shorter_having.append(
                            "CAST([giftcardlist].[last_used] AS DATE) between '" + str(date3) + "' and '" + str(
                                date4) + "'")
                    if columns_vendor_search != '':
                        query_shorter_having.append("[giftcardlist].[vendor] = '" + str(columns_vendor_search) + "'")

                    if len(query_shorter_having) == 0:
                        custom_query_having = ''
                    elif len(query_shorter_having) == 1:
                        custom_query_having = ''.join(query_shorter_having)
                    else:
                        custom_query_having = ' AND '.join(query_shorter_having)

                    sql = giftcard_obj.selectalldownloadwithhaving(custom_query_having, custom_query)
                    cursor.execute(sql)
                else:
                    sql = giftcard_obj.selectalldownloadwithouthaving(custom_query)
                    cursor.execute(sql)

            elif len(checkboxesArray) != 0:
                # addding dictionary data into the list
                list_of_giftcard = []
                # WHERE id IN (1,5,8,9)
                for giftcard_id in checkboxesArray:
                    # getting data by joining 2 tables giftcardtransactionlist & giftcardlist
                    sql = "SELECT giftcardlist.retailer, giftcardlist.batch_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, CONVERT (varchar(10),last_used ,110) 'last_used', CONVERT (varchar(10),date_of_purchase ,110) 'updated_at', giftcardlist.[id], count(ordernumber) as no_of_order, sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) as cancellation_count FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [dbo].[giftcardlist].id = ? group by [dbo].[giftcardlist].gift_card_no, giftcardlist.retailer, [gift_card_pin], giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.[id], len(case when order_purchase_status = 'Cancelled' then 1 else 0 end), giftcardlist.batch_id, giftcardlist.vendor ORDER BY [dbo].[giftcardlist].date_of_purchase DESC"
                    # execute sql query
                    cursor.execute(sql, giftcard_id)

                    # fetching giftcardlist data from the database
                    giftcardlist_data = cursor.fetchone()

                    print(giftcardlist_data)

                    giftdict = {
                        "DOP": giftcardlist_data.updated_at,
                        "Order No.": giftcardlist_data.batch_id,
                        "Vendor": giftcardlist_data.vendor,
                        "Retailer": giftcardlist_data.retailer,
                        "Giftcard #": giftcardlist_data.gift_card_no,
                        "Pin": giftcardlist_data.gift_card_pin,
                        "Status": giftcardlist_data.status,
                        "Balance": giftcardlist_data.balance,
                        "Last Checked": giftcardlist_data.last_used,
                        "# of Orders": giftcardlist_data.no_of_order,
                        "Cancellations": giftcardlist_data.cancellation_count
                    }

                    list_of_giftcard.append(giftdict)

                # creating a dataframe of sql records
                df = pd.DataFrame(list_of_giftcard,
                                  columns=['DOP', 'Order No.', 'Vendor', 'Retailer', 'Giftcard #', 'Pin', 'Status', 'Balance', 'Last Checked',
                                           '# of Orders', 'Cancellations'])

                if reportFormat == "excel":
                    # create the excel file using pandas
                    df.to_excel('./report/giftcardlistreport.xlsx', index=False)
                    #remove the excel file if exist
                    os.remove('./report/giftcardlistreport.csv') if os.path.exists('report/giftcardlistreport.csv') else None
                    # df.to_excel('giftcardlistreport.xlsx', index=False)
                else:
                    # create the excel file using pandas
                    df.to_excel('./report/giftcardlistreport.csv', index=False)
                    # remove the excel file if exist
                    os.remove('./report/giftcardlistreport.xlsx') if os.path.exists(
                        './report/giftcardlistreport.xlsx') else None
                    # df.to_excel('giftcardlistreport.csv', index=False)
                return jsonify({"code": 200, "success": "true"})

            # fetching giftcardlist data from the database
            giftcardlist_data = cursor.fetchall()
            # print(giftcardlist_data)

            # addding dictionary data into the list
            list_of_giftcard = []
            # convert giftcardlist data into dictionary
            # if re.search("Bad|Invalid|Value Off|Loss",' '.join(status_tuple),flags=re.IGNORECASE):
            if "Bad" in status_tuple or "Invalid" in status_tuple or "Value Off" in status_tuple or "Loss" in status_tuple:
                for giftcardlist in giftcardlist_data:
                    giftdict = {
                        "DOP": giftcardlist.updated_at,  # it is updated at value i.e date of purchase of giftcard value
                        "Order No.": giftcardlist.batch_id,
                        "Vendor": giftcardlist.vendor,
                        "Retailer": giftcardlist.retailer,
                        "Giftcard #": giftcardlist.gift_card_no,
                        "Pin": giftcardlist.gift_card_pin,
                        "Value": giftcardlist.gift_card_value,
                        "Cost": giftcardlist.amount_paid,
                        "Status": giftcardlist.status,
                        "Balance": giftcardlist.balance,
                        "Last Checked": giftcardlist.last_used,
                        "# of Orders": giftcardlist.no_of_order,
                        "Cancellations": giftcardlist.cancellation_count
                    }

                    list_of_giftcard.append(giftdict)
                # creating a dataframe of sql records
                df = pd.DataFrame(list_of_giftcard,
                                  columns=['DOP', 'Order No.', 'Vendor', 'Retailer', 'Giftcard #', 'Pin', 'Value', 'Cost',
                                           'Status', 'Balance', 'Last Checked', '# of Orders', 'Cancellations'])
                # print(df)
            else:
                for giftcardlist in giftcardlist_data:
                    giftdict = {
                        "DOP": giftcardlist.updated_at,  # it is updated at value i.e date of purchase of giftcard value
                        "Order No.": giftcardlist.batch_id,
                        "Vendor": giftcardlist.vendor,
                        "Retailer": giftcardlist.retailer,
                        "Giftcard #": giftcardlist.gift_card_no,
                        "Pin": giftcardlist.gift_card_pin,
                        "Status": giftcardlist.status,
                        "Balance": giftcardlist.balance,
                        "Last Checked": giftcardlist.last_used,
                        "# of Orders": giftcardlist.no_of_order,
                        "Cancellations": giftcardlist.cancellation_count
                    }

                    list_of_giftcard.append(giftdict)

                # creating a dataframe of sql records
                df = pd.DataFrame(list_of_giftcard,
                                  columns=['DOP', 'Order No.', 'Vendor', 'Retailer', 'Giftcard #', 'Pin', 'Status', 'Balance', 'Last Checked',
                                           '# of Orders', 'Cancellations'])
                # print(df)
            # create the excel file using pandas
            # logger.info("{0} total rows for download -2".format(str(len(list_of_giftcard))))
            # df.to_excel('./giftcardlistreport.xlsx', index=False)
            # return jsonify({"code": 200, "success": "true"})
            if reportFormat == "excel":
                # create the excel file using pandas
                df.to_excel('./report/giftcardlistreport.xlsx', index=False)
                # remove the excel file if exist
                os.remove('./report/giftcardlistreport.csv') if os.path.exists(
                    './report/giftcardlistreport.csv') else None
                # df.to_excel('giftcardlistreport.xlsx', index=False)
            else:
                # create the excel file using pandas
                df.to_excel('./report/giftcardlistreport.csv', index=False)
                # remove the excel file if exist
                os.remove('./report/giftcardlistreport.xlsx') if os.path.exists(
                    './report/giftcardlistreport.xlsx') else None
                # df.to_excel('giftcardlistreport.csv', index=False)

            return jsonify({"code": 200, "success": "true"})
        file_path = "./report/giftcardlistreport.xlsx"
        return send_file(file_path, mimetype='text/csv',
                             attachment_filename= file_path,
                             as_attachment=True, cache_timeout=0)
    except Exception as e:
        print(e)
        # logger.info("{0} download section".format(str(e)))

@app.route('/giftcardlistselectall', methods=['GET', 'POST', 'DELETE'])
def giftcardlistselectall():
    try:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # print(request.json)
            giftcard_obj = GiftCardClass()

            checkbalance = request.json['checkbalance']
            print('checkbalance', checkbalance)

            unSelectArr = request.json['unSelectArr']
            print('unSelectArr', unSelectArr)
            if len(unSelectArr) == 1:
                unSelectArr.append('0')
            else:
                unSelectArr
            unSelectArr = tuple(unSelectArr)

            records = request.json['records']
            # print(records)

            statusValue = request.json['statusValue']
            # print(statusValue)
            columns_status_search = ("" if statusValue == "Status" else statusValue)

            dateValue = request.json['dateValue']
            # print(dateValue)

            searchbox = str(request.json['searchValue']).strip()

            columns_date_search = ("" if dateValue == "DateRange" else dateValue)

            today = datetime.datetime.now()
            lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
            date1, date2 = (
                (today - datetime.timedelta(days=6)).date(), today.date()) if columns_date_search == 'Last7days' else (
                ((
                         today - datetime.timedelta(
                     days=today.weekday())).date(),
                 today.date()) if columns_date_search == "ThisWeek" else (
                    ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                     lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                        (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                            (today - datetime.timedelta(days=30)).date(),
                            today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                            datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                        datetime.date.strftime(
                                                                                            datetime.datetime.strptime(
                                                                                                columns_date_search[
                                                                                                18:28],
                                                                                                '%m-%d-%Y'),
                                                                                            "%Y-%m-%d")) if len(
                            columns_date_search) == 28 else ("", "")))))
            # print(date1, date2)

            ################## CUSTOM FILTER SECTION ##################
            custom_filter = False

            lastUsed = request.json['lastUsed']
            # print(lastUsed)
            columns_last_used_search = ("" if lastUsed == "LastUsed" else dateValue)
            # print(columns_last_used_search)

            date3, date4 = (
            (today - datetime.timedelta(days=6)).date(), today.date()) if columns_last_used_search == 'Last7days' else (
                ((today - datetime.timedelta(days=today.weekday())).date(),
                 today.date()) if columns_last_used_search == "ThisWeek" else (((today.replace(
                    day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                                                                                lastMonthdate.date()) if columns_last_used_search == "LastMonth" else (
                    (today.replace(day=1).date(), today.date()) if columns_last_used_search == "ThisMonth" else (
                    (today - datetime.timedelta(days=30)).date(),
                    today.date()) if columns_last_used_search == "Last30days" else ((datetime.date.strftime(
                        datetime.datetime.strptime(columns_last_used_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                     datetime.date.strftime(
                                                                                         datetime.datetime.strptime(
                                                                                             columns_last_used_search[
                                                                                             18:28], '%m-%d-%Y'),
                                                                                         "%Y-%m-%d")) if len(
                        columns_last_used_search) == 28 else ("", "")))))
            # print(date3, date4)

            columns_archived = request.json['archive']

            vendorValue = request.json['vendorValue']
            # print(vendorValue)
            columns_vendor_search = ("" if vendorValue == "Vendor" else vendorValue)

            column_order_range = request.json['order_range']
            # print("Order Range ", column_order_range)
            column_cancellation_range = request.json['cancellation_range']
            # print("Cancellation Range ", column_cancellation_range)
            column_balance_range = request.json['balance_range']
            # print("Balance Range ", column_balance_range)
            column_cost_range = request.json['cost_range']
            # print("Cost Range ", column_cost_range)
            column_value_range = request.json['value_range']
            #########################################################################################
            custom_items = [columns_vendor_search, columns_last_used_search, column_order_range,
                            column_cancellation_range, column_balance_range, column_cost_range, column_value_range]
            # print(custom_items)
            custom_filter = any(custom_items)
            # print(custom_filter)
            status_tuple = ()
            query_shorter, custom_query = [], ""
            if columns_date_search != "":
                custom_dtrange = "CAST([giftcardlist].[date_of_purchase] AS DATE) between '" + str(
                    date1) + "' and '" + str(date2) + "'"
                query_shorter.append(custom_dtrange)
            if columns_status_search != "":
                status_tuple = tuple(columns_status_search.split(","))
                status_tuple = '{}'.format(status_tuple)
                status_tuple = status_tuple.replace(",)", ")")
                custom_status = "[giftcardlist].[status] IN {}".format(status_tuple)
                query_shorter.append(custom_status)
            if len(searchbox) != 0:
                # custom_searchbox = searchbox
                custom_searchbox = "(giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR CONVERT (varchar(10), giftcardlist.date_of_purchase,110) LIKE '{}%' OR CONVERT (varchar(10), last_used,110) LIKE '{}%' OR amount_paid LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%' OR giftcardlist.batch_id LIKE '{}%')".format(
                    searchbox, searchbox, searchbox,
                    searchbox, searchbox, searchbox,
                    searchbox, searchbox, searchbox,
                    searchbox
                )
                query_shorter.append(custom_searchbox)
            if columns_archived:
                is_archived = "((YEAR(giftcardlist.date_of_purchase) < YEAR(GETDATE()) and giftcardlist.balance > 0) or (YEAR(giftcardlist.date_of_purchase) = YEAR(GETDATE())))"
                query_shorter.append(is_archived)
            if len(unSelectArr) != 0:
                unSlectedArray = "giftcardlist.[id] NOT IN {}".format(
                    unSelectArr)
                query_shorter.append(unSlectedArray)

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            if custom_filter:
                query_shorter_having = []
                if len(column_order_range) != 0:
                    query_shorter_having.append("count([giftcardtransaction].[ordernumber]) BETWEEN '" + str(
                        column_order_range[0]) + "' AND '" + str(column_order_range[1]) + "'")
                if len(column_cancellation_range) != 0:
                    query_shorter_having.append(
                        "sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) BETWEEN '" + str(
                            column_cancellation_range[0]) + "' AND '" + str(column_cancellation_range[1]) + "'")
                if len(column_balance_range) != 0:
                    query_shorter_having.append(
                        "[giftcardlist].[balance] BETWEEN '" + str(column_balance_range[0]) + "' AND '" + str(
                            column_balance_range[1]) + "'")
                if len(column_cost_range) != 0:
                    query_shorter_having.append(
                        "[giftcardlist].[amount_paid] BETWEEN '" + str(column_cost_range[0]) + "' AND '" + str(
                            column_cost_range[1]) + "'")
                if len(column_value_range) != 0:
                    query_shorter_having.append(
                        "[giftcardlist].[gift_card_value] BETWEEN '" + str(column_value_range[0]) + "' AND '" + str(
                            column_value_range[1]) + "'")
                if columns_last_used_search != '':
                    query_shorter_having.append(
                        "CAST([giftcardlist].[last_used] AS DATE) between '" + str(date3) + "' and '" + str(
                            date4) + "'")
                if columns_vendor_search != '':
                    query_shorter_having.append("[giftcardlist].[vendor] = '" + str(columns_vendor_search) + "'")

                if len(query_shorter_having) == 0:
                    custom_query_having = ''
                elif len(query_shorter_having) == 1:
                    custom_query_having = ''.join(query_shorter_having)
                else:
                    custom_query_having = ' AND '.join(query_shorter_having)

                sql = giftcard_obj.selectallmakingquerywithhaving(custom_query_having, custom_query)
            else:
                sql = giftcard_obj.selectallmakingquerywithouthaving(custom_query)
            print(sql)
            if checkbalance == True:
                # getting id of the selected filters
                if len(unSelectArr) == 0:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
                else:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
            else:
                cursor.execute(sql)
                # fetching giftcardl
                batch_count = cursor.fetchall()
                no_of_records = len(batch_count)

            if checkbalance == True:
                return json.dumps({"arr": checkboxesArray})
            else:
                return json.dumps({'total_record': no_of_records})

    except Exception as e:
        print(e)
        return json.dumps({"code": 400, "error": str(e)})
############### ---------End Gift Card Page-------------  ########################

############### --------- CHECKING QUEUE Page-------------  ########################
@app.route('/checkingqueue', methods=['GET', 'POST'])
def checkingqueue():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        if len(accessdata) != 0:
            if accessdata[0].giftcard == 1:
                if request.method =='POST':
                    try:
                        import datetime
                        # initializing cursor
                        cursor = condb.cursor()

                        obj_queue = CheckingQueueClass()

                        get_ids = request.json['get_ids']
                        print('get ids', get_ids)

                        unSelectArr = request.json['unSelectArr']
                        print('unSelectArr', unSelectArr)

                        if len(unSelectArr) == 1:
                            unSelectArr.append('0')
                        else:
                            unSelectArr
                        unSelectArr = tuple(unSelectArr)

                        records = request.json['records']
                        # print(records)

                        vendorValue = request.json['vendorValue']
                        # print(statusValue)
                        columns_vendor_search = ("" if vendorValue == "Vendor" else vendorValue)

                        columns_date = request.json['dateValue']
                        print(columns_date)
                        columns_date_search = ("" if columns_date == "DateRange" else columns_date)
                        # print(columns_date_search)
                        # print(len(columns_date_search))

                        today = datetime.datetime.now()
                        lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
                        date1, date2 = (
                            (today - datetime.timedelta(days=6)).date(),
                            today.date()) if columns_date_search == 'Last7days' else (
                            ((
                                     today - datetime.timedelta(
                                 days=today.weekday())).date(),
                             today.date()) if columns_date_search == "ThisWeek" else (
                                ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                                 lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                                    (today.replace(day=1).date(),
                                     today.date()) if columns_date_search == "ThisMonth" else (
                                        (today - datetime.timedelta(days=30)).date(),
                                        today.date()) if columns_date_search == "Last30days" else (
                                        (datetime.date.strftime(
                                            datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'),
                                            "%Y-%m-%d"),
                                         datetime.date.strftime(
                                             datetime.datetime.strptime(
                                                 columns_date_search[
                                                 18:28],
                                                 '%m-%d-%Y'),
                                             "%Y-%m-%d")) if len(
                                            columns_date_search) == 28 else ("", "")))))
                        date1 = str(date1)
                        date2 = str(date2)

                        ################## CUSTOM FILTER SECTION ##################
                        custom_filter = False
                        column_gift_card_no_range = request.json['gift_card_no_range']
                        print("Gift card No Range ", column_gift_card_no_range)
                        column_discrepencies_range = request.json['discrepencies_range']
                        print("Discrepencies Range ", column_discrepencies_range)
                        custom_items = [column_gift_card_no_range, column_discrepencies_range]
                        custom_filter = any(custom_items)

                        custom_dtrange, custom_vendor, custom_select_array = None, None, None
                        if columns_date_search != "":
                            custom_dtrange = "CAST([giftcardlist].[queue_date] AS DATE) between '" + str(
                                date1) + "' and '" + str(date2) + "'"
                        if columns_vendor_search != "":
                            custom_vendor = "[giftcardlist].[vendor] = '{}'".format(columns_vendor_search)
                        if len(unSelectArr) != 0:
                            custom_select_array = "giftcardlist.[id] NOT IN {}".format(
                                unSelectArr)
                        if custom_filter:
                            query_shorter = []
                            if len(column_gift_card_no_range) != 0:
                                query_shorter.append("count(queue_id) BETWEEN '" + str(
                                    column_gift_card_no_range[0]) + "' AND '" + str(
                                    column_gift_card_no_range[1]) + "'")
                            if len(column_discrepencies_range) != 0:
                                query_shorter.append(
                                    "count(case when status = 'Invalid' then 1 else null end) BETWEEN '" + str(
                                        column_discrepencies_range[0]) + "' AND '" + str(
                                        column_discrepencies_range[1]) + "'")

                            if len(query_shorter) == 0:
                                custom_query = ''
                            elif len(query_shorter) == 1:
                                custom_query = ''.join(query_shorter)
                            else:
                                custom_query = ' AND '.join(query_shorter)

                            sql = obj_queue.checkingqueueselectallwithhaving(custom_query, custom_dtrange,
                                                                         custom_vendor, custom_select_array)
                        else:
                            sql = obj_queue.checkingqueueselectallwithouthaving(custom_dtrange, custom_vendor, custom_select_array)

                        if get_ids == True:
                            checkboxesArray = []
                            # getting id of the selected filters
                            if len(unSelectArr) == 0:
                                cursor.execute(sql)
                                data = cursor.fetchall()
                                checkboxesArray = [datum[0] for datum in data]
                            else:
                                cursor.execute(sql)
                                data = cursor.fetchall()
                                checkboxesArray = [datum[0] for datum in data]
                        else:
                            cursor.execute(sql)
                            # fetching giftcardl
                            batch_count = cursor.fetchall()
                            no_of_records = len(batch_count)

                        if get_ids == True:
                            return json.dumps({"arr": checkboxesArray})
                        else:
                            return json.dumps({'total_record': no_of_records})
                    except Exception as e:
                        print(e)
                        return json.dumps({"code": 400, "error": str(e)})
                sql = "SELECT DISTINCT vendor FROM [dbo].[giftcardlist] where queue_status='que'"
                cursor.execute(sql)
                vendor_Data = cursor.fetchall()

                range_slider_data = {}
                sql = "SELECT MAX(subtable.queue_id_count) as max_gift_card_nos, MAX(subtable.status_count) as max_discrepencies FROM (SELECT count(queue_id) as queue_id_count, count(case when status = 'Invalid' then 1 else null end) as status_count FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' group by queue_id) subtable"
                cursor.execute(sql)
                table_Data = cursor.fetchone()
                gift_card_no_slider, discrepencies_slider = {}, {}
                if None not in table_Data:
                    min_gift_card_nos, min_discrepencies = 0, 0
                    max_gift_card_nos = int(table_Data.max_gift_card_nos)
                    max_discrepencies = int(table_Data.max_discrepencies)

                    gift_card_no_slider['min'] = min_gift_card_nos
                    gift_card_no_slider['from'] = min_gift_card_nos
                    discrepencies_slider['min'] = min_discrepencies
                    discrepencies_slider['from'] = min_discrepencies

                    if max_gift_card_nos == 0:
                        max_gift_card_nos += 1

                    if max_discrepencies == 0:
                        max_discrepencies += 1

                    gift_card_no_slider['max'] = max_gift_card_nos
                    gift_card_no_slider['to'] = max_gift_card_nos
                    discrepencies_slider['max'] = max_discrepencies
                    discrepencies_slider['to'] = max_discrepencies
                    range_slider_data['gift_card_no_slider'] = gift_card_no_slider
                    range_slider_data['discrepencies_slider'] = discrepencies_slider
                else:
                    gift_card_no_slider['min'], gift_card_no_slider['from'] = 0, 0
                    gift_card_no_slider['max'], gift_card_no_slider['to'] = 1, 1
                    discrepencies_slider['min'], discrepencies_slider['from'] = 0, 0
                    discrepencies_slider['max'], discrepencies_slider['to'] = 1, 1
                    range_slider_data['gift_card_no_slider'] = gift_card_no_slider
                    range_slider_data['discrepencies_slider'] = discrepencies_slider

                return render_template('checkingqueue.html', accessdata=accessdata, vendor = vendor_Data, sliderdata=range_slider_data)
            else:
                return redirect(url_for('index'))
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('login'))

@app.route('/checkingqueuedatatable', methods=['GET', 'POST'])
def CheckingQueueDatatable():
    try:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            obj_queue = CheckingQueueClass()
            # getting all json data from the datatable
            content = request.json
            print(content)
            # get columns from the content(json data)
            columns = content['columns']

            # initially start show 0 & on click next it will increased accroding to defined rows in the table  (Display index for the first record shown on the current page)
            offset = content['start']
            # print(offset)
            # Display length (number of records) use --> used in fetch to get no of next records from the database
            length = content['length']

            # filter for date range using upper dropdown
            columns_date = columns[1]
            # print('columns_date', columns_date)
            columns_date = columns_date['search']['value']
            # print(columns_date)
            columns_date_search = ("" if columns_date == "DateRange" else columns_date)
            # print(columns_date_search)
            # print(len(columns_date_search))

            today = datetime.datetime.now()
            lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
            date1, date2 = (
                (today - datetime.timedelta(days=6)).date(), today.date()) if columns_date_search == 'Last7days' else (
                ((
                         today - datetime.timedelta(
                     days=today.weekday())).date(),
                 today.date()) if columns_date_search == "ThisWeek" else (
                    ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                     lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                        (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                            (today - datetime.timedelta(days=30)).date(),
                            today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                            datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                        datetime.date.strftime(
                                                                                            datetime.datetime.strptime(
                                                                                                columns_date_search[
                                                                                                18:28],
                                                                                                '%m-%d-%Y'),
                                                                                            "%Y-%m-%d")) if len(
                            columns_date_search) == 28 else ("", "")))))
            date1 = str(date1)
            date2 = str(date2)

            # the search field for the datatables
            search = content['search']
            searchbox = search['value'].strip()
            searchbox = "{" if searchbox.startswith("'") else searchbox
            searchbox = "{" if searchbox.startswith("-") else searchbox
            searchbox = "{" if searchbox.startswith(";") else searchbox

            # for sorting
            orderable = content['order']
            sorting = ["queue_date" if orderable[0]['column'] == 1 else (
                "batch_id" if orderable[0]['column'] == 2 else (
                    'queue_id_count' if orderable[0]['column'] == 4 else (
                       'vendor' if orderable[0]['column'] == 3 else (
                          'status_count' if orderable[0]['column'] == 6  else ""))))]
            direction = orderable[0]['dir']
            custom_status = 'que'

            ## Vendor Filter
            columns_vendor = columns[3]

            columns_vendor_search = columns_vendor['search']['value']
            if columns_vendor_search == "Vendor":
                columns_vendor_search = ""


            custom_filter = False
            column_gift_card_no_range = content['gift_card_no_range']
            print("Gift card No Range ", column_gift_card_no_range)
            column_discrepencies_range = content['discrepencies_range']
            print("Discrepencies Range ", column_discrepencies_range)
            custom_items = [column_gift_card_no_range, column_discrepencies_range]
            # print(custom_items)
            custom_filter = any(custom_items)

            custom_searchbox = custom_dtrange = custom_vendor = custom_sorting = custom_direction = None
            if columns_date_search != "":
                custom_dtrange = "CAST([giftcardlist].[queue_date] AS DATE) between '" + str(
                    date1) + "' and '" + str(date2) + "'"
            if columns_vendor_search != "":
                custom_vendor = "[giftcardlist].[vendor] = '{}'".format(columns_vendor_search)
            if len(sorting[0]) != 0:
                custom_sorting = sorting[0]
                custom_direction = direction
            if len(searchbox) != 0:
                custom_searchbox = searchbox

            ################# PLANING ###########################
            if custom_filter:
                query_shorter = []
                if len(column_gift_card_no_range) != 0:
                    query_shorter.append("count(queue_id) BETWEEN '" + str(
                        column_gift_card_no_range[0]) + "' AND '" + str(column_gift_card_no_range[1]) + "'")
                if  len(column_discrepencies_range) != 0:
                    query_shorter.append("count(case when status = 'Invalid' then 1 else null end) BETWEEN '" + str(
                        column_discrepencies_range[0]) + "' AND '" + str(column_discrepencies_range[1]) + "'")

                if len(query_shorter) == 0:
                    custom_query = ''
                elif len(query_shorter) == 1:
                    custom_query = ''.join(query_shorter)
                else:
                    custom_query = ' AND '.join(query_shorter)

                sql = obj_queue.checkingqueuecountwithhaving(custom_query, custom_dtrange, custom_vendor, custom_searchbox)
                cursor.execute(sql)
                # fetching buying details
                count = cursor.fetchall()
                # print("count", count)
                try:
                    no_of_records = len(count)
                except Exception as e:
                    no_of_records = count[0][0]
                # print("no_of_records", no_of_records)

                sql = obj_queue.checkingqueuewithhaving(custom_query, offset, length, custom_dtrange, custom_vendor,
                                         custom_sorting, custom_direction, custom_searchbox)
                # print(sql)
                cursor.execute(sql)
            else:
                sql = obj_queue.checkingqueuecountwithouthaving(custom_dtrange, custom_vendor, custom_searchbox)
                print(sql)
                cursor.execute(sql)
                # fetching buying details
                count = cursor.fetchall()
                # print("count", count)
                try:
                    no_of_records = len(count)
                except Exception as e:
                    no_of_records = count[0][0]

                # print("no_of_records", no_of_records)
                sql = obj_queue.checkingqueuewithouthaving(offset, length, custom_dtrange, custom_vendor,
                                    custom_sorting, custom_direction, custom_searchbox)
                print(sql)
                cursor.execute(sql)

            # fetching checking queue data from the database
            queue_data = cursor.fetchall()

            checkingqueue_list = []
            for checkingqueue in queue_data:
                # print(checkingqueue)
                # print(checkingqueue.queue_id_count)
                # print(len(checkingqueue.queue_id_count))
                progress = int((checkingqueue.balance_status_count / checkingqueue.queue_id_count) * 100)
                checkingqueue_dict = {
                    "vendor": checkingqueue.vendor,
                    "orderNo": checkingqueue.batch_id,
                    "id": checkingqueue.queue_id,
                    "queue_date": checkingqueue.queue_date,
                    "no_of_cards": checkingqueue.queue_id_count,
                    "progress": f'{progress}%',
                    "Discrepencies": checkingqueue.status_count,
                    "newmoney": round(checkingqueue.new_money, 2)
                }
                checkingqueue_list.append(checkingqueue_dict)
            responsedata = {
                "draw": content['draw'],  # draw give pagination number i.e 1 or 2 or 3
                "data": checkingqueue_list,
                "recordsTotal": no_of_records,
                "recordsFiltered": no_of_records
            }
            return jsonify(responsedata)
    except Exception as e:
        print(e)

####################### ---------------- CHECKING QUEUE DETAIL PAGE ---------------- ###############
@app.route('/checkingqueuedetails', methods=['GET', 'POST', 'DELETE', 'PUT'])
def checkingqueuedetails():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        if len(accessdata) != 0:
            if accessdata[0].giftcard == 1:
                if request.method == 'POST':
                    queue_id = request.args['id']
                    try:
                        # initializing cursor
                        cursor = condb.cursor()
                        obj_queue = CheckingQueueDetailsClass()
                        # getting all json data from the datatable
                        content = request.json
                        print(content)
                        # get columns from the content(json data)
                        columns = content['columns']

                        # initially start show 0 & on click next it will increased accroding to defined rows in the table  (Display index for the first record shown on the current page)
                        offset = content['start']
                        # print(offset)
                        # Display length (number of records) use --> used in fetch to get no of next records from the database
                        length = content['length']
                        # the search field for the datatables
                        search = content['search']
                        searchbox = search['value'].strip()
                        searchbox = "{" if searchbox.startswith("'") else searchbox
                        searchbox = "{" if searchbox.startswith("-") else searchbox
                        searchbox = "{" if searchbox.startswith(";") else searchbox

                        # for sorting
                        orderable = content['order']
                        sorting = ["max(queue_date)" if orderable[0]['column'] == 1 else (
                            "giftcardlist.vendor" if orderable[0]['column'] == 2 else (
                                'giftcardlist.gift_card_no' if orderable[0]['column'] == 3 else (
                                    'giftcardlist.gift_card_pin' if orderable[0]['column'] == 4 else (
                                        'no_of_order' if orderable[0]['column'] == 5 else (
                                            'giftcardlist.balance' if orderable[0]['column'] == 6 else(
                                                'giftcardlist.gift_card_value' if orderable[0]['column'] == 7 else (
                                                    'max(giftcardlist.last_check)' if orderable[0]['column'] == 8 else (
                                                        'giftcardlist.status' if orderable[0]['column'] == 9 else ""
                                                         ))))))))]
                        direction = orderable[0]['dir']
                        # filter for status using upper dropdown
                        columns_status = columns[9]
                        # print('columns_status', columns_status)
                        columns_status_search = columns_status['search']['value']
                        # print(columns_status_search)
                        if columns_status_search == 'Status':
                            columns_status_search = ''
                        elif columns_status_search == 'All':
                            columns_status_search = ''

                        custom_filter = False
                        custom_searchbox, custom_queue_id, custom_status, custom_sorting, custom_direction = None, None, None, None, None
                        if columns_status_search != "":
                            custom_status = "[giftcardlist].[status] = '{}'".format(columns_status_search)
                        if queue_id != '':
                            custom_queue_id = "[giftcardlist].[queue_id] = '{}'".format(str(queue_id))
                        if len(sorting[0]) != 0:
                            custom_sorting = sorting[0]
                            custom_direction = direction
                        if len(searchbox) != 0:
                            custom_searchbox = searchbox

                        custom_filter = False
                        column_order_range = content['order_range']
                        # print("Order Range ", column_order_range)
                        column_balance_range = content['balance_range']
                        # print("Balance Range ", column_balance_range)
                        column_value_range = content['value_range']
                        #########################################################################################
                        custom_items = [column_order_range,column_balance_range,column_value_range]
                        # print(custom_items)
                        custom_filter = any(custom_items)

                        ################# PLANING ###########################
                        if custom_filter:
                            query_shorter = []
                            if len(column_order_range) != 0:
                                query_shorter.append("count([giftcardtransaction].[ordernumber]) BETWEEN '" + str(
                                    column_order_range[0]) + "' AND '" + str(column_order_range[1]) + "'")
                            if len(column_balance_range) != 0:
                                query_shorter.append("[giftcardlist].[balance] BETWEEN '" + str(
                                    column_balance_range[0]) + "' AND '" + str(column_balance_range[1]) + "'")
                            if len(column_value_range) != 0:
                                query_shorter.append("[giftcardlist].[gift_card_value] BETWEEN '" + str(
                                    column_value_range[0]) + "' AND '" + str(column_value_range[1]) + "'")

                            if len(query_shorter) == 0:
                                custom_query = ''
                            elif len(query_shorter) == 1:
                                custom_query = ''.join(query_shorter)
                            else:
                                custom_query = ' AND '.join(query_shorter)

                            sql = obj_queue.checkingqueuedetailcountwithhaving(custom_query, custom_queue_id, custom_status,
                                                                         custom_searchbox)
                            cursor.execute(sql)
                            # fetching buying details
                            count = cursor.fetchall()
                            # print("count", count)
                            try:
                                no_of_records = len(count)
                            except Exception as e:
                                no_of_records = count[0][0]
                            # print("no_of_records", no_of_records)

                            sql = obj_queue.checkingqueuedetailwithhaving(custom_query, offset, length, custom_queue_id,
                                                                    custom_status, custom_sorting, custom_direction, custom_searchbox)
                            # print(sql)
                            cursor.execute(sql)
                        else:
                            sql = obj_queue.checkingqueuedetailcountwithouthaving(custom_queue_id, custom_status,
                                                                            custom_searchbox)
                            print(sql)
                            cursor.execute(sql)
                            # fetching buying details
                            count = cursor.fetchall()
                            # print("count", count)
                            try:
                                no_of_records = len(count)
                            except Exception as e:
                                no_of_records = count[0][0]

                            # print("no_of_records", no_of_records)
                            sql = obj_queue.checkingqueuedetailwithouthaving(offset, length, custom_queue_id, custom_status,
                                                                       custom_sorting, custom_direction,
                                                                       custom_searchbox)
                            print(sql)
                            cursor.execute(sql)

                        # fetching checking queue data from the database
                        queue_data = cursor.fetchall()

                        checkingqueue_list = []
                        for checkingqueue in queue_data:
                            checkingqueue_dict = {
                                "vendor": checkingqueue.vendor,
                                "queue_id": checkingqueue.queue_id,
                                "status":checkingqueue.status,
                                "id": checkingqueue.id,
                                "giftcardno": checkingqueue.gift_card_no,
                                "giftcardpin": checkingqueue.gift_card_pin,
                                "queue_date": checkingqueue.queue_date,
                                "last_check":checkingqueue.last_used,
                                "no_of_order": checkingqueue.no_of_order,
                                "giftcardvalue": '{0:.2f}'.format(float(checkingqueue.gift_card_value)),
                                "balance": '{0:.2f}'.format(float(checkingqueue.balance))
                            }
                            checkingqueue_list.append(checkingqueue_dict)
                        responsedata = {
                            "draw": content['draw'],  # draw give pagination number i.e 1 or 2 or 3
                            "data": checkingqueue_list,
                            "recordsTotal": no_of_records,
                            "recordsFiltered": no_of_records
                        }
                        return jsonify(responsedata)
                    except Exception as e:
                        print(e)
                queue_id = request.args['id']
                # sql = "SELECT DISTINCT vendor FROM [dbo].[giftcardlist] where queue_status='que' AND queue_id = ?"
                # cursor.execute(sql, queue_id)
                # vendor_Data = cursor.fetchall()
                range_slider_data = {}
                sql = "SELECT MIN(balance) as min_balance, MAX(balance) as max_balance, MIN(gift_card_value) as min_value, MAX(gift_card_value) as max_value FROM [dbo].[giftcardlist] WHERE [giftcardlist].[queue_status]='que' AND queue_id = ?"
                cursor.execute(sql, queue_id)
                table_Data = cursor.fetchone()
                balance_slider, value_slider, order_slider = {}, {}, {}
                if None not in table_Data:
                    min_balance = int(table_Data.min_balance)
                    max_balance = int(table_Data.max_balance)
                    min_value = int(table_Data.min_value)
                    max_value = int(table_Data.max_value)
                    min_order_no = 0
                    max_order_no = 0

                    sql = "SELECT MAX(subtable.no_of_order) as max_order_no FROM (SELECT count(ordernumber) as no_of_order FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND queue_id = ? group by [giftcardlist].gift_card_no) subtable"
                    cursor.execute(sql, queue_id)
                    table_Data = cursor.fetchone()
                    if None not in table_Data:
                        max_order_no = int(table_Data.max_order_no)

                    min_balance = (0 if min_balance >= 0 else min_balance)
                    min_value = (0 if min_value >= 0 else min_value)
                    order_slider['min'] = min_order_no
                    order_slider['from'] = min_order_no
                    balance_slider['min'] = min_balance
                    balance_slider['from'] = min_balance
                    value_slider['min'] = min_value
                    value_slider['from'] = min_value
                    if max_balance == 0:
                        max_balance += 1

                    if max_order_no == 0:
                        max_order_no += 1

                    if max_value == 0:
                        max_value += 1

                    order_slider['max'] = max_order_no
                    order_slider['to'] = max_order_no
                    balance_slider['max'] = max_balance
                    balance_slider['to'] = max_balance
                    value_slider['max'] = max_value
                    value_slider['to'] = max_value
                    range_slider_data['balance_slider'] = balance_slider
                    range_slider_data['value_slider'] = value_slider
                    range_slider_data['order_slider'] = order_slider
                else:
                    balance_slider['min'], balance_slider['from'] = 0, 0
                    value_slider['min'], value_slider['from'] = 0, 0
                    order_slider['min'], order_slider['from'] = 0, 0
                    balance_slider['max'], balance_slider['to'] = 1, 1
                    value_slider['max'], value_slider['to'] = 1, 1
                    order_slider['max'], order_slider['to'] = 1, 1
                    range_slider_data['balance_slider'] = balance_slider
                    range_slider_data['value_slider'] = value_slider
                    range_slider_data['order_slider'] = order_slider
                return render_template('checkingqueuedetails.html',accessdata=accessdata, queue_id=queue_id, sliderdata=range_slider_data)
            else:
                return redirect(url_for('index'))
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('login'))


@app.route('/checkingqueuedetailselectall', methods=['GET', 'POST'])
def checkingqueuedetailselectall():
    try:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # print(request.json)
            queue_id = request.args['id']

            obj_queue = CheckingQueueDetailsClass()

            get_ids = request.json['get_ids']
            # print('get ids', get_ids)

            unSelectArr = request.json['unSelectArr']
            # print('unSelectArr', unSelectArr)

            if len(unSelectArr) == 1:
                unSelectArr.append('0')
            else:
                unSelectArr
            unSelectArr = tuple(unSelectArr)

            records = request.json['records']
            # print(records)

            statusValue = request.json['statusValue']
            # print(statusValue)
            columns_status_search = ("" if statusValue == "Status" else statusValue)

            ################## CUSTOM FILTER SECTION ##################
            custom_filter = False

            column_order_range = request.json['order_range']
            # print("Order Range ", column_order_range)
            column_balance_range = request.json['balance_range']
            print("Balance Range ", column_balance_range)
            # column_value_range = request.json['value_range']
            #########################################################################################
            custom_items = [column_order_range, column_balance_range, column_value_range]
            # print(custom_items)
            custom_filter = any(custom_items)
            # print(custom_filter)
            custom_queue_id, custom_status, custom_select_array = None, None, None
            if columns_status_search != "":
                custom_status = "[giftcardlist].[status] = '{}'".format(columns_status_search)
            if queue_id != '':
                custom_queue_id = "[giftcardlist].[queue_id] = '{}'".format(str(queue_id))
            if len(unSelectArr) != 0:
                custom_select_array = "giftcardlist.[id] NOT IN {}".format(
                        unSelectArr)
            if custom_filter:
                query_shorter = []
                if len(column_order_range) != 0:
                    query_shorter.append("count([giftcardtransaction].[ordernumber]) BETWEEN '" + str(
                        column_order_range[0]) + "' AND '" + str(column_order_range[1]) + "'")
                if len(column_balance_range) != 0:
                    query_shorter.append("[giftcardlist].[balance] BETWEEN '" + str(
                        column_balance_range[0]) + "' AND '" + str(column_balance_range[1]) + "'")
                if len(column_value_range) != 0:
                    query_shorter.append("[giftcardlist].[gift_card_value] BETWEEN '" + str(
                        column_value_range[0]) + "' AND '" + str(column_value_range[1]) + "'")

                if len(query_shorter) == 0:
                    custom_query = ''
                elif len(query_shorter) == 1:
                    custom_query = ''.join(query_shorter)
                else:
                    custom_query = ' AND '.join(query_shorter)

                sql = obj_queue.checkingqueuedetailselectallwithhaving(custom_query, custom_queue_id, custom_status,
                                                                   custom_select_array)
            else:
                sql = obj_queue.checkingqueuedetailselectallwithouthaving(custom_queue_id, custom_status,
                                                                      custom_select_array)

            if get_ids == True:
                checkboxesArray = []
                # getting id of the selected filters
                if len(unSelectArr) == 0:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
                else:
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    checkboxesArray = [datum[0] for datum in data]
            else:
                cursor.execute(sql)
                # fetching giftcardl
                batch_count = cursor.fetchall()
                no_of_records = len(batch_count)

            if get_ids == True:
                return json.dumps({"arr": checkboxesArray})
            else:
                return json.dumps({'total_record': no_of_records})

    except Exception as e:
        print(e)
        return json.dumps({"code": 400, "error": str(e)})
############### --------- END CHECKING QUEUE Page-------------  ########################

############### --------- Catalouge 1 Page -------------  ########################
@app.route('/catalogue', methods=['GET', 'POST'])
def catalog1():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        cursor.execute("SELECT [category] FROM [dbo].[buycatalogue] where category is not null group by [category] order by category")
        categories = cursor.fetchall()
        cursor.execute("SELECT [brand_name] FROM [dbo].[buycatalogue] where brand_name is not null group by [brand_name] order by brand_name")
        brand_name = cursor.fetchall()

        sql = "UPDATE [bestbuymaster].[dbo].[buycatalogue] SET profit=0, profit_amt=0 WHERE amazon_price=0 or buybox=0"
        cursor.execute(sql)
        cursor.commit()

        cursor = condb.cursor()
        sql = "SELECT count(slider) as count FROM [bestbuymaster].[dbo].[buycatalogue] where slider=1"
        cursor.execute(sql)
        slider_value = cursor.fetchone()[0]
        if slider_value != 0:
            cursor = condb.cursor()
            sql = "UPDATE [dbo].[buycatalogue] SET slider=1, profit=(CASE WHEN buybox>0 THEN round(((((buybox)+(-FBA_fee-sale_price-referal_fee))/sale_price)*100),2) else 0 END), profit_amt=(CASE WHEN buybox>0 THEN round(((buybox)+(-FBA_fee-sale_price-referal_fee)),2) else 0 END) WHERE buybox>0"
            cursor.execute(sql)
            cursor.commit()
            print(cursor.rowcount)
        else:
            cursor = condb.cursor()
            sql = "UPDATE [dbo].[buycatalogue] SET slider=0, profit=(CASE WHEN amazon_price>0 THEN round(((((amazon_price)+(-FBA_fee-sale_price-referal_fee))/sale_price)*100),2) else 0 END), profit_amt=(CASE WHEN amazon_price>0 THEN round(((amazon_price)+(-FBA_fee-sale_price-referal_fee)),2) else 0 END) WHERE amazon_price>0"
            cursor.execute(sql)
            cursor.commit()
            print(cursor.rowcount)

        range_slider_data = {}
        sql = "SELECT MAX(sale_price) as max_price, MAX(amazon_price) as max_amazon_price, MAX(FBA_fee) as max_fba_fee FROM [dbo].[buycatalogue]"
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        price_slider, amazon_slider, fba_slider = {}, {}, {}
        if None not in table_Data:
            min_price = 0
            min_amazon_price = 0
            min_fba_fee = 0
            max_price = int(table_Data.max_price)
            max_amazon_price = int(table_Data.max_amazon_price)
            max_fba_fee = int(table_Data.max_fba_fee)

            price_slider['min'] = min_price
            price_slider['from'] = min_price
            amazon_slider['min'] = min_amazon_price
            amazon_slider['from'] = min_amazon_price
            fba_slider['min'] = min_fba_fee
            fba_slider['from'] = min_fba_fee

            if max_price == 0:
                max_price += 1
            if max_amazon_price == 0:
                max_amazon_price += 1
            if max_fba_fee == 0:
                max_fba_fee += 1

            price_slider['max'] = max_price+1
            price_slider['to'] = max_price+1
            amazon_slider['max'] = max_amazon_price + 1
            amazon_slider['to'] = max_amazon_price + 1
            fba_slider['max'] = max_fba_fee + 1
            fba_slider['to'] = max_fba_fee + 1
            range_slider_data['price_slider'] = price_slider
            range_slider_data['amazon_slider'] = amazon_slider
            range_slider_data['fba_slider'] = fba_slider
        else:
            price_slider['min'], price_slider['from'] = 0, 0
            price_slider['max'], price_slider['to'] = 1, 1
            amazon_slider['min'], amazon_slider['from'] = 0, 0
            amazon_slider['max'], amazon_slider['to'] = 1, 1
            fba_slider['min'], fba_slider['from'] = 0, 0
            fba_slider['max'], fba_slider['to'] = 1, 1
            range_slider_data['price_slider'] = price_slider
            range_slider_data['amazon_slider'] = amazon_slider
            range_slider_data['fba_slider'] = fba_slider

        cursor = condb.cursor()
        cursor.execute(
            "SELECT parent_id, full_address from [dbo].[addressmaster] as a where id=parent_id and parent_id in (SELECT parent_id from [dbo].[addressmaster] where parent_id=a.parent_id and status='Active')")
        addressdata = cursor.fetchall()

        cursor.execute(
            "SELECT parent_id, email from [dbo].[emailmaster] as a where id=parent_id and parent_id in (SELECT parent_id from [dbo].[emailmaster] where parent_id=a.parent_id and status='Active')")
        emaildata = cursor.fetchall()

        available_balance, queue_balance = 0, 0
        sql = "SELECT sum([balance]) as giftcard_balance FROM [dbo].[giftcardlist] WHERE status='Balance' and balance>0 and (last_used <= DATEADD(day,-3, GETDATE()) or last_used is null)"
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        if table_Data:
            available_balance = table_Data.giftcard_balance if table_Data.giftcard_balance else 0
            available_balance = '{0:.2f}'.format(float(available_balance))

        sql = "SELECT sum(giftcardlist.[balance]) as queue_balance FROM [dbo].[giftcardlist] INNER JOIN [dbo].[giftcardtransaction] ON gift_card_no=giftcard_number WHERE status='Balance' and balance>0 and (last_used >= DATEADD(day,-3, GETDATE()) or last_used is null)"
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        if table_Data:
            queue_balance = table_Data.queue_balance if table_Data.queue_balance else 0
            queue_balance = '{0:.2f}'.format(float(queue_balance))
        giftcard_amount = {'available_balance': available_balance, 'queue_balance': queue_balance}

        return render_template('catalog_admin.html',accessdata=accessdata, categories=categories, brand=brand_name, sliderdata=range_slider_data,
                               addressdata=addressdata, emaildata=emaildata, giftcard_amount=giftcard_amount)
    else:
        return redirect(url_for('login'))

@app.route('/catalog-slider', methods=['PUT', 'POST'])
def catalog_slider():
    if request.method == "POST":
        cursor = condb.cursor()
        sql = "SELECT count(slider) as count FROM [bestbuymaster].[dbo].[buycatalogue] where slider=1"
        cursor.execute(sql)
        slider_value = cursor.fetchone()[0]
        if slider_value != 0:
            slider_value = True
        else:
            slider_value = False
        responsedata = {'data':slider_value}
        return jsonify(responsedata)
    elif request.method == "PUT":
        cursor = condb.cursor()
        content = request.json
        slider_value = content['slider_value']
        slider_value = 1 if slider_value else 0
        sql = "UPDATE [dbo].[buycatalogue] SET slider=?"
        cursor.execute(sql, slider_value)
        cursor.commit()
        if cursor.rowcount>0:
            responsedata = {'code': 200, 'data': cursor.rowcount}
            return jsonify(responsedata)
        else:
            responsedata = {'code': 404, 'data': cursor.rowcount}
            return jsonify(responsedata)

@app.route('/catalogue-category', methods=['GET', 'POST'])
def catalogue_category():
    if request.method == "POST":
        cursor = condb.cursor()
        content = request.json
        category = content['category']
        if category == 'category':
            category = ""
        sql = "SELECT [sub_category] FROM [dbo].[buycatalogue] where [category]=? and sub_category is not null group by [sub_category] order by sub_category"
        cursor.execute(sql, category)
        category = cursor.fetchall()
        category_list = []
        for cat in category:
            subcategory = cat.sub_category
            if subcategory not in category_list:
                category_list.append(subcategory)
        responsedata = {'data':category_list}
        return jsonify(responsedata)

@app.route('/cataloguedatatable', methods=['POST'])
def cataloguedatatable():
    try:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            obj_catalog = CatalogueBuy()
            # getting all json data from the datatable
            content = request.json
            # print(content)
            # get columns from the content(json data)
            columns = content['columns']

            # initially start show 0 & on click next it will increased accroding to defined rows in the table  (Display index for the first record shown on the current page)
            offset = content['start']
            # print(offset)
            # Display length (number of records) use --> used in fetch to get no of next records from the database
            length = content['length']

            # the search field for the datatables
            search = content['search']
            searchbox = search['value'].strip()
            searchbox = "{" if searchbox.startswith("'") else searchbox
            searchbox = "{" if searchbox.startswith("-") else searchbox
            searchbox = "{" if searchbox.startswith(";") else searchbox

            column_category = content['category']
            column_category = ("" if column_category == "category" else column_category)
            column_subcategory = content['subcategory']
            column_subcategory = ("" if column_subcategory == "subcategory" else column_subcategory)
            column_brand = content['brand']
            column_brand = ("" if column_brand == "Brand" else column_brand)
            column_profit = content['profit']
            column_profit = ("" if column_profit == "sort" else column_profit)
            column_stock = content['stock']
            column_stock = ("" if column_stock == "stock" else column_stock)

            column_price_range = content['price_range']

            column_amazon_price_range = content['amazon_price_range']

            column_fba_fee_range = content['fba_fee_range']

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            if column_category != "":
                column_category = column_category.replace("'", "''")
                query_shorter.append("[category] = '" + str(column_category) + "'")
            if column_subcategory != "":
                column_subcategory = column_subcategory.replace("'", "''")
                query_shorter.append("[sub_category] = '" + str(column_subcategory) + "'")
            if column_brand != "":
                column_brand = column_brand.replace("'", "''")
                query_shorter.append("[brand_name] = '" + str(column_brand) + "'")
            if len(searchbox) != 0:
                searchbox = searchbox.replace("'","''")
                search_keywords = searchbox.split(" ")
                keywords_list = []
                if len(search_keywords) >1:
                    for keywords in search_keywords:
                        keywords_list.append("[product_name] LIKE '%"+str(keywords)+"%'")
                    if len(keywords_list) == 1:
                        keyword = ''.join(keywords_list)
                        query_shorter.append(keyword)
                    else:
                        keyword = ' AND '.join(keywords_list)
                        query_shorter.append(keyword)
                else:
                    search_query = "([modal_no] LIKE '{}%' OR [product_name] LIKE '%{}%' OR [sku] LIKE '{}%' OR [upc] LIKE '{}%' OR [sale_price] LIKE '{}%' OR [brand_name] LIKE '{}%' OR CONVERT (varchar(10),[Date_creation],110) LIKE '{}%' OR [category] LIKE '{}%' OR [sub_category] LIKE '{}%')".format(
                        searchbox, searchbox, searchbox,
                        searchbox, searchbox, searchbox,
                        searchbox, searchbox, searchbox)
                    query_shorter.append(search_query)
            if len(column_price_range) != 0:
                query_shorter.append("sale_price BETWEEN '" + str(
                    column_price_range[0]) + "' AND '" + str(column_price_range[1]) + "'")
            if len(column_amazon_price_range) != 0:
                query_shorter.append("amazon_price BETWEEN '" + str(
                    column_amazon_price_range[0]) + "' AND '" + str(column_amazon_price_range[1]) + "'")
            if len(column_fba_fee_range) != 0:
                query_shorter.append("FBA_fee BETWEEN '" + str(
                    column_fba_fee_range[0]) + "' AND '" + str(column_fba_fee_range[1]) + "'")
            if column_stock != "":
                if column_stock == 'stockin':
                    query_shorter.append("[available] = 1")
                elif column_stock == 'stockout':
                    query_shorter.append("[available] = 0")
            if column_profit != "":
                if column_profit == 'profitup':
                    custom_sorting = 'profit'
                    custom_direction = 'DESC'
                elif column_profit == 'discountup':
                    custom_sorting = 'percentsave'
                    custom_direction = 'DESC'
                elif column_profit == 'savingup':
                    custom_sorting = 'dollersave'
                    custom_direction = 'DESC'
                elif column_profit == 'priceup':
                    custom_sorting = 'sale_price'
                    custom_direction = 'DESC'
                elif column_profit == 'pricedown':
                    custom_sorting = 'sale_price'
                    custom_direction = 'ASC'
                elif column_profit == 'rankup':
                    custom_sorting = 'amazon_sale_rank'
                    custom_direction = 'DESC'
                elif column_profit == 'rankdown':
                    custom_sorting = 'amazon_sale_rank'
                    custom_direction = 'ASC'
                elif column_profit == 'rankup':
                    custom_sorting = 'amazon_sale_rank'
                    custom_direction = 'DESC'
                elif column_profit == 'rankdown':
                    custom_sorting = 'amazon_sale_rank'
                    custom_direction = 'ASC'
                elif column_profit == 'amzpriceup':
                    custom_sorting = 'amazon_price'
                    custom_direction = 'DESC'
                # elif column_profit == 'profitdown':
                #     custom_sorting = 'profit'
                #     custom_direction = 'ASC'

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            sql = obj_catalog.cataloguecount(custom_query)
            # print(sql)
            cursor.execute(sql)
            count = cursor.fetchall()
            try:
                no_of_records = count[0][0]
            except Exception as e:
                no_of_records = len(count)

            sql = obj_catalog.cataloguedata(offset, length, custom_query, custom_sorting, custom_direction)
            print(sql)
            cursor.execute(sql)

            # fetching checking queue data from the database
            catalogue_data = cursor.fetchall()

            catalogue_list = []
            for catalog in catalogue_data:
                brand_name = ""
                if catalog.brand_name != "" or catalog.brand_name != None:
                    brand_name = str(catalog.brand_name).title()
                was_price = 0.0
                if catalog.was_price:
                    was_price = "{:.2f}".format(round(catalog.was_price, 2))
                sale_price = 0.0
                if catalog.sale_price:
                    sale_price = "{:.2f}".format(round(catalog.sale_price, 2))
                profit_amt = 0.0
                if catalog.profit_amt:
                    profit_amt = "{:.2f}".format(round(catalog.profit_amt, 2))
                watch_price = 0.0
                if catalog.watch_price:
                    watch_price = "{:.2f}".format(round(catalog.watch_price, 2))
                dollerSave = 0.0
                if catalog.dollersave:
                    dollerSave = "{:.2f}".format(round(catalog.dollersave, 2))
                percentSave = 0.0
                if catalog.percentsave:
                    percentSave = "{:.2f}".format(round(catalog.percentsave, 2))
                regularPrice = 0.0
                if catalog.regular_price:
                    regularPrice = "{:.2f}".format(round(catalog.regular_price, 2))
                longDesc = catalog.long_desc if catalog.long_desc else ""
                longDesc = longDesc.replace('\"','')
                catalog_dict = {
                    "Image": catalog.image_url if catalog.image_url else "",
                    "ModelNo": catalog.modal_no if catalog.modal_no else "",
                    "SKUID": catalog.sku if catalog.sku else "",
                    "UPC": catalog.upc if catalog.upc else "",
                    "SalePrice": sale_price,
                    "RegularPrice": regularPrice,
                    "WasPrice": was_price,
                    "WatchPrice": watch_price,
                    "ProductName": catalog.product_name if catalog.product_name else "",
                    "Available": catalog.available if catalog.available else "",
                    "BrandName": brand_name,
                    "ShortDesc": catalog.short_desc if catalog.short_desc else "",
                    "LongDesc": longDesc,
                    "FBAFee": "{:.2f}".format(round(catalog.FBA_fee, 2)) if catalog.FBA_fee else 'N/A',
                    'amazonPrice' : "{:.2f}".format(round(catalog.amazon_price, 2)) if catalog.amazon_price else 'N/A',
                    'referalFee' : "{:.2f}".format(round(catalog.referal_fee, 2)) if catalog.referal_fee else 'N/A',
                    "buyBoxPrice":"{:.2f}".format(round(catalog.buybox, 2)) if catalog.buybox else 'N/A',
                    "DollerSave": dollerSave,
                    "PercentSave": percentSave,
                    "Profit": profit_amt,
                    "ProfitPercent":catalog.profit,
                    "SiteUrl":catalog.url_info,
                    "ASIN":catalog.asin if catalog.asin else "N/A",
                    "AmazonSalesRank": catalog.amazon_sale_rank if catalog.amazon_sale_rank else "#N/A",
                    "AmazonPriceHistory": "{:.2f}".format(round(catalog.amazon_price_history, 2)) if catalog.amazon_price_history else 'N/A',
                    "AmazonSalesRankHistory": catalog.amazon_sale_rank_history if catalog.amazon_sale_rank_history else "#N/A",
                    "Id": catalog.id
                }
                catalogue_list.append(catalog_dict)
            # print(catalogue_list)
            responsedata = {
                "draw": content['draw'],  # draw give pagination number i.e 1 or 2 or 3
                "data": catalogue_list,
                "recordsTotal": no_of_records,
                "recordsFiltered": no_of_records
            }
            return jsonify(responsedata)
    except Exception as e:
        print(e)

@app.route('/catalogue-watchprice', methods=['GET','POST'])
def catalogue_watchprice():
    if 'password' and 'email' in session:
        global companyid
        cursor = condb.cursor()
        if request.method == "POST":
            id = request.form.get('price_id')
            price = request.form.get('price')
            sql = "UPDATE [dbo].[buycatalogue] SET watch_price=?, is_watching=? WHERE [id]=?"
            val = (price,1,id)
            cursor.execute(sql, val)
            cursor.commit()
            rowcount = cursor.rowcount
            sql = "SELECT sku, sale_price, amazon_price, FBA_fee, referal_fee FROM [dbo].[buycatalogue] WHERE id=?"
            cursor.execute(sql, id)
            sku_data = cursor.fetchone()
            if sku_data != None:
                sale_price_1 = sku_data[1]
                amazon_price_1 = sku_data[2]
                fba_fee_1 = sku_data[3]
                referal_fee_1 = sku_data[4]
                amazon_price_int = int(float(amazon_price_1))
                profit_amt, profit_percent = 0, 0
                if amazon_price_int != 0:
                    sale_price_profit_amt = float(sale_price_1) + float(referal_fee_1) + float(fba_fee_1)
                    profit_amt = round((float(amazon_price_1) - float(sale_price_profit_amt)),2)
                    profit_percent = round(((float(profit_amt) / float(sale_price_1))*100), 2)
                    sql = "UPDATE [dbo].[buycatalogue] SET profit=?, profit_amt=? WHERE id=?;"
                    val = [profit_percent, profit_amt, id]
                    cursor.execute(sql, val)
                    cursor.commit()
            responsedata = {}
            if rowcount>0:
                responsedata['code'] = 201
                responsedata['message'] = "Watch Price Updated"
            else:
                responsedata['code'] = 404
                responsedata['message'] = "Watch Price Not Updated"
            return jsonify(responsedata)

        id = request.args['id']
        sql = "SELECT watch_price, is_watching FROM [dbo].[buycatalogue] where [id]=?"
        cursor.execute(sql,id)
        watch_data = cursor.fetchone()
        responsedata = {}
        if watch_data:
            responsedata['watching'] = True if watch_data.is_watching else False
            responsedata['watch_price'] = watch_data.watch_price
            responsedata['price_id'] = id
        return jsonify(responsedata)

def referrerFeeAdapter(price, category):
    path = app.root_path
    file_name = os.path.join(path, 'base_data.json')
    price = float(price)
    with open(file_name) as f:
        fee_data = json.load(f)
        cat_list = [fee_data['referral_fee'][i]['category'] for i in range(len(fee_data['referral_fee']))]
        if re.search(category, ('|').join(cat_list), flags=re.IGNORECASE):
            pass
        else:
            if re.search("Home & Kitchen", category):
                category = "Kitchen"
            elif re.search("Cell Phones & Accessories", category):
                category = "Electronics Accessories"
            elif re.search("Electronics", category):
                category = "Consumer Electronics"
            elif re.search('Health & Household', category):
                category = "Health & Personal Care"
            elif re.search("Sports & Outdoors", category):
                category = "Sports (excluding Sports Collectibles)"
            elif re.search("Clothing, Shoes & Jewelry", category):
                category = "Clothing & Accessories"
            elif re.search("Movies & TV", category):
                category = "Video & DVD"
            # elif re.search("Clothing, Shoes & Jewelry", category):
            #     category = "Clothing & Accessories"
            # elif re.search("Clothing, Shoes & Jewelry", category):
            #     category = "Clothing & Accessories"
            else:
                category = "Everything Else"

        if category == '':
            category = "Everything Else"
        for i, item in enumerate(fee_data['referral_fee']):
            # if re.search(f"{category}", f"{item['category']}", flags=re.IGNORECASE):
            if category in item['category']:
                if item['Applicable minimum referral fee'] is None:
                    if item['Referral fee percentages']['type'] == 'normal':
                        return price * item['Referral fee percentages']['percent']
                    else:
                        for val_range in item['Referral fee percentages']['formulas']:
                            if val_range['range']['from'] <= price < 10 ** 6 if val_range['range']['to'] is None else \
                            val_range['range']['to']:
                                return price * val_range['percent']
                else:
                    if item['Referral fee percentages']['type'] == 'normal':
                        return max(item['Applicable minimum referral fee'],
                                   price * item['Referral fee percentages']['percent'])
                    else:
                        for val_range in item['Referral fee percentages']['formulas']:
                            if val_range['range']['from'] <= price < 10 ** 6 if val_range['range']['to'] is None else \
                            val_range['range']['to']:
                                return max(item['Applicable minimum referral fee'], price * val_range['percent'])

@app.route('/catalogcreatemodel', methods=['GET','POST', 'PUT'])
def catalogcreatemodel():
    if 'password' and 'email' in session:
        global companyid
        cursor = condb.cursor()
        if request.method == "POST":
            content = request.json
            cataloguedata = content['catalogue']
            cataloguelist = cataloguedata.split(",")
            catalogueListData = []
            for id in cataloguelist:
                if id != "":
                    sql = "SELECT id, [sku], [sale_price], [FBA_fee], [amazon_price], [buybox] FROM [dbo].[buycatalogue] WHERE id={0}".format(id)
                    cursor.execute(sql)
                    catalogue_data = cursor.fetchall()
                    catalogue_dict = {}
                    if len(catalogue_data) !=0 :
                        catalogue_dict['Id']='add-'+str(catalogue_data[0][0])
                        catalogue_dict['SKUID'] = catalogue_data[0][1]
                        sale_price = 0.0
                        price = catalogue_data[0][2]
                        if price != None:
                            sale_price = "{:.2f}".format(round(price, 2))
                        FBA_fee = 0.0
                        fee = catalogue_data[0][3]
                        if fee != None:
                            FBA_fee = "{:.2f}".format(round(fee, 2))
                        total_amt = float(sale_price) + float(FBA_fee)
                        total_amt = "{:.2f}".format(round(total_amt, 2))

                        amazon_price = catalogue_data[0][4]
                        amazon_price = "{:.2f}".format(round(amazon_price, 2))

                        buybox_price = catalogue_data[0][5]
                        buybox_price = "{:.2f}".format(round(buybox_price, 2))

                        catalogue_dict['SalePrice'] = sale_price
                        catalogue_dict['FBAFee'] = FBA_fee
                        catalogue_dict['TotalAmt'] = total_amt
                        catalogue_dict['AmazonPrice'] = amazon_price
                        catalogue_dict['BuyboxPrice'] = buybox_price
                        if catalogue_dict not in catalogueListData:
                            catalogueListData.append(catalogue_dict)
            return jsonify(catalogueListData)
        elif request.method == "GET":
            id = request.args['id']
            sql = "SELECT asin, referal_fee, FBA_fee, sale_price, amazon_price, buybox FROM [dbo].[buycatalogue] where [id]=?"
            cursor.execute(sql, id)
            popover_data = cursor.fetchone()
            responsedata = {}
            if popover_data:
                responsedata['amazonASIN'] = popover_data.asin if popover_data.asin else ""
                responsedata['referalFee'] = "{:.2f}".format(round(popover_data.referal_fee, 2))
                responsedata['fbaFee'] = "{:.2f}".format(round(popover_data.FBA_fee, 2))
                responsedata['saleprice'] = "{:.2f}".format(round(popover_data.sale_price, 2))
                responsedata['amazonprice'] = "{:.2f}".format(round(popover_data.amazon_price, 2))
                responsedata['buyboxprice'] = "{:.2f}".format(round(popover_data.buybox, 2))
                responsedata['popoverid'] = id
            return jsonify(responsedata)
        elif request.method == "PUT":
            import requests
            rowcount= 0
            id = request.form.get('price_id')
            amazon_asin = request.form.get('amazon_asin')
            amazonprice = request.form.get('amazonprice')
            amazon_asin = amazon_asin if amazon_asin else None
            if amazon_asin:
                amazon_asin = str(amazon_asin).strip()
                amazon_asin = str(amazon_asin).replace(" ","")

            sql = "SELECT amazon_price FROM [dbo].[buycatalogue] WHERE id=?"
            cursor.execute(sql, id)
            buying_data = cursor.fetchone()

            get_referrer_fees_by_amazon_price = None
            if buying_data:
                amazon_price_1 = int(float(buying_data.amazon_price))
                amazon_price_2 = int(float(amazonprice))
                if amazon_price_1 != amazon_price_2:
                    get_referrer_fees_by_amazon_price = True

            category, amazon_price, referrer_fee = "", 0, 0
            if amazon_asin != "":
                url = "http://35.238.237.64/details?asin=https://www.amazon.com/dp/{0}/".format(amazon_asin)
                try:
                    amazon_data = requests.get(url).json()
                except Exception as e:
                    print(e)
                    amazon_data = {}
                    amazon_price = amazonprice
                if 'Category' in amazon_data:
                    category = amazon_data['Category']
                if 'Deal_Price' in amazon_data:
                    amazon_price = amazon_data['Deal_Price']
                elif 'Amazon_Price' in amazon_data:
                    amazon_price = amazon_data['Amazon_Price']
                elif 'BuyBox_Price' in amazon_data:
                    amazon_price = amazon_data['BuyBox_Price']
                elif 'List_Price' in amazon_data:
                    amazon_price = amazon_data['List_Price']
                if amazon_price != 'Not Available' or amazon_price != None:
                    amazon_price = amazon_price.replace("\n", ".")
                    amazon_price = amazon_price.replace("$", "")
                    try:
                        amazon_price = round(float(amazon_price), 2)
                    except:
                        amazon_price = amazonprice
                else:
                    amazon_price = amazonprice
                referrer_fee = referrerFeeAdapter(amazon_price,category)
                amazonprice = amazon_price
            if get_referrer_fees_by_amazon_price:
                referrer_fee = referrerFeeAdapter(amazonprice,'')

            sql = "UPDATE [dbo].[buycatalogue] SET asin=?, amazon_price=?, referal_fee=? WHERE [id]=?"
            val = (amazon_asin, amazonprice, referrer_fee, id)
            cursor.execute(sql, val)
            cursor.commit()
            rowcount = cursor.rowcount
            sql = "SELECT sale_price, amazon_price, FBA_fee, referal_fee FROM [dbo].[buycatalogue] WHERE id=?"
            cursor.execute(sql, id)
            sku_data = cursor.fetchone()
            if sku_data != None:
                sale_price_1 = sku_data.sale_price
                amazon_price = sku_data.amazon_price
                fab_fee = sku_data.FBA_fee
                referal_fee = sku_data.referal_fee
                amazon_price_int = int(float(amazon_price))
                profit_amt, profit_percent = 0, 0
                if amazon_price_int != 0:
                    profit_amt = (float(amazon_price) + float(fab_fee) + float(referal_fee)) - float(sale_price_1)
                    profit_amt = round(profit_amt, 2)
                    profit_percent = round((float(profit_amt) * 100 / float(sale_price_1)), 2)
                    sql = "UPDATE [dbo].[buycatalogue] SET profit=?, profit_amt=? WHERE id=?;"
                    val = [profit_percent, profit_amt, id]
                    cursor.execute(sql, val)
                    cursor.commit()
            responsedata = {}
            if rowcount > 0:
                responsedata['code'] = 201
                responsedata['message'] = "Price Variation Updated"
            else:
                responsedata['code'] = 404
                responsedata['message'] = "Price Variation Not Updated"
            return jsonify(responsedata)

#####################################################################################################
@app.route('/watchlist', methods=['GET', 'POST', 'DELETE'])
def watchlist_admin():
    if 'password' and 'email' in session:
        if request.method == "POST":
            import datetime

            # initializing cursor
            cursor = condb.cursor()
            obj_watchlist = WatchListCatalogue()
            # getting all json data from the datatable
            content = request.json
            # print(content)
            # get columns from the content(json data)
            columns = content['columns']

            # initially start show 0 & on click next it will increased accroding to defined rows in the table  (Display index for the first record shown on the current page)
            offset = content['start']
            # print(offset)
            # Display length (number of records) use --> used in fetch to get no of next records from the database
            length = content['length']

            sql = obj_watchlist.watchlistcount()
            # print(sql)
            cursor.execute(sql)
            count = cursor.fetchall()
            try:
                no_of_records = count[0][0]
            except Exception as e:
                no_of_records = len(count)

            sql = obj_watchlist.watchlistdata(offset, length)
            # print(sql)
            cursor.execute(sql)

            # fetching checking queue data from the database
            catalogue_data = cursor.fetchall()

            catalogue_list = []
            for catalog in catalogue_data:
                brand_name = ""
                if catalog.brand_name != "" or catalog.brand_name != None:
                    brand_name = str(catalog.brand_name).title()
                was_price = 0.0
                if catalog.was_price:
                    was_price = "{:.2f}".format(round(catalog.was_price, 2))
                sale_price = 0.0
                if catalog.sale_price:
                    sale_price = "{:.2f}".format(round(catalog.sale_price, 2))
                profit_amt = 0.0
                if catalog.profit_amt:
                    profit_amt = "{:.2f}".format(round(catalog.profit_amt, 2))
                watch_price = 0.0
                if catalog.watch_price:
                    watch_price = "{:.2f}".format(round(catalog.watch_price, 2))
                dollerSave = 0.0
                if catalog.dollersave:
                    dollerSave = "{:.2f}".format(round(catalog.dollersave, 2))
                percentSave = 0.0
                if catalog.percentsave:
                    percentSave = "{:.2f}".format(round(catalog.percentsave, 2))
                regularPrice = 0.0
                if catalog.regular_price:
                    regularPrice = "{:.2f}".format(round(catalog.regular_price, 2))
                catalog_dict = {
                    "Image": catalog.image_url if catalog.image_url else "",
                    "ModelNo": catalog.modal_no if catalog.modal_no else "",
                    "SKUID": catalog.sku if catalog.sku else "",
                    "UPC": catalog.upc if catalog.upc else "",
                    "SalePrice": sale_price,
                    "RegularPrice": regularPrice,
                    "WasPrice": was_price,
                    "WatchPrice": watch_price,
                    "ProductName": catalog.product_name if catalog.product_name else "",
                    "Available": catalog.available if catalog.available else "",
                    "BrandName": brand_name,
                    "ShortDesc": catalog.short_desc if catalog.short_desc else "",
                    "LongDesc": catalog.long_desc if catalog.long_desc else "",
                    "FBAFee": "{:.2f}".format(round(catalog.FBA_fee, 2)) if catalog.FBA_fee else 'N/A',
                    'amazonPrice' : "{:.2f}".format(round(catalog.amazon_price, 2)) if catalog.amazon_price else 'N/A',
                    'referalFee' : "{:.2f}".format(round(catalog.referal_fee, 2)) if catalog.referal_fee else 'N/A',
                    "buyBoxPrice": "{:.2f}".format(round(catalog.buybox, 2)) if catalog.buybox else 'N/A',
                    "DollerSave": dollerSave,
                    "PercentSave": percentSave,
                    "Profit": profit_amt,
                    "ProfitPercent": catalog.profit,
                    "SiteUrl": catalog.url_info,
                    "ASIN": catalog.asin if catalog.asin else "N/A",
                    "AmazonSalesRank": catalog.amazon_sale_rank if catalog.amazon_sale_rank else "#N/A",
                    "AmazonPriceHistory": "{:.2f}".format(round(catalog.amazon_price_history, 2)) if catalog.amazon_price_history else 'N/A',
                    "AmazonSalesRankHistory": catalog.amazon_sale_rank_history if catalog.amazon_sale_rank_history else "#N/A",
                    "Id": catalog.id
                }
                catalogue_list.append(catalog_dict)
            # print(catalogue_list)
            responsedata = {
                "draw": content['draw'],  # draw give pagination number i.e 1 or 2 or 3
                "data": catalogue_list,
                "recordsTotal": no_of_records,
                "recordsFiltered": no_of_records
            }
            return jsonify(responsedata)
        elif request.method == 'DELETE':
            id = request.args['id']
            id = id.replace('remove-','')
            cursor = condb.cursor()
            sql = "UPDATE [dbo].[buycatalogue] SET watch_price=?, is_watching=? WHERE [id]=?"
            val = (0, 0, id)
            cursor.execute(sql, val)
            cursor.commit()
            status = cursor.rowcount
            responsedata = {'code':404, 'message':'Information not available.'}
            if status>0:
                responsedata = {'code': 200, 'message': 'Removed.'}
                return jsonify(responsedata)
            return jsonify(responsedata)
        elif request.method == 'GET':
            global companyid
            companyid = session["companyid"]
            cursor = condb.cursor()
            cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
            accessdata = cursor.fetchall()
            cursor = condb.cursor()
            cursor.execute(
                "SELECT parent_id, full_address from [dbo].[addressmaster] as a where id=parent_id and parent_id in (SELECT parent_id from [dbo].[addressmaster] where parent_id=a.parent_id and status='Active')")
            addressdata = cursor.fetchall()

            cursor.execute(
                "SELECT parent_id, email from [dbo].[emailmaster] as a where id=parent_id and parent_id in (SELECT parent_id from [dbo].[emailmaster] where parent_id=a.parent_id and status='Active')")
            emaildata = cursor.fetchall()

            available_balance, queue_balance = 0, 0
            sql = "SELECT sum([balance]) as giftcard_balance FROM [dbo].[giftcardlist] WHERE status='Balance' and balance>0 and (last_used <= DATEADD(day,-3, GETDATE()) or last_used is null)"
            cursor.execute(sql)
            table_Data = cursor.fetchone()
            if table_Data:
                available_balance = table_Data.giftcard_balance if table_Data.giftcard_balance else 0
                available_balance = '{0:.2f}'.format(float(available_balance))

            sql = "SELECT sum(giftcardlist.[balance]) as queue_balance FROM [dbo].[giftcardlist] INNER JOIN [dbo].[giftcardtransaction] ON gift_card_no=giftcard_number WHERE status='Balance' and balance>0 and (last_used >= DATEADD(day,-3, GETDATE()) or last_used is null)"
            cursor.execute(sql)
            table_Data = cursor.fetchone()
            if table_Data:
                queue_balance = table_Data.queue_balance if table_Data.queue_balance else 0
                queue_balance = '{0:.2f}'.format(float(queue_balance))
            giftcard_amount = {'available_balance': available_balance, 'queue_balance': queue_balance}

            return render_template('watchlist_admin.html',accessdata=accessdata, addressdata=addressdata, emaildata=emaildata, giftcard_amount=giftcard_amount)

############### --------- END Catalouge 1 Page -------------  ########################

#################### ----------- Ledger Page ----------- ############################

@app.route('/ledger', methods=['GET', 'POST', 'DELETE', 'PUT'])
def ledger():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        if len(accessdata) != 0:
            if accessdata[0].giftcard == 1:
                if request.method == "POST":
                    import datetime
                    # initializing cursor
                    cursor = condb.cursor()
                    id = request.args['id']
                    # getting all json data from the datatable
                    content = request.json
                    # print(content)
                    # get columns from the content(json data)
                    columns = content['columns']

                    # initially start show 0 & on click next it will increased accroding to defined rows in the table  (Display index for the first record shown on the current page)
                    offset = content['start']
                    # print(offset)
                    # Display length (number of records) use --> used in fetch to get no of next records from the database
                    length = content['length']

                    sql = "SELECT count(id) as count FROM [dbo].[giftcardtransaction] WHERE giftcard_number = {0}".format(id)
                    # print(sql)
                    cursor.execute(sql)
                    count = cursor.fetchall()
                    try:
                        no_of_records = count[0][0]
                    except Exception as e:
                        no_of_records = len(count)

                    # sql = obj_watchlist.watchlistdata(offset, length)
                    sql = "SELECT id, CONVERT(varchar(10), Date_creation,110) as date_creation, gc_balance, gift_card_value, giftcard_number, ordernumber, order_purchase_status, giftcard_status, action, action_type, amount FROM [dbo].[giftcardtransaction] WHERE giftcard_number = {0} ORDER BY Date_creation DESC OFFSET {1} ROWS FETCH NEXT {2} ROWS ONLY".format(id, offset, length)
                    print(sql)
                    cursor.execute(sql)

                    # fetching checking queue data from the database
                    ledger_data = cursor.fetchall()

                    ledger_list = []
                    for ledger in ledger_data:
                        if ledger.action_type is None:
                            current_balance = round((float(ledger.gc_balance) - float(ledger.amount)),2)
                            amount = - round(float(ledger.amount),2)
                        else:
                            current_balance = round(float(ledger.gc_balance),2)
                            amount = round(float(ledger.amount),2)
                        ledger_dict = {
                            'Id':ledger.id,
                            'Date_creation':ledger.date_creation,
                            'Current_amount': '{0:.2f}'.format(float(current_balance)),
                            'OrderNo': ledger.ordernumber,
                            'OrderStatus': ledger.order_purchase_status,
                            'GiftCardStatus': ledger.giftcard_status,
                            'GiftCardAction': ledger.action,
                            'ActionType': ledger.action_type,
                            'Amount': '{0:.2f}'.format(float(amount)),
                        }
                        ledger_list.append(ledger_dict)
                    print(ledger_list)
                    responsedata = {
                        "draw": content['draw'],  # draw give pagination number i.e 1 or 2 or 3
                        "data": ledger_list,
                        "recordsTotal": no_of_records,
                        "recordsFiltered": no_of_records
                    }
                    return jsonify(responsedata)
                elif request.method == "GET":
                    gc_no = request.args['gc']

                    cursor = condb.cursor()
                    sql = "SELECT id, gift_card_no, vendor, amount_paid, gift_card_value, discount, balance, CONVERT (varchar(10),date_of_purchase ,110) 'date_of_purchase', DATEDIFF(minute,date_of_purchase,GETDATE()) as minutes, DATEDIFF(hour,date_of_purchase,GETDATE()) as hours, DATEDIFF(day,date_of_purchase,GETDATE()) as days, status FROM [dbo].[giftcardlist] WHERE gift_card_no='{0}'".format(gc_no)
                    cursor.execute(sql)
                    gc_data = cursor.fetchone()
                    response_data = {'gc_num':'','vendor':'','cost':0,'value':0,'discount':0,'balance':0,'dop':'','current_time':'','status':'','id':''}
                    if gc_data:
                        current_time = ""
                        if gc_data.days != 0:
                            if gc_data.days == 1:
                                current_time = str(gc_data.days) + " day"
                            else:
                                current_time = str(gc_data.days) + " days"
                        elif gc_data.hours != 0:
                            if gc_data.hours == 1:
                                current_time = str(gc_data.hours) + " hour"
                            else:
                                current_time = str(gc_data.hours) + " hours"
                        elif gc_data.minutes != 0:
                            if gc_data.minutes == 1:
                                current_time = str(gc_data.minutes) + " minute"
                            else:
                                current_time = str(gc_data.minutes) + " minutes"
                        else:
                            current_time = "New"
                        cost = gc_data.amount_paid
                        value = gc_data.gift_card_value
                        discount = float(((value-cost)*100)/value)
                        discount = float(round(discount, 2))
                        response_data = {'gc_num': str(gc_data.gift_card_no),
                                         'vendor': gc_data.vendor,
                                         'cost': '{0:.2f}'.format(float(gc_data.amount_paid)),
                                         'value': '{0:.2f}'.format(float(gc_data.gift_card_value)),
                                         'discount': '{0:.2f}'.format(float(discount)),
                                         'balance': '{0:.2f}'.format(float(gc_data.balance)),
                                         'current_time':current_time,
                                         'dop': gc_data.date_of_purchase,
                                         'status': gc_data.status,
                                         'id': gc_data.id}

                    return render_template('ledger.html',accessdata=accessdata, gc_data=response_data, data=gc_no)
                elif request.method == "PUT":
                    import datetime
                    cursor = condb.cursor()
                    id = request.json['id']
                    sql = "UPDATE [dbo].[giftcardtransaction] SET check_balance=?, Date_modify=? WHERE [id] = ?"
                    val = [1, datetime.datetime.now(), id]
                    cursor.execute(sql, val)
                    cursor.commit()
                    if cursor.rowcount >0:
                        return jsonify({"code": 201, "message": "Check Balance will update soon."})
                    return jsonify({"code": 404, "message": "The items are not available."})
                elif request.method == "DELETE":
                    cursor = condb.cursor()
                    id = request.args['id']
                    sql = "DELETE FROM [dbo].[giftcardtransaction] WHERE [id] = ?"
                    cursor.execute(sql, id)
                    cursor.commit()
                    if cursor.rowcount > 0:
                        return jsonify({"code": 201, "message": "Deleted."})
                    return jsonify({"code": 404, "message": "The items are not available."})
            else:
                return redirect(url_for('index'))
        else:
            return redirect(url_for('index'))
    else:
        return redirect(url_for('login'))

#################### ----------- END Ledger Page ----------- #########################

#################### ----------- Settings Page ----------- ############################

@app.route('/setting', methods=['GET', 'PUT'])
def setting():
    if 'password' and 'email' in session:
        global companyid
        companyid = session["companyid"]
        cursor = condb.cursor()
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        if len(accessdata) != 0:
            if request.method == "PUT":
                form_data = request.form
                non_cancelled_order = form_data.get('non_cancelled_order')
                input_status = form_data.get('input_status')
                cancelled_order = form_data.get('cancelled_order')
                auto_pause_cancellation = form_data.get('auto_pause_cancellation')
                auto_pause_cancellation_rate = form_data.get('auto_pause_cancellation_rate')
                cursor = condb.cursor()
                cursor.execute(
                    "SELECT id FROM [dbo].[settings]")
                table_data = cursor.fetchone()
                print(form_data)
                if table_data is not None:
                    id = table_data.id
                    if auto_pause_cancellation_rate is not None:
                        sql = "UPDATE [dbo].[settings] SET cancellation_rate=?, Date_modify=? WHERE id=?"
                        val = (auto_pause_cancellation_rate, datetime.now(), id)
                        cursor.execute(sql,val)
                        cursor.commit()
                    if auto_pause_cancellation is not None:
                        sql = "UPDATE [dbo].[settings] SET cancellation=?, Date_modify=? WHERE id=?"
                        val = (auto_pause_cancellation, datetime.now(), id)
                        cursor.execute(sql,val)
                        cursor.commit()
                    if cancelled_order is not None:
                        sql = "UPDATE [dbo].[settings] SET cancelled_order=?, Date_modify=? WHERE id=?"
                        val = (cancelled_order, datetime.now(), id)
                        cursor.execute(sql,val)
                        cursor.commit()
                    if input_status is not None:
                        sql = "UPDATE [dbo].[settings] SET status=?, Date_modify=? WHERE id=?"
                        val = (input_status, datetime.now(), id)
                        cursor.execute(sql,val)
                        cursor.commit()
                    if non_cancelled_order is not None:
                        sql = "UPDATE [dbo].[settings] SET non_cancelled_order=?, Date_modify=? WHERE id=?"
                        val = (non_cancelled_order, datetime.now(), id)
                        cursor.execute(sql,val)
                        cursor.commit()
                else:
                    non_cancelled_order = int(non_cancelled_order) if non_cancelled_order else 0
                    input_status = input_status if input_status else None
                    cancelled_order = int(cancelled_order) if cancelled_order else 0
                    auto_pause_cancellation = float(auto_pause_cancellation) if auto_pause_cancellation else 0
                    auto_pause_cancellation_rate = float(auto_pause_cancellation_rate) if auto_pause_cancellation_rate else 0
                    sql = "INSERT INTO [dbo].[settings] (user_id, company_id, cancellation_rate, cancellation, non_cancelled_order, cancelled_order, status, Date_creation) VALUES (?,?,?,?,?,?,?,?)"
                    val = [1,1,auto_pause_cancellation_rate, auto_pause_cancellation, non_cancelled_order, cancelled_order, input_status, datetime.now()]
                    cursor.execute(sql, val)
                    cursor.commit()
                if cursor.rowcount >0:
                    return jsonify({"code": 201, "success": True})
                else:
                    return jsonify({"code": 404, "success": False})
            cursor.execute("SELECT cancellation_rate, cancellation, non_cancelled_order, cancelled_order, status FROM [dbo].[settings]")
            table_data = cursor.fetchone()
            settings_data = {'cancellation_rate':"", 'cancellation':"", 'non_cancelled_order':"", 'cancelled_order':"", 'status':""}
            if table_data:
                settings_data['cancellation_rate'] = table_data.cancellation_rate
                settings_data['cancellation'] = table_data.cancellation
                settings_data['non_cancelled_order'] = table_data.non_cancelled_order
                settings_data['cancelled_order'] = table_data.cancelled_order
                settings_data['status'] = table_data.status if table_data.status else ""
            return render_template('setting.html',accessdata=accessdata, settings_data=settings_data)
        else:
            return redirect(url_for('login'))
    else:
        return redirect(url_for('login'))

#################### ----------- END Settings Page ----------- ############################

#################### ----------- User - Profile Page ----------- ############################
@app.route('/users', methods=['GET', 'POST', 'PUT', 'DELETE'])
def users():
    global companyid
    companyid = session["companyid"]
    cursor = condb.cursor()
    if 'password' and 'email' in session:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # getting all json data from the datatable
            content = request.json
            # get columns from the content(json data)
            columns = content['columns']

            # initially start show 0 & on click next it will increased accroding to defined rows in the table  (Display index for the first record shown on the current page)
            offset = content['start']
            # Display length (number of records) use --> used in fetch to get no of next records from the database
            length = content['length']

            sql = "SELECT count(id) as count FROM [dbo].[usermaster]"
            print(sql)
            cursor.execute(sql)
            count = cursor.fetchall()
            try:
                no_of_records = count[0][0]
            except Exception as e:
                no_of_records = len(count)

            sql = "SELECT id, CONVERT(varchar(10), Date_creation,110) as date_creation, contactname, email, status FROM [dbo].[usermaster] ORDER BY Date_creation DESC OFFSET {0} ROWS FETCH NEXT {1} ROWS ONLY".format(
                 offset, length)
            print(sql)
            cursor.execute(sql)

            # fetching checking queue data from the database
            user_data = cursor.fetchall()

            user_list = []
            for data in user_data:
                status = userstatus(data.status)
                user_dict = {
                    'Id': data.id,
                    'Date_creation': data.date_creation,
                    'Name': data.contactname,
                    'Email': data.email,
                    'Status': status,
                    'Pos': 0,
                    'Total_paid': 0
                }
                user_list.append(user_dict)
            print(user_list)
            responsedata = {
                "draw": content['draw'],  # draw give pagination number i.e 1 or 2 or 3
                "data": user_list,
                "recordsTotal": no_of_records,
                "recordsFiltered": no_of_records
            }
            return jsonify(responsedata)
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        return render_template('users.html',accessdata=accessdata)
    else:
        data['code'] = 400
        data['message'] = "You are not authorised user."
        return json.dumps(data)

def userstatus(status):
    try:
        status = int(status)
        if status == 0:
            return 'Pending'
        elif status == 1:
            return 'Activate'
        elif status == 2:
            return 'Deactivate'
    except:
        if status == 'Pending':
            return 0
        elif status == 'Activate':
            return 1
        elif status == 'Deactivate':
            return 2

@app.route('/edituser', methods=['GET','POST','PUT','DELETE'])
def edituser():
    data = {}
    try:
        if 'password' and 'email' in session:
            companyid = session["companyid"]
            cursor = condb.cursor()
            cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
            accessdata = cursor.fetchall()
            if request.method == 'GET':
                user_id = request.args['id']
                sql = "SELECT * FROM [dbo].[usermaster] WHERE id={0}".format(user_id)
                cursor.execute(sql)
                user_data = cursor.fetchone()
                if user_data:
                    data['code'] = 200
                    data['Id'] = user_id
                    data['Email'] = user_data.email
                    data['Password'] = user_data.password
                    data['Name'] = user_data.businessname
                    data['CompanyName'] = user_data.contactname
                    data['Address1'] = user_data.address1
                    data['Address2'] = user_data.address2
                    data['City'] = user_data.city
                    data['State'] = user_data.state
                    data['Zip'] = user_data.zip
                    return json.dumps(data)
                else:
                    data['code'] = 404
                    data['message'] = "The user information is not matched."
                    return json.dumps(data)
            elif request.method == 'POST':
                userid = request.form.get('userinfo')
                company_name = request.form.get('cmpname')
                name = request.form.get('uname')
                address1 = request.form.get('address1')
                address2 = request.form.get('address2')
                city = request.form.get('city')
                state = request.form.get('state')
                zip = request.form.get('zip')
                new_pass = request.form.get('user_new_pass')
                sql = "UPDATE [dbo].[usermaster] SET businessname=?, contactname=?, address1=?, address2=?, city=?, state=?, zip=?, Date_modify=? WHERE id=?"
                val = (name, company_name, address1, address2, city, state, zip, datetime.now(), userid)
                cursor.execute(sql, val)
                cursor.commit()
                if new_pass != "":
                    sql = "UPDATE [dbo].[usermaster] SET password=?, Date_modify=? WHERE id=?"
                    val = (new_pass, datetime.now(), userid)
                    cursor.execute(sql, val)
                    cursor.commit()
                    flash('User password updated.')

                flash('User information updated.')
                data['code'] = 201
                return redirect(url_for('users'))
            elif request.method == 'PUT':
                user_data = request.json
                userid = user_data['id']
                status = user_data['newValue']
                status = userstatus(status)
                # print(user_data)
                sql = "UPDATE [dbo].[usermaster] SET status=?, Date_modify=? WHERE id=?"
                val = (status, datetime.now(), userid)
                cursor.execute(sql, val)
                cursor.commit()
                rowcount = cursor.rowcount
                if rowcount >0:
                    data['code'] = 200
                    data['message'] = "Status Updated"
                else:
                    data['message'] = "Not Updated"
                return json.dumps(data)
            elif request.method == 'DELETE':
                user_data = request.json
                userid = int(user_data['row_num'])
                if userid == companyid:
                    data['code'] = 400
                    return json.dumps(data)
                sql = "SELECT count(A.user_id) as user_used FROM [dbo].[emailmaster] AS A FULL OUTER JOIN [dbo].[addressmaster] AS B ON A.user_id = B.user_id FULL OUTER JOIN [dbo].[buyingmaster] AS C ON A.user_id = C.user_id WHERE A.user_id={0}".format(userid)
                cursor.execute(sql)
                user_existance = cursor.fetchone()
                if user_existance:
                    if user_existance.user_used > 0:
                        data['code'] = 400
                        return json.dumps(data)
                    else:
                        sql = "DELETE FROM [dbo].[usermaster] WHERE id={0}".format(userid)
                        cursor.execute(sql)
                        cursor.commit()
                        if cursor.rowcount > 0:
                            data['code'] = 200
                            return json.dumps(data)
                        else:
                            data['code'] = 400
                            return json.dumps(data)
        else:
            data['code'] = 400
            data['message'] = "You are not authorised user."
            return json.dumps(data)
    except Exception as e:
        print(e)
        data['code'] = 400
        data['message'] = str(e)
        return json.dumps(data)

@app.route('/editpermission', methods=['GET','POST','PUT'])
def editpermission():
    data = {}
    try:
        if 'password' and 'email' in session:
            companyid = session["companyid"]
            cursor = condb.cursor()
            cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
            accessdata = cursor.fetchall()
            if request.method == 'GET':
                user_id = request.args['id']
                sql = "SELECT * FROM [dbo].[usermaster] WHERE id={0}".format(user_id)
                cursor.execute(sql)
                user_data = cursor.fetchone()
                if user_data:
                    data['code'] = 200
                    data['Id'] = user_id
                    data['Email'] = user_data.email
                    data['Password'] = user_data.password
                    data['Name'] = user_data.businessname
                    data['CompanyName'] = user_data.contactname
                    data['Address1'] = user_data.address1
                    data['Address2'] = user_data.address2
                    data['City'] = user_data.city
                    data['State'] = user_data.state
                    data['Zip'] = user_data.zip
                    return json.dumps(data)
                else:
                    data['code'] = 404
                    data['message'] = "The user information is not matched."
                    return json.dumps(data)
            elif request.method == 'POST':
                userid = request.form.get('userinfo')
                company_name = request.form.get('cmpname')
                name = request.form.get('uname')
                address1 = request.form.get('address1')
                address2 = request.form.get('address2')
                city = request.form.get('city')
                state = request.form.get('state')
                zip = request.form.get('zip')
                new_pass = request.form.get('user_new_pass')
                sql = "UPDATE [dbo].[usermaster] SET businessname=?, contactname=?, address1=?, address2=?, city=?, state=?, zip=?, Date_modify=? WHERE id=?"
                val = (name, company_name, address1, address2, city, state, zip, datetime.now(), userid)
                cursor.execute(sql, val)
                cursor.commit()
                if new_pass != "":
                    sql = "UPDATE [dbo].[usermaster] SET password=?, Date_modify=? WHERE id=?"
                    val = (new_pass, datetime.now(), userid)
                    cursor.execute(sql, val)
                    cursor.commit()
                    flash('User password updated.')

                flash('User information updated.')
                data['code'] = 201
                return redirect(url_for('users'))
            elif request.method == 'PUT':
                user_data = request.json
                userid = user_data['id']
                status = user_data['newValue']
                status = userstatus(status)
                # print(user_data)
                sql = "UPDATE [dbo].[usermaster] SET status=?, Date_modify=? WHERE id=?"
                val = (status, datetime.now(), userid)
                cursor.execute(sql, val)
                cursor.commit()
                rowcount = cursor.rowcount
                if rowcount > 0:
                    data['code'] = 200
                    data['message'] = "Status Updated"
                else:
                    data['message'] = "Not Updated"
                return json.dumps(data)
        else:
            data['code'] = 400
            data['message'] = "You are not authorised user."
            return json.dumps(data)
    except Exception as e:
        print(e)
        data['code'] = 400
        data['message'] = str(e)
        return json.dumps(data)

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    global companyid
    companyid = session["companyid"]
    cursor = condb.cursor()
    if 'password' and 'email' in session:
        if request.method == "POST":
            user_data = request.form
            email = user_data.get('email')
            password = user_data.get('user_pass')
            name = user_data.get('uname')
            cname = user_data.get('cmpname')
            address1 = user_data.get('address1')
            address2 = user_data.get('address2')
            city = user_data.get('city')
            state = user_data.get('state')
            zip = user_data.get('zip')
            user_type = 2
            user_status = 0
            role = 0
            sql = "INSERT INTO [dbo].[usermaster] (businessname, contactname, email, password, accessid, companyid, role, status, address1, address2, city, state, zip, Date_creation) OUTPUT INSERTED.ID VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);"
            val = (name, cname, email, password, user_type, companyid, role, user_status, address1, address2, city, state, zip, datetime.now())
            cursor.execute(sql, val)
            user_inserted_id = cursor.fetchone()[0]
            # print(user_inserted_id)
            cursor.commit()
            sql = "INSERT INTO [dbo].[accessmaster] (userid, companyid, Date_creation) VALUES (?,?,?);"
            val = (user_inserted_id, companyid, datetime.now())
            cursor.execute(sql, val)
            cursor.commit()
            flash('User information successfully saved.')
            return redirect(url_for('users'))
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        return render_template('profile.html',accessdata=accessdata)
    else:
        data['code'] = 400
        data['message'] = "You are not authorised user."
        return json.dumps(data)

@app.route('/getuseremail', methods=['GET'])
def getUserEmail():
    if 'password' and 'email' in session:
        cursor = condb.cursor()
        # print(request)
        email = request.args['email']
        sql = "SELECT email FROM [dbo].[usermaster] WHERE usermaster.email = ?"
        cursor.execute(sql, email)
        data = cursor.fetchall()
        if len(data) == 0:
            return jsonify(True)
        else:
            return jsonify(False)
    else:
        data['code'] = 400
        data['message'] = "You are not authorised user."
        return json.dumps(data)

#################### ----------- END User - Profile Page ----------- ############################

#################### ----------- Commission Page ----------- ############################

@app.route('/commissions', methods=['GET', 'POST', 'PUT'])
def commissions():
    global companyid
    companyid = session["companyid"]
    if 'password' and 'email' in session:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            # getting all json data from the datatable
            content = request.json

            commission_obj = AdminCommission()
            # get columns from the content(json data)
            columns = content['columns']

            # initially start show 0 & on click next it will increased accroding to defined rows in the table  (Display index for the first record shown on the current page)
            offset = content['start']
            # Display length (number of records) use --> used in fetch to get no of next records from the database
            length = content['length']

            # the search field for the datatables
            search = content['search']
            searchbox = search['value'].strip()
            searchbox = "{" if searchbox.startswith("'") else searchbox
            searchbox = "{" if searchbox.startswith("-") else searchbox
            searchbox = "{" if searchbox.startswith(";") else searchbox

            # filter for status using upper dropdown
            columns_status = columns[5]
            # print('columns_status', columns_status)
            columns_status_search = columns_status['search']['value']
            # print(columns_status_search)
            columns_status_search = ('' if columns_status_search == 'Status' else columns_status_search)
            # print(columns_status_search)

            columns_date = columns[0]
            columns_date = columns_date['search']['value']
            columns_date_search = ("" if columns_date == "DateRange" else columns_date)

            today = datetime.datetime.now()
            lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
            date1, date2 = (
                (today - datetime.timedelta(days=6)).date(), today.date()) if columns_date_search == 'Last7days' else (
                ((
                         today - datetime.timedelta(
                     days=today.weekday())).date(),
                 today.date()) if columns_date_search == "ThisWeek" else (
                    ((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                     lastMonthdate.date()) if columns_date_search == "LastMonth" else (
                        (today.replace(day=1).date(), today.date()) if columns_date_search == "ThisMonth" else (
                            (today - datetime.timedelta(days=30)).date(),
                            today.date()) if columns_date_search == "Last30days" else ((datetime.date.strftime(
                            datetime.datetime.strptime(columns_date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),
                                                                                        datetime.date.strftime(
                                                                                            datetime.datetime.strptime(
                                                                                                columns_date_search[
                                                                                                18:28],
                                                                                                '%m-%d-%Y'),
                                                                                            "%Y-%m-%d")) if len(
                            columns_date_search) == 28 else ("", "")))))
            date1 = str(date1)
            date2 = str(date2)

            # for sorting
            orderable = content['order']
            sorting = ["weekstart" if orderable[0]['column'] == 0 else (
                "order_number" if orderable[0]['column'] == 1 else (
                    'total_item' if orderable[0]['column'] == 2 else (
                        'total_amount' if orderable[0]['column'] == 3 else (
                            'commision' if orderable[0]['column'] == 4 else ""))))]
            direction = orderable[0]['dir']

            ## RANGE SLIDER VALUE ---- >
            custom_filter = False
            column_order_range = content['order_range']
            column_item_range = content['item_range']
            column_commission_range = content['commission_range']
            column_amount_range = content['amount_range']
            #########################################################################################
            custom_items = [column_order_range, column_item_range, column_commission_range, column_amount_range]
            custom_filter = any(custom_items)

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None
            if columns_date_search != "":
                custom_dtrange = "CAST([ordertracking].[orderedDate] AS DATE) between '" + str(
                    date1) + "' and '" + str(date2) + "'"
                query_shorter.append(custom_dtrange)
            if columns_status_search != "":
                query_shorter.append("comm_status = '" + str(columns_status_search) + "'")
            if len(searchbox) != 0:
                custom_searchbox = "(CONVERT (varchar(10), ordertracking.orderedDate,110) LIKE '{}%' OR ordertracking.order_number LIKE '{}%' OR ordertracking.comm_status LIKE '{}%' OR ordertracking.subtotal LIKE '{}%')".format(
                    searchbox, searchbox, searchbox, searchbox
                )
                query_shorter.append(custom_searchbox)
            if len(sorting[0]) != 0:
                custom_sorting = sorting[0]
                custom_direction = direction

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            if custom_filter:
                query_shorter_having = []
                if len(column_order_range) != 0:
                    query_shorter_having.append("count(DISTINCT order_number) BETWEEN '" + str(
                        column_order_range[0]) + "' AND '" + str(column_order_range[1]) + "'")
                if len(column_item_range) != 0:
                    query_shorter_having.append("sum(qty_cart) BETWEEN '" + str(
                        column_item_range[0]) + "' AND '" + str(column_item_range[1]) + "'")
                if len(column_amount_range) != 0:
                    query_shorter_having.append("sum(price*qty_cart) BETWEEN '" + str(
                        column_amount_range[0]) + "' AND '" + str(column_amount_range[1]) + "'")
                if len(column_commission_range) != 0:
                    query_shorter_having.append("round(sum(price*qty_cart)/100,2) BETWEEN '" + str(
                        column_commission_range[0]) + "' AND '" + str(column_commission_range[1]) + "'")

                if len(query_shorter_having) == 0:
                    custom_query_having = ''
                elif len(query_shorter_having) == 1:
                    custom_query_having = ''.join(query_shorter_having)
                else:
                    custom_query_having = ' AND '.join(query_shorter_having)

                sql = commission_obj.commissionforcountwithhaving(custom_query_having, custom_query)
                # print(sql)
                cursor.execute(sql)
                count = cursor.fetchall()
                # print("count", count)
                try:
                    no_of_records = len(count)
                except Exception as e:
                    no_of_records = count[0][0]

                sql = commission_obj.commissionforquerywithhaving(offset, length, custom_query_having, custom_query,
                                                        custom_sorting, custom_direction)
                # print(sql)
                cursor.execute(sql)
            else:
                sql = commission_obj.commissionforcount(custom_query)
                # print(sql)
                cursor.execute(sql)
                count = cursor.fetchall()
                # print("count", count)
                try:
                    no_of_records = len(count)
                except Exception as e:
                    no_of_records = count[0][0]

                sql = commission_obj.commissionforquery(offset, length, custom_query,
                                                 custom_sorting, custom_direction)
                # print(sql)
                cursor.execute(sql)

            # fetching checking queue data from the database
            commissionTable = cursor.fetchall()

            commission_list = []
            for data in commissionTable:
                commission_date = "{0} - {1}".format(pd.to_datetime(data.weekstart).date().strftime('%m/%d/%y'), pd.to_datetime(data.weekend).date().strftime('%m/%d/%y'))
                commission_date_range = "{0}-{1}".format(data.weekend, data.weekstart)
                commission_dict = {
                    'WeekCount': data.week_count,
                    'WeekStart': data.weekstart,
                    'WeekEnd': data.weekend,
                    'CommissionDateRange': commission_date_range,
                    'CommissionDate': commission_date,
                    'OrderCount': data.order_number,
                    'Status': data.comm_status if data.comm_status else 'No Status',
                    'TotalItem': data.total_item,
                    'TotalAmount': '{0:.2f}'.format(float(data.total_amount)),
                    'TotalCommission': '{0:.2f}'.format(float(data.commision))
                }
                commission_list.append(commission_dict)
            print(commission_list)
            responsedata = {
                "draw": content['draw'],  # draw give pagination number i.e 1 or 2 or 3
                "data": commission_list,
                "recordsTotal": no_of_records,
                "recordsFiltered": no_of_records
            }
            return jsonify(responsedata)
        elif request.method == "PUT":
            data = {}
            import datetime
            cursor = condb.cursor()
            commission_data = request.json
            date_range = commission_data['dateRange']
            start_date, end_date = "", ""
            if date_range:
                date_range_list = date_range.split('-')
                end_date = date_range_list[0]
                start_date = date_range_list[1]
            status = commission_data['newValue']

            sql = "UPDATE [dbo].[ordertracking] SET comm_status=?, Date_modify=? WHERE orderedDate between '"+str(start_date)+"' and '"+str(end_date)+"'"
            val = (status, datetime.datetime.now())
            cursor.execute(sql, val)
            cursor.commit()
            rowcount = cursor.rowcount
            if rowcount > 0:
                data['code'] = 200
                data['message'] = "Status Updated"
            else:
                data['message'] = "Not Updated"
            return jsonify(data)
        cursor = condb.cursor()
        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()

        ##### SLider data #####
        range_slider_data = {}
        sql = "SELECT MAX(subtotal) as max_amount, MAX(round((subtotal/100),0)) as max_commission FROM [dbo].[ordertracking] WHERE tracking_status not in ('Cancelled','Processed','Ordered')"
        cursor.execute(sql)
        table_Data = cursor.fetchone()
        amount_slider, commission_slider = {}, {}
        if None not in table_Data:
            max_amount = int(table_Data.max_amount)
            max_commission = int(table_Data.max_commission)

            amount_slider['min'], commission_slider['min'] = 0, 0
            amount_slider['from'], commission_slider['from'] = 0, 0

            max_amount += 1
            max_commission += 1

            amount_slider['max'], commission_slider['max'] = max_amount, max_commission
            amount_slider['to'], commission_slider['to'] = max_amount, max_commission
            range_slider_data['amount_slider'] = amount_slider
            range_slider_data['commission_slider'] = commission_slider
        else:
            amount_slider['min'], commission_slider['min'] = 0, 0
            amount_slider['from'], commission_slider['from'] = 0, 0
            amount_slider['max'], commission_slider['max'] = 1, 1
            amount_slider['to'], commission_slider['to'] = 1, 1
            range_slider_data['amount_slider'] = amount_slider
            range_slider_data['commission_slider'] = commission_slider
        return render_template('commissions.html', accessdata = accessdata, sliderdata = range_slider_data)
    else:
        data['code'] = 400
        data['message'] = "You are not authorised user."
        return json.dumps(data)

@app.route('/commissions-details', methods=['GET', 'POST'])
def commissions_detail():
    global companyid
    companyid = session["companyid"]
    cursor = condb.cursor()
    if 'password' and 'email' in session:
        if request.method == "POST":
            import datetime
            # initializing cursor
            cursor = condb.cursor()
            commission_detail_obj = AdminCommissionDetails()
            date_range = request.args.get('range')
            # print(date_range)
            start_date, end_date = "", ""
            if date_range:
                date_range_list = date_range.split('-')
                end_date = date_range_list[0]
                start_date = date_range_list[1]
            # getting all json data from the datatable
            content = request.json
            # get columns from the content(json data)
            columns = content['columns']

            # initially start show 0 & on click next it will increased accroding to defined rows in the table  (Display index for the first record shown on the current page)
            offset = content['start']
            # Display length (number of records) use --> used in fetch to get no of next records from the database
            length = content['length']

            search = content['search']
            searchbox = search['value'].strip()
            searchbox = "{" if searchbox.startswith("'") else searchbox
            searchbox = "{" if searchbox.startswith("-") else searchbox
            searchbox = "{" if searchbox.startswith(";") else searchbox

            # for sorting
            orderable = content['order']
            sorting = ["dateCreation" if orderable[0]['column'] == 0 else (
                      "order_number" if orderable[0]['column'] == 1 else (
                          'item_sku' if orderable[0]['column'] == 2 else (
                             'title' if orderable[0]['column'] == 3 else (
                                'subtotal' if orderable[0]['column'] == 4 else ""
                                 ))))]

            direction = orderable[0]['dir']

            ## RANGE SLIDER VALUE ---- >
            custom_filter = False
            column_commission_range = content['commission_range']
            column_amount_range = content['amount_range']
            #########################################################################################
            custom_items = [column_commission_range, column_amount_range]
            custom_filter = any(custom_items)

            query_shorter, custom_query = [], ""
            custom_sorting, custom_direction = None, None

            custom_dtrange = "orderedDate between '" + str(start_date) + "' and '" + str(end_date) + "'"
            query_shorter.append(custom_dtrange)
            if len(searchbox) != 0:
                custom_searchbox = "(CONVERT (varchar(10), ordertracking.orderedDate,110) LIKE '{}%' OR ordertracking.order_number LIKE '{}%' OR ordertracking.item_sku LIKE '{}%' OR ordertracking.subtotal LIKE '{}%')".format(
                    searchbox, searchbox, searchbox, searchbox
                )
                query_shorter.append(custom_searchbox)
            if len(sorting[0]) != 0:
                custom_sorting = sorting[0]
                custom_direction = direction

            if len(query_shorter) == 0:
                custom_query = ''
            elif len(query_shorter) == 1:
                custom_query = ''.join(query_shorter)
            else:
                custom_query = ' AND '.join(query_shorter)

            if custom_filter:
                query_shorter_having = []
                if len(column_amount_range) != 0:
                    query_shorter_having.append("sum(price*qty_cart) BETWEEN '" + str(
                        column_amount_range[0]) + "' AND '" + str(column_amount_range[1]) + "'")
                if len(column_commission_range) != 0:
                    query_shorter_having.append("(sum(price*qty_cart)/100) BETWEEN '" + str(
                        column_commission_range[0]) + "' AND '" + str(column_commission_range[1]) + "'")

                if len(query_shorter_having) == 0:
                    custom_query_having = ''
                elif len(query_shorter_having) == 1:
                    custom_query_having = ''.join(query_shorter_having)
                else:
                    custom_query_having = ' AND '.join(query_shorter_having)

                sql = commission_detail_obj.commissiondetailforcountwithhaving(custom_query_having, custom_query)
                # print(sql)
                cursor.execute(sql)
                count = cursor.fetchall()
                # print("count", count)
                try:
                    no_of_records = len(count)
                except Exception as e:
                    no_of_records = count[0][0]

                sql = commission_detail_obj.commissiondetailforquerywithhaving(offset, length, custom_query_having, custom_query,
                                                                  custom_sorting, custom_direction)
                # print(sql)
                cursor.execute(sql)
            else:
                sql = commission_detail_obj.commissiondetailforcount(custom_query)
                # print(sql)
                cursor.execute(sql)
                count = cursor.fetchall()
                # print("count", count)
                try:
                    no_of_records = len(count)
                except Exception as e:
                    no_of_records = count[0][0]

                sql = commission_detail_obj.commissiondetailforquery(offset, length, custom_query,
                                                        custom_sorting, custom_direction)
                # print(sql)
                cursor.execute(sql)

            # fetching checking queue data from the database
            commissionTable = cursor.fetchall()

            commission_list = []
            for data in commissionTable:
                commission_date = "{0}".format(pd.to_datetime(data.dateCreation).date().strftime('%m/%d/%y'))
                commission_dict = {
                    'CommissionDate': commission_date,
                    'OrderNumber': data.order_number,
                    'ItemSku': data.item_sku,
                    'Title': data.title,
                    'Price': '{0:.2f}'.format(float(data.price)),
                    'Qty': data.qty_cart,
                    'TotalPrice': '{0:.2f}'.format(float(data.subtotal)),
                    'TotalCommision': '{:.4f}'.format(data.subtotal/100),
                }
                commission_list.append(commission_dict)
            # print(commission_list)
            responsedata = {
                "draw": content['draw'],  # draw give pagination number i.e 1 or 2 or 3
                "data": commission_list,
                "recordsTotal": no_of_records,
                "recordsFiltered": no_of_records
            }
            return jsonify(responsedata)

        date_range = request.args.get('e')
        # print(date_range)
        start_date, end_date = "", ""
        if date_range:
            date_range_list = date_range.split('-')
            end_date = date_range_list[0]
            start_date = date_range_list[1]
            ##### SLider data #####
            range_slider_data = {}
            sql = "SELECT MAX(subtotal) as max_amount, MAX(round((subtotal/100),0)) as max_commission FROM [dbo].[ordertracking] WHERE tracking_status not in ('Cancelled','Processed','Ordered') AND orderedDate between '"+str(start_date)+"' and '"+str(end_date)+"'"
            cursor.execute(sql)
            table_Data = cursor.fetchone()
            amount_slider, commission_slider = {}, {}
            if None not in table_Data:
                max_amount = int(table_Data.max_amount)
                max_commission = int(table_Data.max_commission)

                amount_slider['min'], commission_slider['min'] = 0, 0
                amount_slider['from'], commission_slider['from'] = 0, 0

                max_amount += 1
                max_commission += 1

                amount_slider['max'], commission_slider['max'] = max_amount, max_commission
                amount_slider['to'], commission_slider['to'] = max_amount, max_commission
                range_slider_data['amount_slider'] = amount_slider
                range_slider_data['commission_slider'] = commission_slider
            else:
                amount_slider['min'], commission_slider['min'] = 0, 0
                amount_slider['from'], commission_slider['from'] = 0, 0
                amount_slider['max'], commission_slider['max'] = 1, 1
                amount_slider['to'], commission_slider['to'] = 1, 1
                range_slider_data['amount_slider'] = amount_slider
                range_slider_data['commission_slider'] = commission_slider

        sql = "SELECT CONVERT(varchar, DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), 101) weekstart, CONVERT(varchar, DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), 101) weekend, count(DISTINCT order_number) as order_number, sum(qty_cart) as total_item, sum(price*qty_cart) as total_amount, round(sum(price*qty_cart)/100,2) as commision, comm_status FROM [dbo].[ordertracking] WHERE tracking_status not in ('Cancelled','Processed','Ordered') AND orderedDate between '"+str(start_date)+"' and '"+str(end_date)+"'  GROUP BY DATEPART(WEEK,orderedDate), DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), comm_status"
        cursor.execute(sql)
        table_data = cursor.fetchone()
        commission_data = {
            'CommissionDate':'',
            'OrderCount':'',
            'Status': '',
            'TotalItem': '',
            'TotalAmount': '',
            'TotalCommission': ''
        }
        if table_data:
            commission_date = "{0} - {1}".format(pd.to_datetime(table_data.weekstart).date().strftime('%m/%d/%y'),
                                                 pd.to_datetime(table_data.weekend).date().strftime('%m/%d/%y'))
            commission_data = {
                'CommissionDate': commission_date,
                'OrderCount': table_data.order_number,
                'Status': table_data.comm_status if table_data.comm_status else 'No Status',
                'TotalItem': table_data.total_item,
                'TotalAmount': round(float(table_data.total_amount), 2),
                'TotalCommission': round(float(table_data.commision), 2)
            }

        cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
        accessdata = cursor.fetchall()
        return render_template('commissions_details.html',accessdata=accessdata, commissiondata=commission_data, date_range=date_range, sliderdata = range_slider_data)
    else:
        data['code'] = 400
        data['message'] = "You are not authorised user."
        return json.dumps(data)

#################### ----------- END Commission Page ----------- ############################

@app.route('/pos2')
def pos2():
	global companyid
	companyid = session["companyid"]
	cursor = condb.cursor()
	cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
	accessdata = cursor.fetchall()
	return render_template('pos2.html',accessdata=accessdata)

@app.route('/posdetail')
def posdetail():
	global companyid
	companyid = session["companyid"]
	cursor = condb.cursor()
	cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
	accessdata = cursor.fetchall()
	return render_template('posdetail.html',accessdata=accessdata)

@app.route('/posdetail-user')
def posdetail_user():
	global companyid
	companyid = session["companyid"]
	cursor = condb.cursor()
	cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
	accessdata = cursor.fetchall()
	return render_template('posdetail_user.html',accessdata=accessdata)

@app.route('/PO-Queue')
def PO_Queue():
    global companyid
    companyid = session["companyid"]
    cursor = condb.cursor()
    cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
    accessdata = cursor.fetchall()
    return render_template('PO_Queue.html',accessdata=accessdata)

@app.route('/invoices')
def invoices():
	global companyid
	companyid = session["companyid"]
	cursor = condb.cursor()
	cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
	accessdata = cursor.fetchall()
	return render_template('invoices.html',accessdata=accessdata)

@app.route('/invoicedetails')
def invoicedetails():
	global companyid
	companyid = session["companyid"]
	cursor = condb.cursor()
	cursor.execute("SELECT * FROM [dbo].[accessmaster] WHERE [dbo].[accessmaster].userid =" + str(companyid))
	accessdata = cursor.fetchall()
	return render_template('invoicedetails.html',accessdata=accessdata)

if __name__ == '__main__':
    app.run(debug=True)