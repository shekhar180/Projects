# import random
# print(random.sample(range(99), 20))
def emailchecker(email_user):
    email_user_list = []
    try:
        if email_user != "":
            i=0
            strlen = len(email_user)
            email_user_list.append(email_user)
            while i<strlen:
                if i != 0 and i !=(strlen):
                    newemail = email_user[:i]+'.'+email_user[i:]
                    if newemail not in email_user_list:
                        email_user_list.append(newemail)
                    if newemail[-1]:
                        newemail1 = newemail[:i+2]+'.'+newemail[i+2:]
                        if newemail1[-1] != '.':
                            if newemail1 not in email_user_list:
                                email_user_list.append(newemail1)
                        if newemail1:
                            newemail2 = newemail1[:i+4]+'.'+newemail1[i+4:]
                            if newemail2[-1] != '.':
                                if newemail2 not in email_user_list:
                                    email_user_list.append(newemail2)
                            if newemail2:
                                newemail3 = newemail2[:i+6]+'.'+newemail2[i+6:]
                                if newemail3[-1] != '.':
                                    if newemail3 not in email_user_list:
                                        email_user_list.append(newemail3)
                i+=1
        print(email_user_list.sort(reverse=True))
        return email_user_list
    except Exception as e:
        print(e)
        return email_user_list


# print(emailchecker("shekharlashkari"))



def emailparser(email_user):
    email_user_list = []
    try:
        if email_user != "":
            i = 0
            emaillist1 = []
            emaillist2 = []
            emaillist1.append(email_user)
            while i < len(email_user):
                if int(i + 1) < len(email_user):
                    if email_user[i + 1] != '.':
                        if email_user[i + 1] == '_':
                            pass
                        else:
                            if email_user[i] == '_':
                                pass
                            else:
                                emailuser = email_user[:i + 1] + '.' + email_user[i + 1:]
                                if emailuser not in emaillist1:
                                    emaillist1.append(emailuser)
                if int(i + 5) < len(email_user):
                    if email_user[i + 1] != '.':
                        if email_user[i + 1] == '_':
                            pass
                        else:
                            if email_user[i] == '_':
                                pass
                            else:
                                newstring = email_user[:i + 1] + '.' + email_user[i + 1:]
                    if newstring[i + 5] != '.':
                        if newstring[i + 5] == '_':
                            pass
                        else:
                            if newstring[i + 4] == '_':
                                pass
                            else:
                                nnewstring = newstring[:i + 5] + '.' + newstring[i + 5:]
                    if nnewstring[-1] != '.':
                        if nnewstring not in emaillist2:
                            emaillist2.append(nnewstring)

                i += 1
            email_user_list = emaillist1+emaillist2
        return email_user_list
    except Exception as e:
        print(e)
        return email_user_list

# print(emailparser("lashkarishekhar"))


def customdaterange(date_search):
    import datetime
    dates = {}
    dates.update({'date1':'','date2':''})
    today = datetime.datetime.now()
    lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
    date1, date2 = ((today - datetime.timedelta(days=6)).date(), today.date()) if date_search == 'Last7days' else \
        ((today.date(),today.date()) if date_search == "Today" else \
        (((today - datetime.timedelta(days=today.weekday())).date(),today.date()) if date_search == "ThisWeek" else \
         (((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),lastMonthdate.date()) if date_search == "LastMonth" else \
          ((today.replace(day=1).date(), today.date()) if date_search == "ThisMonth" else \
           ((today - datetime.timedelta(days=30)).date(),today.date()) if date_search == "Last30days" else \
           ((datetime.date.strftime(datetime.datetime.strptime(date_search[7:17], '%m-%d-%Y'), "%Y-%m-%d"),datetime.date.strftime(datetime.datetime.strptime(date_search[18:28],'%m-%d-%Y'),"%Y-%m-%d")) if len(date_search) == 28 else \
            ("", ""))))))
    dates.update({'date1': date1, 'date2': date2})
    return dates

print(customdaterange('Last30days'))