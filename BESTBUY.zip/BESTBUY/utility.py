class EmailList:
    def emailqueryforcount(self, custom_query=None):
        if custom_query:
            sql = "SELECT COUNT(*) as count FROM [dbo].[emailmaster] where {} AND parent_id = id GROUP BY parent_id,email,CONVERT (varchar(10), Date_creation,110),batch_status".format(
                custom_query)
        else:
            sql = "SELECT COUNT(*) as count FROM [dbo].[emailmaster] where parent_id = id GROUP BY parent_id,email,CONVERT (varchar(10), Date_creation,110),batch_status"
        return sql

    def emailquery(self, offset=None, length=None, custom_query=None, custom_sorting=None, custom_direction=None):
        if custom_sorting:
            if custom_query:
                sql = "SELECT parent_id, email, CONVERT (varchar(10), Date_creation,110) 'creationDate', batch_status as status FROM [dbo].[emailmaster] WHERE {} AND parent_id = id GROUP BY parent_id,email,CONVERT (varchar(10), Date_creation,110),batch_status ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_query, custom_sorting, custom_direction, offset, length)
            else:
                sql = "SELECT parent_id, email, CONVERT (varchar(10), Date_creation,110) 'creationDate', batch_status as status FROM [dbo].[emailmaster] WHERE parent_id = id GROUP BY parent_id,email,CONVERT (varchar(10), Date_creation,110),batch_status ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_sorting, custom_direction, offset, length)
        elif custom_query:
            sql = "SELECT parent_id, email, CONVERT (varchar(10), Date_creation,110) 'creationDate', batch_status as status FROM [dbo].[emailmaster] WHERE {} AND parent_id = id GROUP BY parent_id,email,CONVERT (varchar(10), Date_creation,110),batch_status ORDER BY max(Date_creation) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, offset, length)
        else:
            sql = "SELECT parent_id, email, CONVERT (varchar(10), Date_creation,110) 'creationDate', batch_status as status FROM [dbo].[emailmaster] WHERE parent_id = id GROUP BY parent_id,email,CONVERT (varchar(10), Date_creation,110),batch_status ORDER BY max(Date_creation) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                offset, length)
        return sql

    def emailqueryselectall(self, custom_query=None):
        if custom_query:
            sql = "SELECT emailmaster.id FROM [dbo].[emailmaster] where {} AND parent_id = id GROUP BY id,parent_id,email,CONVERT (varchar(10), Date_creation,110),batch_status".format(
                custom_query)
        else:
            sql = "SELECT emailmaster.id FROM [dbo].[emailmaster] where parent_id = id GROUP BY id,parent_id,email,CONVERT (varchar(10), Date_creation,110),batch_status"
        return sql

class EmailDetails:
    def emaildetailqueryforcount(self, custom_query=None):
        sql = "SELECT count([dbo].[emailmaster].[id]) as count FROM [dbo].[emailmaster] WHERE {}".format(
                custom_query)
        return sql

    def emaildetailquery(self, offset=None, length=None, custom_query=None, custom_sorting=None, custom_direction=None):
        if custom_sorting:
            sql = "SELECT id, email, parent_id, status, no_of_order, cancellation, CONVERT (varchar(10), Date_creation ,110) 'creationDate' FROM [dbo].[emailmaster] WHERE {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, custom_sorting, custom_direction, offset, length)
        else:
            sql = "SELECT id, email, parent_id, status, no_of_order, cancellation, CONVERT (varchar(10), Date_creation ,110) 'creationDate' FROM [dbo].[emailmaster] WHERE {} ORDER BY Date_creation ASC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, offset, length)
        return sql

    def emaildetailqueryselectall(self, custom_query=None):
        sql = "SELECT [emailmaster].[id] FROM [dbo].[emailmaster] WHERE {}".format(
            custom_query)
        return sql

class AddressList:
    def addressqueryforcount(self, custom_query=None):
        if custom_query:
            sql = "SELECT COUNT(*) as count FROM [dbo].[addressmaster] where {} AND parent_id = id group by parent_id, batch_status, city, state, zip".format(
                custom_query)
        else:
            sql = "SELECT COUNT(*) as count FROM [dbo].[addressmaster] where parent_id = id group by parent_id, batch_status, city, state, zip"
        return sql

    def addressquery(self, offset=None, length=None, custom_query=None, custom_sorting=None, custom_direction=None):
        if custom_sorting:
            if custom_query:
                sql = "SELECT parent_id, batch_status as status, city, state, zip, CONVERT (varchar(10), max(Date_creation) ,110) 'creationDate' FROM [dbo].[addressmaster] where {} AND parent_id = id group by parent_id, batch_status, city, state, zip  ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_query, custom_sorting, custom_direction, offset, length)
            else:
                sql = "SELECT parent_id, batch_status as status, city, state, zip, CONVERT (varchar(10), max(Date_creation) ,110) 'creationDate' FROM [dbo].[addressmaster] where parent_id = id group by parent_id, batch_status, city, state, zip  ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_sorting, custom_direction, offset, length)
        elif custom_query:
            sql = "SELECT parent_id, batch_status as status, city, state, zip, CONVERT (varchar(10), max(Date_creation) ,110) 'creationDate' FROM [dbo].[addressmaster] where {} AND parent_id = id group by parent_id, batch_status, city, state, zip  ORDER BY max(Date_creation) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, offset, length)
        else:
            sql = "SELECT parent_id, batch_status as status, city, state, zip, CONVERT (varchar(10), max(Date_creation) ,110) 'creationDate' FROM [dbo].[addressmaster] where parent_id = id group by parent_id, batch_status, city, state, zip  ORDER BY max(Date_creation) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                offset, length)
        return sql

    def addressqueryselectall(self, custom_query=None):
        if custom_query:
            sql = "SELECT addressmaster.id as count FROM [dbo].[addressmaster] where {} AND parent_id = id group by id, parent_id, batch_status, city, state, zip".format(
                custom_query)
        else:
            sql = "SELECT addressmaster.id as count FROM [dbo].[addressmaster] where parent_id = id group by id, parent_id, batch_status, city, state, zip"
        return sql

class AddressDetails:
    def addressdetailqueryforcount(self, custom_query=None):
        sql = "SELECT count([dbo].[addressmaster].[id]) as count FROM [dbo].[addressmaster] WHERE {}".format(
                custom_query)
        return sql

    def addressdetailquery(self, offset=None, length=None, custom_query=None, custom_sorting=None, custom_direction=None):
        if custom_sorting:
            sql = "SELECT id, full_address, parent_id, no_of_order, cancellation, status, CONVERT (varchar(10), Date_creation ,110) 'creationDate' FROM [dbo].[addressmaster] WHERE {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, custom_sorting, custom_direction, offset, length)
        else:
            sql = "SELECT id, full_address, parent_id, no_of_order, cancellation, status, CONVERT (varchar(10), Date_creation ,110) 'creationDate' FROM [dbo].[addressmaster] WHERE {} ORDER BY Date_creation ASC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, offset, length)
        return sql

    def addressdetailqueryselectall(self, custom_query=None):
        sql = "SELECT [addressmaster].[id] FROM [dbo].[addressmaster] WHERE {}".format(
            custom_query)
        return sql

class BuyingManager:
    def buyingmanagerrangequeryforcount(self, having_query=None, custom_query=None):
        if custom_query:
            sql = "SELECT count([buyingmaster].[cart_id]) as count FROM [dbo].[buyingmaster] WHERE {} group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal], [final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled] HAVING {}".format(
                custom_query, having_query)
        else:
            sql = "SELECT count([buyingmaster].[cart_id]) as count FROM [dbo].[buyingmaster] group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal], [final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled] HAVING {}".format(
                having_query)
        return sql

    def buyingmanagerrangequery(self, offset=None, length=None, having_query=None, custom_query=None, custom_sorting=None, custom_direction=None):
        if custom_sorting:
            if custom_query:
                sql = "SELECT [buyingmaster].[cart_id], [priority], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110) 'creationDate', COUNT(DISTINCT  [buyingmaster].[item_sku]) as skus, [subtotal], [order_count], [completed_count], [cancelled_count], [unfulfilled], sum([projected_cost]) as projected_cost, [final_cost], [status], [reason] FROM [dbo].[buyingmaster] WHERE {} group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal], [final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled] HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_query, having_query, custom_sorting, custom_direction, offset, length)
            else:
                sql = "SELECT [buyingmaster].[cart_id], [priority], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110) 'creationDate', COUNT(DISTINCT  [buyingmaster].[item_sku]) as skus, [subtotal], [order_count], [completed_count], [cancelled_count], [unfulfilled], sum([projected_cost]) as projected_cost, [final_cost], [status], [reason] FROM [dbo].[buyingmaster] group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal], [final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled] HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    having_query, custom_sorting, custom_direction, offset, length)
        elif custom_query:
            sql = "SELECT [buyingmaster].[cart_id], [priority], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110) 'creationDate', COUNT(DISTINCT  [buyingmaster].[item_sku]) as skus, [subtotal], [order_count], [completed_count], [cancelled_count], [unfulfilled], sum([projected_cost]) as projected_cost, [final_cost], [status], [reason] FROM [dbo].[buyingmaster] WHERE {} group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal], [final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled] HAVING {} ORDER BY min([buyingmaster].[priority]) ASC, max([buyingmaster].[Date_creation]) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, having_query, offset, length)
        else:
            sql = "SELECT [buyingmaster].[cart_id], [priority], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110) 'creationDate', COUNT(DISTINCT  [buyingmaster].[item_sku]) as skus, [subtotal], [order_count], [completed_count], [cancelled_count], [unfulfilled], sum([projected_cost]) as projected_cost, [final_cost], [status], [reason] FROM [dbo].[buyingmaster] group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal], [final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled] HAVING {} ORDER BY min([buyingmaster].[priority]) ASC, max([buyingmaster].[Date_creation]) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                having_query, offset, length)
        return sql

    def buyingmanagerqueryforcount(self, custom_query=None):
        if custom_query:
            sql = "SELECT count([buyingmaster].[cart_id]) as count FROM [dbo].[buyingmaster] WHERE {} group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal], [final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled]".format(
                custom_query)
        else:
            sql = "SELECT count([buyingmaster].[cart_id]) as count FROM [dbo].[buyingmaster] group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal], [final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled]"
        return sql

    def buyingmanagerquery(self, offset=None, length=None, custom_query=None, custom_sorting=None, custom_direction=None):
        if custom_sorting:
            if custom_query:
                sql = "SELECT [buyingmaster].[cart_id], [priority], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110) 'creationDate', COUNT(DISTINCT  [buyingmaster].[item_sku]) as skus, [subtotal], [order_count], [completed_count], [cancelled_count], [unfulfilled], sum([projected_cost]) as projected_cost, [final_cost], [status], [reason] FROM [dbo].[buyingmaster] WHERE {} group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal],[final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled] ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_query, custom_sorting, custom_direction, offset, length)
            else:
                sql = "SELECT [buyingmaster].[cart_id], [priority], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110) 'creationDate', COUNT(DISTINCT  [buyingmaster].[item_sku]) as skus, [subtotal], [order_count], [completed_count], [cancelled_count], [unfulfilled], sum([projected_cost]) as projected_cost, [final_cost], [status], [reason] FROM [dbo].[buyingmaster] group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal],[final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled] ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_sorting, custom_direction, offset, length)
        elif custom_query:
            sql = "SELECT [buyingmaster].[cart_id], [priority], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110) 'creationDate', COUNT(DISTINCT  [buyingmaster].[item_sku]) as skus, [subtotal], [order_count], [completed_count], [cancelled_count], [unfulfilled], sum([projected_cost]) as projected_cost, [final_cost], [status], [reason] FROM [dbo].[buyingmaster] WHERE {} group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal],[final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled] ORDER BY min([buyingmaster].[priority]) ASC, max([buyingmaster].[Date_creation]) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, offset, length)
        else:
            sql = "SELECT [buyingmaster].[cart_id], [priority], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110) 'creationDate', COUNT(DISTINCT  [buyingmaster].[item_sku]) as skus, [subtotal], [order_count], [completed_count], [cancelled_count], [unfulfilled], sum([projected_cost]) as projected_cost, [final_cost], [status], [reason] FROM [dbo].[buyingmaster] group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal],[final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled] ORDER BY min([buyingmaster].[priority]) ASC, max([buyingmaster].[Date_creation]) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                offset, length)
        return sql

    def buyingmanagerselectallwithhaving(self, having_query=None, custom_query=None):
        if custom_query:
            sql = "SELECT [buyingmaster].[cart_id] FROM [dbo].[buyingmaster] WHERE {} group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal], [final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled] HAVING {}".format(
                custom_query, having_query)
        else:
            sql = "SELECT [buyingmaster].[cart_id] FROM [dbo].[buyingmaster] group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal], [final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled] HAVING {}".format(
                having_query)
        return sql

    def buyingmanagerselectallwithouthaving(self, custom_query=None):
        if custom_query:
            sql = "SELECT [buyingmaster].[cart_id] FROM [dbo].[buyingmaster] WHERE {} group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal], [final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled]".format(
                custom_query)
        else:
            sql = "SELECT [buyingmaster].[cart_id] FROM [dbo].[buyingmaster] group by [buyingmaster].[priority], [buyingmaster].[cart_id], CONVERT (varchar(10), [dbo].[buyingmaster].[Date_creation] ,110), [status], [reason], [subtotal], [final_cost], [order_count], [completed_count], [cancelled_count], [unfulfilled]"
        return sql

    def customdaterange(self, date_search):
        import datetime
        dates = {}
        dates['date1'] = ''
        dates['date2'] = ''
        today = datetime.datetime.now()
        lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
        date1, date2 = ((today - datetime.timedelta(days=6)).date(), today.date()) if date_search == 'Last7days' else \
            ((today.date(), today.date()) if date_search == "Today" else \
                 (((today - datetime.timedelta(days=today.weekday())).date(),
                   today.date()) if date_search == "ThisWeek" else \
                      (((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                        lastMonthdate.date()) if date_search == "LastMonth" else \
                           ((today.replace(day=1).date(), today.date()) if date_search == "ThisMonth" else \
                                ((today - datetime.timedelta(days=30)).date(),
                                 today.date()) if date_search == "Last30days" else \
                                    ((datetime.date.strftime(datetime.datetime.strptime(date_search[7:17], '%m-%d-%Y'),
                                                             "%Y-%m-%d"),
                                      datetime.date.strftime(datetime.datetime.strptime(date_search[18:28], '%m-%d-%Y'),
                                                             "%Y-%m-%d")) if len(date_search) == 28 else \
                                         ("", ""))))))
        dates['date1'] = date1
        dates['date2'] = date2
        return dates

class OrderTracking:
    # Order tracking query for range counts
    def ordertrackingrangequeryforcount(self, havingquery=None, custom_query=None):
        if custom_query:
            sql = "SELECT COUNT(*) as count FROM [dbo].[ordertracking] WHERE {} group by order_number, no_of_gc, cart_total HAVING {}".format(
                custom_query, havingquery)
        else:
            sql = "SELECT COUNT(*) as count FROM [dbo].[ordertracking] group by order_number, no_of_gc, cart_total HAVING {}".format(
                havingquery)
        return sql

    # Order tracking query for range
    def ordertrackingrangequery(self, offset=None, length=None, havingquery=None, custom_query=None, sorting=None,
                                direction=None):
        if sorting:
            if custom_query:
                sql = "SELECT [order_number], [cart_total], max([tracking_status]) as tracking_status, [no_of_gc], sum(qty_cart) as qty_cart, CONVERT (varchar(10), max(orderedDate) ,110) 'creationDate' FROM [dbo].[ordertracking] WHERE {} group by order_number, no_of_gc, cart_total HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_query, havingquery, sorting, direction, offset, length)
            else:
                sql = "SELECT [order_number], [cart_total], max([tracking_status]) as tracking_status, [no_of_gc], sum(qty_cart) as qty_cart, CONVERT (varchar(10), max(orderedDate) ,110) 'creationDate' FROM [dbo].[ordertracking] group by order_number, no_of_gc, cart_total HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    havingquery, sorting, direction, offset, length)
        elif custom_query:
            sql = "SELECT [order_number], [cart_total], max([tracking_status]) as tracking_status, [no_of_gc], sum(qty_cart) as qty_cart, CONVERT (varchar(10), max(orderedDate) ,110) 'creationDate' FROM [dbo].[ordertracking] WHERE {} group by order_number, no_of_gc, cart_total HAVING {} ORDER BY max(orderedDate) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, havingquery, offset, length)
        else:
            sql = "SELECT [order_number], [cart_total], max([tracking_status]) as tracking_status, [no_of_gc], sum(qty_cart) as qty_cart, CONVERT (varchar(10), max(orderedDate) ,110) 'creationDate' FROM [dbo].[ordertracking] group by order_number, no_of_gc, cart_total HAVING {} ORDER BY max(orderedDate) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                havingquery, offset, length)
        return sql

    # Order tracking query for counts
    def ordertrackingqueryforcount(self, custom_query=None):
        if custom_query:
            sql = "SELECT COUNT(*) as count FROM [dbo].[ordertracking] WHERE {} group by order_number, no_of_gc, cart_total".format(
                custom_query)
        else:
            sql = "SELECT COUNT(*) as count FROM [dbo].[ordertracking] group by order_number, no_of_gc, cart_total"
        return sql

    # Order tracking query
    def ordertrackingquery(self, offset=None, length=None, custom_query=None, sorting=None,
                                direction=None):
        if sorting:
            if custom_query:
                sql = "SELECT [order_number], [cart_total], max([tracking_status]) as tracking_status, [no_of_gc], sum(qty_cart) as qty_cart, CONVERT (varchar(10), max(orderedDate) ,110) 'creationDate' FROM [dbo].[ordertracking] WHERE {} group by order_number, no_of_gc, cart_total ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_query, sorting, direction, offset, length)
            else:
                sql = "SELECT [order_number], [cart_total], max([tracking_status]) as tracking_status, [no_of_gc], sum(qty_cart) as qty_cart, CONVERT (varchar(10), max(orderedDate) ,110) 'creationDate' FROM [dbo].[ordertracking] group by order_number, no_of_gc, cart_total ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    sorting, direction, offset, length)
        elif custom_query:
            sql = "SELECT [order_number], [cart_total], max([tracking_status]) as tracking_status, [no_of_gc], sum(qty_cart) as qty_cart, CONVERT (varchar(10), max(orderedDate) ,110) 'creationDate' FROM [dbo].[ordertracking] WHERE {} group by order_number, no_of_gc, cart_total ORDER BY max(orderedDate) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, offset, length)
        else:
            sql = "SELECT [order_number], [cart_total], max([tracking_status]) as tracking_status, [no_of_gc], sum(qty_cart) as qty_cart, CONVERT (varchar(10), max(orderedDate) ,110) 'creationDate' FROM [dbo].[ordertracking] group by order_number, no_of_gc, cart_total ORDER BY max(orderedDate) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                offset, length)
        return sql

    def ordertrackingquerywithhaving(self, havingquery=None, custom_query=None):
        if custom_query:
            sql = "SELECT order_number FROM [dbo].[ordertracking] WHERE {} group by order_number, no_of_gc, cart_total HAVING {}".format(
                custom_query, havingquery)
        else:
            sql = "SELECT order_number FROM [dbo].[ordertracking] group by order_number, no_of_gc, cart_total HAVING {}".format(
                havingquery)
        return sql

    def ordertrackingquerywithouthaving(self, custom_query=None):
        if custom_query:
            sql = "SELECT order_number FROM [dbo].[ordertracking] WHERE {} group by order_number, no_of_gc, cart_total".format(
                custom_query)
        else:
            sql = "SELECT order_number FROM [dbo].[ordertracking] group by order_number, no_of_gc, cart_total"
        return sql

    def ordertrackingdownloadwithhaving(self, havingquery=None, custom_query=None):
        if custom_query:
            sql = "SELECT [order_number], [cart_total], max([tracking_status]) as tracking_status, [no_of_gc], sum(qty_cart) as qty_cart, CONVERT (varchar(10), max(orderedDate) ,110) 'creationDate' FROM [dbo].[ordertracking] WHERE {} group by order_number, no_of_gc, cart_total HAVING {} ORDER BY max(orderedDate) DESC".format(
                custom_query, havingquery)
        else:
            sql = "SELECT [order_number], [cart_total], max([tracking_status]) as tracking_status, [no_of_gc], sum(qty_cart) as qty_cart, CONVERT (varchar(10), max(orderedDate) ,110) 'creationDate' FROM [dbo].[ordertracking] group by order_number, no_of_gc, cart_total HAVING {} ORDER BY max(orderedDate) DESC".format(
                havingquery)
        return sql

    def ordertrackingdownloadwithouthaving(self, custom_query=None):
        if custom_query:
            sql = "SELECT [order_number], [cart_total], max([tracking_status]) as tracking_status, [no_of_gc], sum(qty_cart) as qty_cart, CONVERT (varchar(10), max(orderedDate) ,110) 'creationDate' FROM [dbo].[ordertracking] WHERE {} group by order_number, no_of_gc, cart_total ORDER BY max(orderedDate) DESC".format(
                custom_query)
        else:
            sql = "SELECT [order_number], [cart_total], max([tracking_status]) as tracking_status, [no_of_gc], sum(qty_cart) as qty_cart, CONVERT (varchar(10), max(orderedDate) ,110) 'creationDate' FROM [dbo].[ordertracking] group by order_number, no_of_gc, cart_total ORDER BY max(orderedDate) DESC"
        return sql

    def customdaterange(self, date_search):
        import datetime
        dates = {}
        dates['date1'] = ''
        dates['date2'] = ''
        today = datetime.datetime.now()
        lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
        date1, date2 = ((today - datetime.timedelta(days=6)).date(), today.date()) if date_search == 'Last7days' else \
            ((today.date(), today.date()) if date_search == "Today" else \
                 (((today - datetime.timedelta(days=today.weekday())).date(),
                   today.date()) if date_search == "ThisWeek" else \
                      (((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                        lastMonthdate.date()) if date_search == "LastMonth" else \
                           ((today.replace(day=1).date(), today.date()) if date_search == "ThisMonth" else \
                                ((today - datetime.timedelta(days=30)).date(),
                                 today.date()) if date_search == "Last30days" else \
                                    ((datetime.date.strftime(datetime.datetime.strptime(date_search[7:17], '%m-%d-%Y'),
                                                             "%Y-%m-%d"),
                                      datetime.date.strftime(datetime.datetime.strptime(date_search[18:28], '%m-%d-%Y'),
                                                             "%Y-%m-%d")) if len(date_search) == 28 else \
                                         ("", ""))))))
        dates['date1'] = date1
        dates['date2'] = date2
        return dates

class GiftCardClass:
    ## Gift card custom date range
    def customdaterange(self, date_search):
        import datetime
        dates = {}
        dates['date1'] = ''
        dates['date2'] = ''
        today = datetime.datetime.now()
        lastMonthdate = today.replace(day=1) - datetime.timedelta(days=1)
        date1, date2 = ((today - datetime.timedelta(days=6)).date(), today.date()) if date_search == 'Last7days' else \
            ((today.date(), today.date()) if date_search == "Today" else \
                 (((today - datetime.timedelta(days=today.weekday())).date(),
                   today.date()) if date_search == "ThisWeek" else \
                      (((today.replace(day=1) - datetime.timedelta(days=lastMonthdate.day)).date(),
                        lastMonthdate.date()) if date_search == "LastMonth" else \
                           ((today.replace(day=1).date(), today.date()) if date_search == "ThisMonth" else \
                                ((today - datetime.timedelta(days=30)).date(),
                                 today.date()) if date_search == "Last30days" else \
                                    ((datetime.date.strftime(datetime.datetime.strptime(date_search[7:17], '%m-%d-%Y'),
                                                             "%Y-%m-%d"),
                                      datetime.date.strftime(datetime.datetime.strptime(date_search[18:28], '%m-%d-%Y'),
                                                             "%Y-%m-%d")) if len(date_search) == 28 else \
                                         ("", ""))))))
        dates['date1'] = date1
        dates['date2'] = date2
        return dates

    ## Gift card filter range using custom filter count with having condition
    def giftcardrangecount(self, havingquery=None, custom_query=None):
        if custom_query:
            sql = "SELECT COUNT(*) FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number WHERE {} group by [giftcardlist].gift_card_no, giftcardlist.vendor, giftcardlist.batch_id, gift_card_pin, giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.id,  amount_paid, giftcardlist.gift_card_value HAVING {}".format(
                custom_query, havingquery)
        else:
            sql = "SELECT COUNT(*) FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number group by [giftcardlist].gift_card_no, giftcardlist.vendor, giftcardlist.batch_id, gift_card_pin, giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.id,  amount_paid, giftcardlist.gift_card_value HAVING {}".format(
                havingquery)
        return sql

    ## Gift card filter range using custom filter data with having condition
    def giftcardrangequery(self, offset=None, length=None, havingquery=None, custom_query=None,
                           sorting=None, direction=None):
        if sorting:
            if custom_query:
                sql = "SELECT giftcardlist.vendor, giftcardlist.batch_id, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, CONVERT (varchar(10),last_used ,110) 'last_used', CONVERT (varchar(10),date_of_purchase ,110) 'date_of_purchase', giftcardlist.id, sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) as cancellation_count, amount_paid, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number WHERE {} group by [giftcardlist].gift_card_no, giftcardlist.vendor, giftcardlist.batch_id, gift_card_pin, giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.id,  amount_paid, giftcardlist.gift_card_value HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_query, havingquery, sorting, direction, offset, length)
            else:
                sql = "SELECT giftcardlist.vendor, giftcardlist.batch_id, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, CONVERT (varchar(10),last_used ,110) 'last_used', CONVERT (varchar(10),date_of_purchase ,110) 'date_of_purchase', giftcardlist.id, sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) as cancellation_count, amount_paid, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number group by [giftcardlist].gift_card_no, giftcardlist.vendor, giftcardlist.batch_id, gift_card_pin, giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.id,  amount_paid, giftcardlist.gift_card_value HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                     havingquery, sorting, direction, offset, length)
        elif custom_query:
            sql = "SELECT giftcardlist.vendor, giftcardlist.batch_id, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, CONVERT (varchar(10),last_used ,110) 'last_used', CONVERT (varchar(10),date_of_purchase ,110) 'date_of_purchase', giftcardlist.id, sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) as cancellation_count, amount_paid, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number WHERE {} group by [giftcardlist].gift_card_no, giftcardlist.vendor, giftcardlist.batch_id, gift_card_pin, giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.id,  amount_paid, giftcardlist.gift_card_value HAVING {} ORDER BY [dbo].[giftcardlist].date_of_purchase DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, havingquery, offset, length)
        else:
            sql = "SELECT giftcardlist.vendor, giftcardlist.batch_id, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, CONVERT (varchar(10),last_used ,110) 'last_used', CONVERT (varchar(10),date_of_purchase ,110) 'date_of_purchase', giftcardlist.id, sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) as cancellation_count, amount_paid, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number group by [giftcardlist].gift_card_no, giftcardlist.vendor, giftcardlist.batch_id, gift_card_pin, giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.id,  amount_paid, giftcardlist.gift_card_value HAVING {} ORDER BY [dbo].[giftcardlist].date_of_purchase DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                havingquery, offset, length)
        return sql

    ## Gift card normal filter count
    def giftcardqueryforcount(self, custom_query=None):
        if custom_query:
            sql = "SELECT COUNT(giftcardlist.id) FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number WHERE {} group by [giftcardlist].gift_card_no".format(
                custom_query)
        else:
            sql = "SELECT COUNT(giftcardlist.id) FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number group by [giftcardlist].gift_card_no"
        return sql

    ## Gift card normal filter data
    def giftcardquery(self, offset=None, length=None, custom_query=None, sorting=None, direction=None):
        if sorting:
            if custom_query:
                sql = "SELECT giftcardlist.vendor, giftcardlist.batch_id, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, CONVERT (varchar(10),last_used ,110) 'last_used', CONVERT (varchar(10),date_of_purchase ,110) 'date_of_purchase', giftcardlist.id, sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) as cancellation_count, amount_paid, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number WHERE {} group by [giftcardlist].gift_card_no, giftcardlist.vendor, giftcardlist.batch_id, gift_card_pin, giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.id,  amount_paid, giftcardlist.gift_card_value ORDER BY {} {} DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_query, sorting, direction, offset, length)
            else:
                sql = "SELECT giftcardlist.vendor, giftcardlist.batch_id, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, CONVERT (varchar(10),last_used ,110) 'last_used', CONVERT (varchar(10),date_of_purchase ,110) 'date_of_purchase', giftcardlist.id, sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) as cancellation_count, amount_paid, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number group by [giftcardlist].gift_card_no, giftcardlist.vendor, giftcardlist.batch_id, gift_card_pin, giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.id,  amount_paid, giftcardlist.gift_card_value ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    sorting, direction, offset, length)
        elif custom_query:
            sql = "SELECT giftcardlist.vendor, giftcardlist.batch_id, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, CONVERT (varchar(10),last_used ,110) 'last_used', CONVERT (varchar(10),date_of_purchase ,110) 'date_of_purchase', giftcardlist.id, sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) as cancellation_count, amount_paid, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number WHERE {} group by [giftcardlist].gift_card_no, giftcardlist.vendor, giftcardlist.batch_id, gift_card_pin, giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.id,  amount_paid, giftcardlist.gift_card_value ORDER BY [dbo].[giftcardlist].date_of_purchase DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, offset, length)
        else:
            sql = "SELECT giftcardlist.vendor, giftcardlist.batch_id, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, CONVERT (varchar(10),last_used ,110) 'last_used', CONVERT (varchar(10),date_of_purchase ,110) 'date_of_purchase', giftcardlist.id, sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) as cancellation_count, amount_paid, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number group by [giftcardlist].gift_card_no, giftcardlist.vendor, giftcardlist.batch_id, gift_card_pin, giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.id,  amount_paid, giftcardlist.gift_card_value ORDER BY [dbo].[giftcardlist].date_of_purchase DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                offset, length)
        return sql

    ## Giftcard download using select all with custom filter
    def selectalldownloadwithhaving(self, havingquery=None, custom_query=None):
        if custom_query:
            sql = "SELECT giftcardlist.retailer, giftcardlist.batch_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, CONVERT (varchar(10),last_used ,110) 'last_used', CONVERT (varchar(10),date_of_purchase ,110) 'updated_at', giftcardlist.[id], count(ordernumber) as no_of_order, sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) as cancellation_count, giftcardlist.gift_card_value, amount_paid FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number WHERE {} group by [dbo].[giftcardlist].gift_card_no, giftcardlist.retailer, [gift_card_pin], giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.[id],  giftcardlist.batch_id, giftcardlist.vendor, giftcardlist.gift_card_value, amount_paid HAVING {} ORDER BY [dbo].[giftcardlist].date_of_purchase DESC".format(
                custom_query, havingquery)
        else:
            sql = "SELECT giftcardlist.retailer, giftcardlist.batch_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, CONVERT (varchar(10),last_used ,110) 'last_used', CONVERT (varchar(10),date_of_purchase ,110) 'updated_at', giftcardlist.[id], count(ordernumber) as no_of_order, sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) as cancellation_count, giftcardlist.gift_card_value, amount_paid FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number group by [dbo].[giftcardlist].gift_card_no, giftcardlist.retailer, [gift_card_pin], giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.[id],  giftcardlist.batch_id, giftcardlist.vendor, giftcardlist.gift_card_value, amount_paid HAVING {} ORDER BY [dbo].[giftcardlist].date_of_purchase DESC".format(
                havingquery)
        return sql

    ## Giftcard download using select all without custom filter
    def selectalldownloadwithouthaving(self, custom_query=None):
        if custom_query:
            sql = "SELECT giftcardlist.retailer, giftcardlist.batch_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, CONVERT (varchar(10),last_used ,110) 'last_used', CONVERT (varchar(10),date_of_purchase ,110) 'updated_at', giftcardlist.[id], count(ordernumber) as no_of_order, sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) as cancellation_count, giftcardlist.gift_card_value, amount_paid FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number WHERE {} group by [dbo].[giftcardlist].gift_card_no, giftcardlist.retailer, [gift_card_pin], giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.[id],  giftcardlist.batch_id, giftcardlist.vendor, giftcardlist.gift_card_value, amount_paid ORDER BY [dbo].[giftcardlist].date_of_purchase DESC".format(
                custom_query)
        else:
            sql = "SELECT giftcardlist.retailer, giftcardlist.batch_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, CONVERT (varchar(10),last_used ,110) 'last_used', CONVERT (varchar(10),date_of_purchase ,110) 'updated_at', giftcardlist.[id], count(ordernumber) as no_of_order, sum(case when order_purchase_status = 'Cancelled' then 1 else 0 end) as cancellation_count, giftcardlist.gift_card_value, amount_paid FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number group by [dbo].[giftcardlist].gift_card_no, giftcardlist.retailer, [gift_card_pin], giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.[id],  giftcardlist.batch_id, giftcardlist.vendor, giftcardlist.gift_card_value, amount_paid ORDER BY [dbo].[giftcardlist].date_of_purchase DESC"
        return sql

    ## Gift card select all functionality using having with checking queue
    def selectallmakingquerywithhaving(self, havingquery=None, custom_query=None):
        if custom_query:
            sql = "SELECT [giftcardlist].id FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number WHERE {} group by [giftcardlist].gift_card_no, giftcardlist.vendor, giftcardlist.batch_id, gift_card_pin, giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.id,  amount_paid, giftcardlist.gift_card_value HAVING {}".format(
                custom_query, havingquery)
        else:
            sql = "SELECT [giftcardlist].id FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number group by [giftcardlist].gift_card_no, giftcardlist.vendor, giftcardlist.batch_id, gift_card_pin, giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.id,  amount_paid, giftcardlist.gift_card_value HAVING {}".format(
                havingquery)
        return sql

    ## Gift card select all functionality with checking queue
    def selectallmakingquerywithouthaving(self, custom_query=None):
        if custom_query:
            sql = "SELECT [giftcardlist].id FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number WHERE {} group by [giftcardlist].gift_card_no, giftcardlist.vendor, giftcardlist.batch_id, gift_card_pin, giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.id,  amount_paid, giftcardlist.gift_card_value".format(
                custom_query)
        else:
            sql = "SELECT [giftcardlist].id FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number group by [giftcardlist].gift_card_no, giftcardlist.vendor, giftcardlist.batch_id, gift_card_pin, giftcardlist.status, [balance], [last_used], date_of_purchase, giftcardlist.id,  amount_paid, giftcardlist.gift_card_value"
        return sql

class CheckingQueueClass:
    ## Checking Queue filter range using custom filter count with having condition
    def checkingqueuecountwithhaving(self, havingquery=None, dtfilter=None, vendor=None, custom_searchbox=None):
        if custom_searchbox:
            if dtfilter and vendor:
                sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(
                    dtfilter, vendor, custom_searchbox, custom_searchbox, custom_searchbox, havingquery)
            elif vendor:
                sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(
                    vendor, custom_searchbox, custom_searchbox, custom_searchbox, havingquery)
            elif dtfilter:
                sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(
                    dtfilter, custom_searchbox, custom_searchbox, custom_searchbox, havingquery)
            else:
                sql = "SELECT count(queue_id) as queue_id_count where [giftcardlist].queue_status='que' AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(
                    custom_searchbox, custom_searchbox, custom_searchbox, havingquery)
        elif dtfilter:
            if vendor:
                sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(
                    dtfilter, vendor, havingquery)
            else:
                sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(
                    dtfilter, havingquery)
        elif vendor:
            sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(
                vendor, havingquery)
        else:
            sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(havingquery)
        return sql

    ## Checking Queue filter range using custom filter data with having condition
    def checkingqueuewithhaving(self, havingquery=None, offset=None, length=None, dtfilter=None, vendor=None, sorting=None,
                           direction=None, custom_searchbox=None):
        if custom_searchbox:
            if sorting:
                if dtfilter and vendor:
                    sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                        dtfilter, vendor, custom_searchbox, custom_searchbox, custom_searchbox, havingquery, sorting, direction,
                        offset, length)
                elif dtfilter:
                    sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                        dtfilter, custom_searchbox, custom_searchbox, custom_searchbox, havingquery, sorting, direction, offset,
                        length)
                elif vendor:
                    sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                        dtfilter, custom_searchbox, custom_searchbox, custom_searchbox, havingquery, sorting, direction, offset,
                        length)
                else:
                    sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                        custom_searchbox, custom_searchbox, custom_searchbox, havingquery, sorting, direction, offset, length)
            elif dtfilter and vendor:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    dtfilter, vendor, custom_searchbox, custom_searchbox, custom_searchbox, havingquery, offset, length)
            elif vendor:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    vendor, custom_searchbox, custom_searchbox, custom_searchbox, havingquery, offset, length)
            elif dtfilter:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    dtfilter, custom_searchbox, custom_searchbox, custom_searchbox, havingquery, offset, length)
            else:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_searchbox, custom_searchbox, custom_searchbox, havingquery, offset, length)
        elif sorting:
            if dtfilter and vendor:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    dtfilter, vendor, havingquery, sorting, direction, offset, length)
            elif dtfilter:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    dtfilter, havingquery, sorting, direction, offset, length)
            elif vendor:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    vendor, havingquery, sorting, direction, offset, length)
            else:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    havingquery, sorting, direction, offset, length)
        elif dtfilter:
            if vendor:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    dtfilter, havingquery, vendor, offset, length)
            else:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    dtfilter, havingquery, offset, length)
        elif vendor:
            sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                vendor, havingquery, offset, length)
        else:
            sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {} ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                havingquery, offset, length)
        return sql

    ## Checking Queue normal filter count
    def checkingqueuecountwithouthaving(self, dtfilter=None, vendor=None, custom_searchbox=None):
        if custom_searchbox:
            if dtfilter and vendor:
                sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)".format(
                    dtfilter, vendor, custom_searchbox, custom_searchbox, custom_searchbox)
            elif vendor:
                sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)".format(
                    vendor, custom_searchbox, custom_searchbox, custom_searchbox)
            elif dtfilter:
                sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)".format(
                    dtfilter, custom_searchbox, custom_searchbox, custom_searchbox)
            else:
                sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)".format(
                    custom_searchbox, custom_searchbox, custom_searchbox)
        elif dtfilter:
            if vendor:
                sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)".format(
                    dtfilter, vendor)
            else:
                sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)".format(
                    dtfilter)
        elif vendor:
            sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)".format(
                vendor)
        else:
            sql = "SELECT count(queue_id) as queue_id_count FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)"
        return sql

    ## Checking Queue normal filter data
    def checkingqueuewithouthaving(self, offset=None, length=None, dtfilter=None, vendor=None, sorting=None, direction=None,
                      custom_searchbox=None):
        if custom_searchbox:
            if sorting:
                if dtfilter and vendor:
                    sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                        dtfilter, vendor, custom_searchbox, custom_searchbox, custom_searchbox, sorting, direction, offset, length)
                elif dtfilter:
                    sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                        dtfilter, custom_searchbox, custom_searchbox, custom_searchbox, sorting, direction, offset, length)
                elif vendor:
                    sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                        dtfilter, custom_searchbox, custom_searchbox, custom_searchbox, sorting, direction, offset, length)
                else:
                    sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                        custom_searchbox, custom_searchbox, custom_searchbox, sorting, direction, offset, length)
            elif dtfilter and vendor:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    dtfilter, vendor, custom_searchbox, custom_searchbox, custom_searchbox, offset, length)
            elif vendor:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    vendor, custom_searchbox, custom_searchbox, custom_searchbox, offset, length)
            elif dtfilter:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    dtfilter, custom_searchbox, custom_searchbox, custom_searchbox, offset, length)
            else:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND (batch_id LIKE '{}%' OR CONVERT (varchar(10),queue_date ,110) LIKE '{}%' OR vendor LIKE '{}%') GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_searchbox, custom_searchbox, custom_searchbox, offset, length)
        elif sorting:
            if dtfilter and vendor:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    dtfilter, vendor, sorting, direction, offset, length)
            elif dtfilter:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    dtfilter, sorting, direction, offset, length)
            elif vendor:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    vendor, sorting, direction, offset, length)
            else:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    sorting, direction, offset, length)
        elif dtfilter:
            if vendor:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    dtfilter, vendor, offset, length)
            else:
                sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    dtfilter, offset, length)
        elif vendor:
            sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                vendor, offset, length)
        else:
            sql = "SELECT batch_id, queue_id, CONVERT (varchar(10),queue_date ,110) 'queue_date', count(queue_id) as queue_id_count, vendor, count(case when status = 'Invalid' OR status = 'Bad' OR status = 'Error' OR status = 'Negative Balance' then 1 else null end) as status_count, count(case when check_balance_status = 'checked' then 1 else null end) as balance_status_count, sum(new_money) as new_money FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) ORDER BY queue_id DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                offset, length)
        return sql

    def checkingqueueselectallwithhaving(self, havingquery=None, dtfilter=None, vendor=None, array=None):
        if array:
            if dtfilter and vendor:
                sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(
                    dtfilter, vendor, array, havingquery)
            elif dtfilter:
                sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(
                     dtfilter, array, havingquery)
            elif vendor:
                sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(
                     vendor, array, havingquery)
            else:
                sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(
                    array, havingquery)
        elif dtfilter:
            if vendor:
                sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(
                        dtfilter, vendor, havingquery)
            else:
                sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(
                        dtfilter, havingquery)
        elif vendor:
            sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(
                vendor, havingquery)
        else:
            sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110) HAVING {}".format(havingquery)
        return sql

    def checkingqueueselectallwithouthaving(self, dtfilter=None, vendor=None, array=None):
        if array:
            if dtfilter and vendor:
                sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)".format(
                    dtfilter, vendor, array)
            elif dtfilter:
                sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)".format(
                     dtfilter, array)
            elif vendor:
                sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)".format(
                     vendor, array)
            else:
                sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)".format(
                    array)
        elif dtfilter:
            if vendor:
                sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)".format(
                        dtfilter, vendor)
            else:
                sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where {} AND [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)".format(
                        dtfilter)
        elif vendor:
            sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)".format(
                vendor)
        else:
            sql = "SELECT [giftcardlist].queue_id as id FROM [dbo].[giftcardlist] where [giftcardlist].queue_status='que' GROUP BY queue_id, vendor, batch_id, CONVERT (varchar(10),queue_date ,110)"
        return sql

class CheckingQueueDetailsClass:
    ## Checking Queue filter range using custom filter count with having condition
    def checkingqueuedetailcountwithhaving(self, havingquery=None, queue_id=None, status=None,
                                     custom_searchbox=None):
        if custom_searchbox:
            if status:
                sql = "SELECT count([giftcardlist].gift_card_no) FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} AND (giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR  CONVERT (varchar(10), last_check,110) LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%') GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {}".format(
                    queue_id, status, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox, havingquery)
            else:
                sql = "SELECT count([giftcardlist].gift_card_no) FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND (giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR  CONVERT (varchar(10), last_check,110) LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%') GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {}".format(
                    queue_id, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox, havingquery)
        elif status:
            sql = "SELECT count([giftcardlist].gift_card_no) FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {}".format(queue_id,status, havingquery)
        else:
            sql = "SELECT count([giftcardlist].gift_card_no) FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {}".format(queue_id, havingquery)
        return sql

    ## Checking Queue filter range using custom filter data with having condition
    def checkingqueuedetailwithhaving(self, havingquery=None, offset=None, length=None, queue_id=None, status=None,
                                sorting=None, direction=None, custom_searchbox=None):
        if custom_searchbox:
            if sorting:
                if status:
                    sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} AND (giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR  CONVERT (varchar(10), last_check,110) LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%') GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                        queue_id, status, custom_searchbox, custom_searchbox,
                        custom_searchbox, custom_searchbox, custom_searchbox,
                        custom_searchbox, custom_searchbox, havingquery, sorting, direction, offset, length)
                else:
                    sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND (giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR  CONVERT (varchar(10), last_check,110) LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%') GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                        queue_id, custom_searchbox, custom_searchbox,
                        custom_searchbox, custom_searchbox, custom_searchbox,
                        custom_searchbox, custom_searchbox, havingquery, sorting, direction, offset, length)
            elif status:
                sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} AND (giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR  CONVERT (varchar(10), last_check,110) LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%') GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {} ORDER BY max(queue_date) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    queue_id, status, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox, havingquery, offset, length)
            else:
                sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND (giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR  CONVERT (varchar(10), last_check,110) LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%') GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {} ORDER BY max(queue_date) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    queue_id, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox, havingquery, offset, length)
        elif sorting:
            if status:
                sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value  FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    queue_id, status, havingquery, sorting, direction, offset, length)
            else:
                sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value  FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    queue_id, havingquery, sorting, direction, offset, length)
        elif status:
            sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value  FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {} ORDER BY max(queue_date) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                queue_id, status, havingquery, offset, length)
        else:
            sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value  FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {} ORDER BY max(queue_date) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                queue_id, havingquery, offset, length)
        return sql

    ## Checking Queue normal filter count
    def checkingqueuedetailcountwithouthaving(self, queue_id=None, status=None, custom_searchbox=None):
        if custom_searchbox:
            if status:
                sql = "SELECT count([giftcardlist].gift_card_no) FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} AND (giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR  CONVERT (varchar(10), last_check,110) LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%') GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110)".format(
                    queue_id, status, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox)
            else:
                sql = "SELECT count([giftcardlist].gift_card_no) FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND (giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR  CONVERT (varchar(10), last_check,110) LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%') GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110)".format(
                    queue_id, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox)
        elif status:
            sql = "SELECT count([giftcardlist].gift_card_no) FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110)".format(queue_id,status)
        else:
            sql = "SELECT count([giftcardlist].gift_card_no) FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110)".format(queue_id)
        return sql

    ## Checking Queue normal filter data
    def checkingqueuedetailwithouthaving(self, offset=None, length=None, queue_id=None, status=None, sorting=None,
                                   direction=None,
                                   custom_searchbox=None):
        if custom_searchbox:
            if sorting:
                if status:
                    sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} AND (giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR  CONVERT (varchar(10), last_check,110) LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%') GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                        queue_id, status, custom_searchbox, custom_searchbox,
                        custom_searchbox, custom_searchbox, custom_searchbox,
                        custom_searchbox, custom_searchbox, sorting, direction, offset, length)
                else:
                    sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND (giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR  CONVERT (varchar(10), last_check,110) LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%') GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                        queue_id, custom_searchbox, custom_searchbox,
                        custom_searchbox, custom_searchbox, custom_searchbox,
                        custom_searchbox, custom_searchbox, sorting, direction, offset, length)
            elif status:
                sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} AND (giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR  CONVERT (varchar(10), last_check,110) LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%') GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) ORDER BY max(queue_date) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    queue_id, status, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox, offset, length)
            else:
                sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND (giftcardlist.vendor LIKE '{}%' OR giftcardlist.gift_card_no LIKE '{}%' OR giftcardlist.gift_card_pin LIKE '{}%' OR giftcardlist.status LIKE '{}%' OR giftcardlist.balance LIKE '{}%' OR  CONVERT (varchar(10), last_check,110) LIKE '{}%' OR giftcardlist.gift_card_value LIKE '{}%') GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) ORDER BY max(queue_date) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    queue_id, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox, custom_searchbox,
                    custom_searchbox, custom_searchbox, offset, length)
        elif sorting:
            if status:
                sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value  FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    queue_id, status, sorting, direction, offset, length)
            else:
                sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value  FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    queue_id, sorting, direction, offset, length)
        elif status:
            sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value  FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) ORDER BY max(queue_date) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                queue_id, status, offset, length)
        else:
            sql = "SELECT queue_id, CONVERT (varchar(10),queue_date,110) 'queue_date', CONVERT (varchar(10),giftcardlist.last_check,110) 'last_used', giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], sum(case when order_purchase_status is not null then 1 else 0 end) as no_of_order, giftcardlist.gift_card_value  FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) ORDER BY max(queue_date) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                queue_id, offset, length)
        return sql

    ## Checking Queue select all functionality with having condtion
    def checkingqueuedetailselectallwithhaving(self, havingquery=None, queue_id=None, status=None, array=None):
        if array:
            if status:
                sql = "SELECT [giftcardlist].id FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {}".format(
                    queue_id, status, array, havingquery)
            else:
                sql = "SELECT [giftcardlist].id FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {}".format(
                    queue_id, array, havingquery)
        elif status:
            sql = "SELECT [giftcardlist].id FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {}".format(
                queue_id, status, havingquery)
        else:
            sql = "SELECT [giftcardlist].id FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110) HAVING {}".format(
                queue_id, havingquery)
        return sql

    ## Checking Queue select all functionality without having condtion
    def checkingqueuedetailselectallwithouthaving(self, queue_id=None, status=None, array=None):
        if array:
            if status:
                sql = "SELECT [giftcardlist].id FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110)".format(
                    queue_id, status, array)
            else:
                sql = "SELECT [giftcardlist].id FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110)".format(
                    queue_id, array)
        elif status:
            sql = "SELECT [giftcardlist].id FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110)".format(
                queue_id, status)
        else:
            sql = "SELECT [giftcardlist].id FROM [dbo].[giftcardlist] LEFT JOIN [dbo].[giftcardtransaction] ON [dbo].[giftcardlist].gift_card_no = [dbo].[giftcardtransaction].giftcard_number where [giftcardlist].queue_status='que' AND {} GROUP BY queue_id, giftcardlist.vendor, giftcardlist.gift_card_no, giftcardlist.gift_card_pin, giftcardlist.status, giftcardlist.balance, giftcardlist.[id], giftcardlist.gift_card_value, CONVERT (varchar(10),queue_date,110), CONVERT (varchar(10),giftcardlist.last_check,110)".format(
                queue_id)
        return sql

class CatalogueBuy():
    def cataloguecount(self, custom_query=None):
        if custom_query is not None and custom_query != '':
            sql = "SELECT count(id) FROM [dbo].[buycatalogue] WHERE {}".format(custom_query)
        else:
            sql = "SELECT count(id) FROM [dbo].[buycatalogue]"
        return sql

    def cataloguedata(self, offset=None, length=None, custom_query=None,
                               sorting=None, direction=None):
        if sorting:
            if custom_query is not None and custom_query != '':
                sql = "SELECT id, [image_url], [modal_no], [sku], [upc], [sale_price], [regular_price], [product_name], [available], [brand_name], [short_desc], [long_desc], CONVERT (varchar(10),[Date_creation],110) dateCreation, [was_price], [amazon_price], [referal_fee], [FBA_fee], [watch_price], [category], [sub_category], [url_info], [profit], [profit_amt], [dollersave], [percentsave], [asin], [amazon_sale_rank], [amazon_price_history], [amazon_sale_rank_history], [buybox] FROM [dbo].[buycatalogue] WHERE {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_query, sorting, direction, offset, length)
            else:
                sql = "SELECT id, [image_url], [modal_no], [sku], [upc], [sale_price], [regular_price], [product_name], [available], [brand_name], [short_desc], [long_desc], CONVERT (varchar(10),[Date_creation],110) dateCreation, [was_price], [amazon_price], [referal_fee], [FBA_fee], [watch_price], [category], [sub_category], [url_info], [profit], [profit_amt], [dollersave], [percentsave], [asin], [amazon_sale_rank], [amazon_price_history], [amazon_sale_rank_history], [buybox] FROM [dbo].[buycatalogue] ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    sorting, direction, offset, length)
        elif custom_query is not None and custom_query != '':
            sql = "SELECT id, [image_url], [modal_no], [sku], [upc], [sale_price], [regular_price], [product_name], [available], [brand_name], [short_desc], [long_desc], CONVERT (varchar(10),[Date_creation],110) dateCreation, [was_price], [amazon_price], [referal_fee], [FBA_fee], [watch_price], [category], [sub_category], [url_info], [profit], [profit_amt], [dollersave], [percentsave], [asin], [amazon_sale_rank], [amazon_price_history], [amazon_sale_rank_history], [buybox] FROM [dbo].[buycatalogue] WHERE {} ORDER BY available DESC, profit DESC, Date_creation DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, offset, length)
        else:
            sql = "SELECT id, [image_url], [modal_no], [sku], [upc], [sale_price], [regular_price], [product_name], [available], [brand_name], [short_desc], [long_desc], CONVERT (varchar(10),[Date_creation],110) dateCreation, [was_price], [amazon_price], [referal_fee], [FBA_fee], [watch_price], [category], [sub_category], [url_info], [profit], [profit_amt], [dollersave], [percentsave], [asin], [amazon_sale_rank], [amazon_price_history], [amazon_sale_rank_history], [buybox] FROM [dbo].[buycatalogue] ORDER BY available DESC, profit DESC, Date_creation DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                offset, length)
        return sql

class WatchListCatalogue():
    def watchlistcount(self, custom_query=None):
        sql = "SELECT count(id) FROM [dbo].[buycatalogue] WHERE is_watching = 1"
        return sql

    def watchlistdata(self, offset=None, length=None):
        sql = "SELECT id, [image_url], [modal_no], [sku], [upc], [sale_price], [regular_price], [product_name], [available], [brand_name], [short_desc], [long_desc], CONVERT (varchar(10),[Date_creation],110) dateCreation, [was_price], [amazon_price], [referal_fee], [FBA_fee], [watch_price], [category], [sub_category], [url_info], [profit], [profit_amt], [dollersave], [percentsave], [asin], [amazon_sale_rank], [amazon_price_history], [amazon_sale_rank_history], [buybox] FROM [dbo].[buycatalogue] WHERE is_watching=1 ORDER BY available DESC, profit DESC, Date_creation DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                offset, length)
        return sql

class AdminCommission:
    def commissionforcountwithhaving(self, having_query=None, custom_query=None):
        if custom_query:
            sql = "SELECT count(DISTINCT order_number) as order_number FROM [dbo].[ordertracking] WHERE {} AND tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY DATEPART(WEEK,orderedDate), DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), comm_status HAVING {}".format(
                custom_query, having_query)
        else:
            sql = "SELECT count(DISTINCT order_number) as order_number FROM [dbo].[ordertracking] WHERE tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY DATEPART(WEEK,orderedDate), DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), comm_status HAVING {}".format(
                having_query)
        return sql

    def commissionforquerywithhaving(self, offset=None, length=None, having_query=None, custom_query=None, custom_sorting=None, custom_direction=None):
        if custom_sorting:
            if custom_query:
                sql = "SELECT DATEPART(wk,orderedDate) as week_count, CONVERT(varchar, DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), 101) weekstart, CONVERT(varchar, DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), 101) weekend, count(DISTINCT order_number) as order_number, sum(qty_cart) as total_item, sum(price*qty_cart) as total_amount, round(sum(price*qty_cart)/100,2) as commision, comm_status FROM [dbo].[ordertracking] WHERE {} AND tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY DATEPART(WEEK,orderedDate), DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), comm_status HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_query, having_query, custom_sorting, custom_direction, offset, length)
            else:
                sql = "SELECT DATEPART(wk,orderedDate) as week_count, CONVERT(varchar, DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), 101) weekstart, CONVERT(varchar, DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), 101) weekend, count(DISTINCT order_number) as order_number, sum(qty_cart) as total_item, sum(price*qty_cart) as total_amount, round(sum(price*qty_cart)/100,2) as commision, comm_status FROM [dbo].[ordertracking] WHERE tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY DATEPART(WEEK,orderedDate), DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), comm_status HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    having_query, custom_sorting, custom_direction, offset, length)
        elif custom_query:
            sql = "SELECT DATEPART(wk,orderedDate) as week_count, CONVERT(varchar, DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), 101) weekstart, CONVERT(varchar, DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), 101) weekend, count(DISTINCT order_number) as order_number, sum(qty_cart) as total_item, sum(price*qty_cart) as total_amount, round(sum(price*qty_cart)/100,2) as commision, comm_status FROM [dbo].[ordertracking] WHERE {} AND tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY DATEPART(WEEK,orderedDate), DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), comm_status HAVING {} ORDER BY max(orderedDate) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, having_query, offset, length)
        else:
            sql = "SELECT DATEPART(wk,orderedDate) as week_count, CONVERT(varchar, DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), 101) weekstart, CONVERT(varchar, DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), 101) weekend, count(DISTINCT order_number) as order_number, sum(qty_cart) as total_item, sum(price*qty_cart) as total_amount, round(sum(price*qty_cart)/100,2) as commision, comm_status FROM [dbo].[ordertracking] WHERE tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY DATEPART(WEEK,orderedDate), DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), comm_status HAVING {} ORDER BY max(orderedDate) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                having_query, offset, length)
        return sql

    def commissionforcount(self, custom_query=None):
        if custom_query:
            sql = "SELECT count(DISTINCT order_number) as order_number FROM [dbo].[ordertracking] WHERE {} AND tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY DATEPART(WEEK,orderedDate), DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), comm_status".format(
                custom_query)
        else:
            sql = "SELECT count(DISTINCT order_number) as order_number FROM [dbo].[ordertracking] WHERE tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY DATEPART(WEEK,orderedDate), DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), comm_status"
        return sql

    def commissionforquery(self, offset=None, length=None, custom_query=None, custom_sorting=None, custom_direction=None):
        if custom_sorting:
            if custom_query:
                sql = "SELECT DATEPART(wk,orderedDate) as week_count, CONVERT(varchar, DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), 101) weekstart, CONVERT(varchar, DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), 101) weekend, count(DISTINCT order_number) as order_number, sum(qty_cart) as total_item, sum(price*qty_cart) as total_amount, round(sum(price*qty_cart)/100,2) as commision, comm_status FROM [dbo].[ordertracking] WHERE {} AND tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY DATEPART(WEEK,orderedDate), DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), comm_status ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_query, custom_sorting, custom_direction, offset, length)
            else:
                sql = "SELECT DATEPART(wk,orderedDate) as week_count, CONVERT(varchar, DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), 101) weekstart, CONVERT(varchar, DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), 101) weekend, count(DISTINCT order_number) as order_number, sum(qty_cart) as total_item, sum(price*qty_cart) as total_amount, round(sum(price*qty_cart)/100,2) as commision, comm_status FROM [dbo].[ordertracking] WHERE tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY DATEPART(WEEK,orderedDate), DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), comm_status ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_sorting, custom_direction, offset, length)
        elif custom_query:
            sql = "SELECT DATEPART(wk,orderedDate) as week_count, CONVERT(varchar, DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), 101) weekstart, CONVERT(varchar, DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), 101) weekend, count(DISTINCT order_number) as order_number, sum(qty_cart) as total_item, sum(price*qty_cart) as total_amount, round(sum(price*qty_cart)/100,2) as commision, comm_status FROM [dbo].[ordertracking] WHERE {} AND tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY DATEPART(WEEK,orderedDate), DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), comm_status ORDER BY max(orderedDate) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, offset, length)
        else:
            sql = "SELECT DATEPART(wk,orderedDate) as week_count, CONVERT(varchar, DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), 101) weekstart, CONVERT(varchar, DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), 101) weekend, count(DISTINCT order_number) as order_number, sum(qty_cart) as total_item, sum(price*qty_cart) as total_amount, round(sum(price*qty_cart)/100,2) as commision, comm_status FROM [dbo].[ordertracking] WHERE tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY DATEPART(WEEK,orderedDate), DATEADD(dd, -(DATEPART(dw, CONVERT(varchar, orderedDate, 101))-1), CONVERT(varchar, orderedDate, 101)), DATEADD(dd, 7-(DATEPART(dw, CONVERT(varchar, orderedDate, 101))), CONVERT(varchar, orderedDate, 101)), comm_status ORDER BY max(orderedDate) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                offset, length)
        return sql

class AdminCommissionDetails:
    def commissiondetailforcountwithhaving(self, having_query=None, custom_query=None):
        sql = "SELECT count(order_number) FROM [dbo].[ordertracking] WHERE {} AND tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY order_number, item_sku, title, price, qty_cart HAVING {}".format(
            custom_query, having_query)
        return sql

    def commissiondetailforquerywithhaving(self, offset=None, length=None, having_query=None, custom_query=None, custom_sorting=None, custom_direction=None):
        if custom_sorting:
            sql = "SELECT CONVERT(varchar, orderedDate, 101) as dateCreation, order_number, item_sku, title, price, qty_cart, (price*qty_cart) as subtotal, tracking_status FROM [dbo].[ordertracking] WHERE {} AND tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY order_number, item_sku, title, price, qty_cart, CONVERT(varchar, orderedDate, 101), tracking_status HAVING {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, having_query, custom_sorting, custom_direction, offset, length)
        else:
            sql = "SELECT CONVERT(varchar, orderedDate, 101) as dateCreation, order_number, item_sku, title, price, qty_cart, (price*qty_cart) as subtotal, tracking_status FROM [dbo].[ordertracking] WHERE {} AND tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY order_number, item_sku, title, price, qty_cart, CONVERT(varchar, orderedDate, 101), tracking_status HAVING {} ORDER BY max(orderedDate) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, having_query, offset, length)
        return sql

    def commissiondetailforcount(self, custom_query=None):
        sql = "SELECT count(order_number) FROM [dbo].[ordertracking] WHERE {} AND tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY order_number, item_sku, title, price, qty_cart".format(
            custom_query)
        return sql

    def commissiondetailforquery(self, offset=None, length=None, custom_query=None, custom_sorting=None, custom_direction=None):
        if custom_sorting:
            sql = "SELECT CONVERT(varchar, orderedDate, 101) as dateCreation, order_number, item_sku, title, price, qty_cart, (price*qty_cart) as subtotal, tracking_status FROM [dbo].[ordertracking] WHERE {} AND tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY order_number, item_sku, title, price, qty_cart, CONVERT(varchar, orderedDate, 101), tracking_status ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, custom_sorting, custom_direction, offset, length)
        else:
            sql = "SELECT CONVERT(varchar, orderedDate, 101) as dateCreation, order_number, item_sku, title, price, qty_cart, (price*qty_cart) as subtotal, tracking_status FROM [dbo].[ordertracking] WHERE {} AND tracking_status not in ('Cancelled','Processed','Ordered') GROUP BY order_number, item_sku, title, price, qty_cart, CONVERT(varchar, orderedDate, 101), tracking_status ORDER BY max(orderedDate) DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                custom_query, offset, length)
        return sql

class NotificationList:
    def notificationqueryforcount(self, custom_query=None):
        if custom_query:
            sql = "SELECT count(id) as count FROM [dbo].[notification] WHERE {}".format(
                custom_query)
        else:
            sql = "SELECT count(id) as count FROM [dbo].[notification]"
        return sql

    def notificationquery(self, offset=None, length=None, custom_query=None, custom_sorting=None, custom_direction=None):
        if custom_query:
            if custom_sorting:
                sql = "SELECT CONVERT(varchar, Date_creation, 101) as dateCreation, id, seen, message, order_number, status FROM [dbo].[notification] WHERE {} ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_query, custom_sorting, custom_direction, offset, length)
            else:
                sql = "SELECT CONVERT(varchar, Date_creation, 101) as dateCreation, id, seen, message, order_number, status FROM [dbo].[notification] WHERE {} ORDER BY Date_creation DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_query, offset, length)
        else:
            if custom_sorting:
                sql = "SELECT CONVERT(varchar, Date_creation, 101) as dateCreation, id, seen, message, order_number, status FROM [dbo].[notification] ORDER BY {} {} OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    custom_sorting, custom_direction, offset, length)
            else:
                sql = "SELECT CONVERT(varchar, Date_creation, 101) as dateCreation, id, seen, message, order_number, status FROM [dbo].[notification] ORDER BY Date_creation DESC OFFSET {} ROWS FETCH NEXT {} ROWS ONLY".format(
                    offset, length)
        return sql