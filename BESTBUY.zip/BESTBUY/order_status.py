import os
import re
import time
import json
import traceback
import unicodedata

import pandas as pd
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.proxy import Proxy, ProxyType
from selenium.webdriver.chrome.options import Options

DRIVER = 'EDGE'
DRIVER_PATH = 'msedgedriver.exe'


def get_driver_settings():
    DRIVER_SETTINGS = {}
    DRIVER_SETTINGS['DRIVER'] = DRIVER
    DRIVER_SETTINGS['DRIVER_PATH'] = DRIVER_PATH
    return DRIVER_SETTINGS

# def smartproxy():
#     prox = Proxy()
#     prox.proxy_type = ProxyType.MANUAL
#     prox.http_proxy = '{hostname}:{port}'.format(hostname=HOSTNAME, port=PORT)
#     prox.ssl_proxy = '{hostname}:{port}'.format(hostname=HOSTNAME, port=PORT)
#
#     if DRIVER == 'FIREFOX':
#         capabilities = webdriver.DesiredCapabilities.FIREFOX
#     elif DRIVER == 'CHROME':
#         capabilities = webdriver.DesiredCapabilities.CHROME
#     elif DRIVER == 'EDGE':
#         capabilities = webdriver.DesiredCapabilities.EDGE
#     prox.add_to_capabilities(capabilities)
#     return capabilities


def luminati():
    PROXY = '127.0.0.1:24000'
    proxy = Proxy()
    proxy.http_proxy = PROXY
    proxy.ftp_proxy = PROXY
    proxy.sslProxy = PROXY
    proxy.no_proxy = "localhost"  # etc... ;)
    proxy.proxy_type = ProxyType.MANUAL

    # limunati customer info
    proxy.socksUsername = 'lum-customer-c_513d0b61-zone-static'
    # proxy.socksPassword = "k9qkacyco59d" # mobile
    # proxy.socksPassword = "hvpm58f52si5"  # static_res
    # proxy.socksPassword = "rzmua35siw42"  # residential

    if DRIVER == 'FIREFOX':
        capabilities = webdriver.DesiredCapabilities.FIREFOX
    elif DRIVER == 'CHROME':
        capabilities = webdriver.DesiredCapabilities.CHROME
    elif DRIVER == 'EDGE':
        capabilities = webdriver.DesiredCapabilities.EDGE
    proxy.add_to_capabilities(capabilities)
    capabilities['acceptInsecureCerts'] = True
    capabilities['acceptSslCerts'] = True
    return capabilities


# df = pd.read_excel("Final Order.xlsx")
# final_df = pd.DataFrame(columns=df.columns.tolist() + ['No. of Shipments'])

# first_name = df['First Name']
# order_no = df['Order No.']
# last_name = df['Last Name']
# contact_no = df['Contact No.']
# status_list = []
# date_of_purchase = df['Date of Purchase']

# print(order_no, last_name, contact_no, status_list)

# browser.get("https://addons.mozilla.org/en-US/firefox/addon/smartproxyextension/?src=search")
# add_ext = browser.find_element_by_xpath('/html/body/div/div/div/div/div[2]/div[1]/section[1]/div/header/div[3]/div/div/a')
# add_ext.click()
# time.sleep(40)


def order_status(data,path):
    details = {}

    current_path = os.path.join(path,"chromedriver.exe")
    download_path = os.path.join(path,"report")
    download_path = os.path.join(download_path,"invocies")
    if not os.path.exists(download_path):
        os.makedirs(download_path)
    download_path = os.path.join(download_path, "")
    download_check = os.path.join(download_path, str(data['order_number'])+".pdf")
    delivery_sub_status = ""

    chrome_options = webdriver.ChromeOptions()
    settings = {
        "recentDestinations": [{
            "id": "Save as PDF",
            "origin": "local",
            "account": ""
        }],
        "selectedDestinationId": "Save as PDF",
        "version": 2,
        "isHeaderFooterEnabled": False,
        "customMargins": {},
        "marginsType": 2,
        "scaling": 100,
        "isCssBackgroundEnabled": False
    }
    prefs = {'printing.print_preview_sticky_settings.appState': json.dumps(settings),
             'savefile.default_directory': download_path}
    chrome_options.add_experimental_option('prefs', prefs)
    chrome_options.add_argument('--kiosk-printing')
    chrome_options.add_argument('--disable-dev-shm-usage')
    # browser = webdriver.Chrome(executable_path=current_path, desired_capabilities=luminati(),
    #                            options=chrome_options)
    browser = webdriver.Chrome(executable_path=current_path,
                               options=chrome_options)
    time.sleep(2)

    item_details = []
    try:
        details['order_number'] = data['order_number']
        browser.get('https://www.bestbuy.com/profile/ss/guestorderlookup')
        time.sleep(3)

        fill_order = browser.find_element_by_id('orderNumber-id')
        fill_order.send_keys(str(data['order_number']))
        # final_df.loc[i, 'Order No.'] = order_no[i]

        fill_last = browser.find_element_by_id('lastName-id')
        fill_last.send_keys(str(data['last_name']))
        # final_df.loc[i, 'Last Name'] = last_name[i]
        # final_df.loc[i, 'First Name'] = first_name[i]

        fill_contact = browser.find_element_by_id('phoneNumber-id')
        fill_contact.send_keys(str(data['mobile']))
        # final_df.loc[i, 'Contact No.'] = contact_no[i]

        browser.find_element_by_xpath('/html/body/main/div/div/div[1]/div/form/button').click()
        time.sleep(5)

        details['order_total'] = None
        details['products_total'] = None
        details['order_taxes'] = None
        details['shipping'] = None
        try:
            # purchase_date = browser.find_element_by_class_name(
            #     'order-details-summary__order-date.oss-col-l-3').text.replace('Purchase Date:', '')
            # print(purchase_date)
            # details['Purchase_Date'] = purchase_date
            try:
                if browser.find_element_by_class_name("order-details-summary__toggle.hidden-print").get_attribute('aria-expanded') == 'false':
                    browser.find_element_by_class_name('order-details-summary__toggle.hidden-print').click()
                    time.sleep(2)
            except:
                pass
            try:
                order_details = browser.find_element_by_class_name('order-details').find_element_by_class_name('order-summary')
                detail_fields = order_details.find_element_by_class_name('order-summary__content')
                soup = BeautifulSoup(detail_fields.get_attribute('innerHTML'), 'html.parser')
                product_total = soup.find('div', attrs={'data-test': 'product-total'}).text.replace("Product Total", '')
                order_shipping = soup.find('div', attrs={'data-test': 'shipping-total'}).text.replace("Shipping", '')
                order_tax = soup.find('div', attrs={'data-test': 'tax-fees-surcharges'}).text.replace(
                    "Sales Tax, Fees & Surcharges", '')
                order_total = soup.find('div', attrs={'data-test': 'order-total'}).text.replace("Order Total", '')
                details['products_total'] = float(product_total.replace('$', '').replace(',', ''))
                details['order_taxes'] = float(order_tax.replace('$', '').replace(',', ''))
                details['order_total'] = float(order_total.replace('$', '').replace(',', ''))
                details['shipping'] = order_shipping.replace('$', '').replace(',', '')
            except:
                pass

            delivery_list_group = browser.find_element_by_class_name('item-details')
            delivery_list = delivery_list_group.find_elements_by_class_name('fulfillment-group')

            for j, delivery_entry in enumerate(delivery_list):
                try:
                    sku_list = []
                    delivery = {}
                    # soup = BeautifulSoup(delivery_entry.get_attribute('innerHTML'), 'html.parser')
                    shipping_info = delivery_entry.find_element_by_class_name('fulfillment-tracker.oss-wrapper--l')
                    try:
                        heading = delivery_entry.find_element_by_class_name('fulfillment-group-header__heading').text
                        if re.search('Digital Item', heading):
                            raise Exception
                    except:
                        pass

                    delivery_status = shipping_info.find_element_by_class_name('fulfillment-status__text').find_element_by_class_name('customer-status-info-message').text
                    print(delivery_status)

                    delivery['tracking_status'] = None
                    delivery['tracking_number'] = None
                    delivery['carrier_name'] = None

                    try:
                        if re.search('Delivered', delivery_status, flags=re.IGNORECASE):
                            delivery['tracking_status'] = 'Delivered'
                            shipping_info.find_element_by_class_name(
                                'fulfillment-tracker__status-wrapper').find_element_by_tag_name('a').click()
                    except:
                        pass

                    try:
                        delivery_sub_status = shipping_info.find_element_by_class_name(
                            'status-description.fulfillment-tracker__status-description').find_element_by_class_name(
                            'customer-status-info-message').text
                        if delivery_sub_status in ['Shipped', 'In Transit', 'Delayed']:
                            delivery_sub_status = 'Shipped'
                        elif re.search('Delivered', delivery_sub_status, flags=re.IGNORECASE):
                            delivery_sub_status = 'Delivered'
                        elif 'canceled' in delivery_sub_status:
                            delivery_sub_status = 'Cancelled'
                        delivery['tracking_status'] = delivery_sub_status
                    except:
                        pass

                    try:
                        if shipping_info.find_element_by_class_name(
                                'tracker-details__control-container.hidden-print').find_element_by_class_name(
                                'tracker-control').get_attribute('aria-expanded') == 'false':
                            shipping_info.find_element_by_class_name(
                                'tracker-details__control-container.hidden-print').find_element_by_class_name(
                                'tracker-control').click()
                        time.sleep(1)
                        tracking_info = browser.find_element_by_class_name(
                            'tracker-details__content.row').find_element_by_class_name('tracking-number')
                        tracking_no = tracking_info.find_element_by_tag_name('a').text
                        delivery['tracking_number'] = tracking_no
                        tracking_history = tracking_info.find_element_by_tag_name('a').get_attribute('href')
                        delivery['carrier_name'] = re.search('carrier=(.*?)$', tracking_history, flags=re.DOTALL).group(
                            1)
                    except Exception as e:
                        print(e)

                    items = delivery_entry.find_elements_by_class_name('fulfillment-item-row')
                    for item in items:
                        skus = {}
                        skus['sku'] = None
                        skus['qty'] = None
                        skus['item_total'] = None
                        skus['item_price'] = None
                        skus['item_tax'] = None
                        soup = BeautifulSoup(item.get_attribute('innerHTML'), 'html.parser')
                        sku = soup.find('span', attrs={'data-test': 'item-sku'}).text.replace("SKU:", '')
                        quantity = soup.find('span', attrs={'data-test': 'item-quantity'}).text.replace("Quantity:", '')
                        item_total = soup.find('div', attrs={'data-test': 'item-total'}).text.replace("Item Total:", '')
                        item_price = soup.find('div', attrs={'data-test': 'item-product-price'}).text.replace(
                            "Product Price:", '')
                        item_tax = soup.find('div', attrs={'data-test': 'item-total-tax-and-surcharges'}).text.replace(
                            "Sales Tax, Fees & Surcharges:", '')
                        print(sku, quantity)
                        skus['sku'] = sku
                        skus['qty'] = quantity
                        skus['item_total'] = item_total.replace('$', '')
                        skus['item_price'] = item_price.replace('$', '')
                        skus['item_tax'] = item_tax.replace('$', '')
                        sku_list.append(skus)

                    delivery['sku_no'] = sku_list

                except Exception as z:
                    traceback.print_tb(z.__traceback__)
                    print(z)

                item_details.append(delivery)

        except Exception as e:
            traceback.print_tb(e.__traceback__)
            print(e)

    except Exception as e:
        traceback.print_tb(e.__traceback__)
        print(e)

    if delivery_sub_status == 'Delivered' or delivery_sub_status == 'Cancelled' or delivery_sub_status == 'Shipped':
        is_download = True
        if os.path.exists(download_check):
            if delivery_sub_status != 'Delivered' and delivery_sub_status != 'Cancelled':
                os.remove(download_check)
            else:
                is_download = False
        if is_download:
            a = ActionChains(browser)
            a.key_down(Keys.CONTROL).send_keys('P').key_up(Keys.CONTROL).perform()
            browser.execute_script('window.print();')
            os.rename(download_path + r'Best Buy Order Details.pdf', download_path + f'{str(data["order_number"])}.pdf')

    browser.delete_all_cookies()
    browser.quit()
    details['items'] = item_details
    return details

# in_data = {
# "order_number": "BBY01-806282707265",
# "last_name": "Mauricio",
# "mobile": "9817667660"
# }
# print(order_status(in_data))