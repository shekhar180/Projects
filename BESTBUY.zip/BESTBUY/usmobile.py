from flask import Flask, flash, render_template, request, session, redirect, url_for, make_response, jsonify, send_file, Response
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
import pyodbc
import random

app = Flask(__name__)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# app.config['SQLALCHEMY_DATABASE_URI'] = "mssql+pyodbc://bestbuy_db:akash$123654@WIN-CCDM0AMH1KS/bestbuymaster?driver=SQL+Server"
app.config['SQLALCHEMY_DATABASE_URI'] = "mssql+pyodbc://DESKTOP-DV8PF1D/bestbuymaster?driver=SQL+Server"
db = SQLAlchemy(app)

condb = pyodbc.connect("Driver={SQL Server};"
                       "Server=DESKTOP-DV8PF1D;"
                       "Database=bestbuymaster;"
                       )

def randomDigits(digits):
    lower = 10**(digits-1)
    upper = 10**digits - 1
    return random.randint(lower, upper)

def randomNumber():
    word = ['981766','858944','217231','935874','669257','417402','465479','858395','583783','727760','808658','892590','826255','867845','444555','648496','382851','285706','473933','858225','727265','473421','720818','833481','494754','834987','826488','826225','324820','948564','431712','840713','863225','998380','222603','902585','362232','844444','876417','561759','561225','411841','928862','898225','858276','428881','430949','872225','585589','658867','521379','510256','498224','340943','785292','849390','763225','310730','512589','706996','802839','778632','322225','367834','503779','595395','927225','637256','979471','856225','272225','954225','393724','785474','403300','274424','392373','724500','675688','949362','798232','756410','819446','253398','224225','971252','921225','572210','492260','856098','626212','856513','766412','508219','787388','826698','477669','362213','276225','459781','758310','882225','829706','923405','255225','369317','608579','267519','703332','577322','620225','579710','743225','717309','662280','330535','269874','759284','889250','839299','286250','851610','279879','936251','785757','600354','898643','766250','873547','720205','872811','776251','94743','252752','637362','434770','370373','231505','347273','462225','551791','608411','517318','134408','683225','302245','634339','236768','712478','793102','394714','589642','974798','427583','402183','740250','776250']
    word_coice = random.choice(word)
    return ("{0}{1}").format(word_coice, randomDigits(4))

cursor = condb.cursor()
insert_record = 0
mobile_list = []
for i in range(0,10000):
    mobile_number = randomNumber()

    if mobile_number not in mobile_list:
        mobile_list.append(mobile_number)
    sql = "If Not Exists(select id from [dbo].[phonenumber] where phone=?) Begin INSERT INTO [dbo].[phonenumber] (phone, status, Date_creation) VALUES(?,?,?) End"
    value = [mobile_number,mobile_number,'Active',datetime.now()]
    cursor.execute(sql, value)
    count = cursor.rowcount
    if count > 0:
        cursor.commit()
        insert_record +=1

print("Record inserted phone number - "+str(insert_record))
print("Total mobile number generated for ",len(mobile_list))
print("Total mobile number ",mobile_list)

# print([randomNumber() for i in range(0,100)])
