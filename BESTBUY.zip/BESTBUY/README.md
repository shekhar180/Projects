# BBCRM
```
url - http://188.227.106.114:8080/
```

```
url - http://45.138.27.169:8080/
```

```
url - http://45.138.26.88:8080/
```

```1. Environment -```
- Python version - 3.8.5
- pip install -r requirements.txt

```2. Database -```
- SQL Server 15 or above
- First install sql server - https://www.microsoft.com/en-us/sql-server/sql-server-downloads
- Second install management studio - https://docs.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms?view=sql-server-ver15

```
**Deploy application on IIS server**
```
1. For fresh machine First we need to configure IIS server using through following steps
-  On start menu search **Server Manager** then click on **"Add roles and features"**
-  Next -> Next -> Next
-  Click on checkbox -
   -  [x] Web Server IIS 16, 
   -  [x] Windows deployement services, 
   -  [x] Windows server update.
   -  For cgi file click on inside checkbox in Web server IIS 16

2. Now install python and sql server as per above details

3. After installation of software and server configuration see the file location on c drive **inetbub-> wwwroot -> "Our Application Packages"** 'ex - C:\inetpub\wwwroot'

4. Now open IIS server using search start menu opetion IIS manager then click on following process for deploy flask application 
   - Click on server -> click on sites -> right click on sites -> Add new website -> Site: "BBCRM" -> Phycal path: **"C:\inetpub\wwwroot\BBCRM\"**
      -> port: 8080 -> click on Ok Button with checked 'Start website immediately' option
   - Now click on "Handler Mapping Icon" -> click on "Add Module Mapping" -> Requested Path: * -> Module -> FastCgiModule -> Executable (Opetional): **"C:\Program Files\Python\python.exe"|C:\inetpub\wwwroot\BBCRM\wfastcgi.py** -> Name: FastCGI -> Request Restriction **Unchecked** -> **Ok.**
   - Now set mapping configuration for FASTCGI Setting -> Click on Add Application -> Enviorment variable select -> Name: PYTHONPATH, Value: C:\inetpub\wwwroot\BBCRM\ -> Name: WSGI_HANDLER, Value: app.app -> **Ok.**

5. For inbount rules for port number using firewall setting allow port number

6. Now for create database user for access outside annonomous user using MS Management Studio create user role and set the database details in our application path.


```
Selenium Script Setup
```
1. Enviornment
   - Python version 3.8
   - Webdriver use - Chrome/Microsoft Eadge (As per browser)

2. Script Setup
   - Set path of webdriver in python script
   - Run script

3. Windows Task Scheduler
   - Create a task and name of task
   - Action tab click on new
   - Add python executable path 
   - Trigger python script
   - for more ref visit - https://www.jcchouinard.com/python-automation-using-task-scheduler/
