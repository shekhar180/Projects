import os
import re
import time
import traceback
import unicodedata

import pandas as pd
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.proxy import Proxy, ProxyType
from selenium.webdriver.chrome.options import Options

DRIVER = 'EDGE'
DRIVER_PATH = 'msedgedriver.exe'


def get_driver_settings():
    DRIVER_SETTINGS = {}
    DRIVER_SETTINGS['DRIVER'] = DRIVER
    DRIVER_SETTINGS['DRIVER_PATH'] = DRIVER_PATH
    return DRIVER_SETTINGS

# def smartproxy():
#     prox = Proxy()
#     prox.proxy_type = ProxyType.MANUAL
#     prox.http_proxy = '{hostname}:{port}'.format(hostname=HOSTNAME, port=PORT)
#     prox.ssl_proxy = '{hostname}:{port}'.format(hostname=HOSTNAME, port=PORT)
#
#     if DRIVER == 'FIREFOX':
#         capabilities = webdriver.DesiredCapabilities.FIREFOX
#     elif DRIVER == 'CHROME':
#         capabilities = webdriver.DesiredCapabilities.CHROME
#     elif DRIVER == 'EDGE':
#         capabilities = webdriver.DesiredCapabilities.EDGE
#     prox.add_to_capabilities(capabilities)
#     return capabilities


def luminati():
    PROXY = '127.0.0.1:24000'
    proxy = Proxy()
    proxy.http_proxy = PROXY
    proxy.ftp_proxy = PROXY
    proxy.sslProxy = PROXY
    proxy.no_proxy = "localhost"  # etc... ;)
    proxy.proxy_type = ProxyType.MANUAL

    # limunati customer info
    proxy.socksUsername = 'lum-customer-c_513d0b61-zone-static'
    # proxy.socksPassword = "k9qkacyco59d" # mobile
    # proxy.socksPassword = "hvpm58f52si5"  # static_res
    # proxy.socksPassword = "rzmua35siw42"  # residential

    if DRIVER == 'FIREFOX':
        capabilities = webdriver.DesiredCapabilities.FIREFOX
    elif DRIVER == 'CHROME':
        capabilities = webdriver.DesiredCapabilities.CHROME
    elif DRIVER == 'EDGE':
        capabilities = webdriver.DesiredCapabilities.EDGE
    proxy.add_to_capabilities(capabilities)
    capabilities['acceptInsecureCerts'] = True
    capabilities['acceptSslCerts'] = True
    return capabilities


# df = pd.read_excel("Final Order.xlsx")
# final_df = pd.DataFrame(columns=df.columns.tolist() + ['No. of Shipments'])

# first_name = df['First Name']
# order_no = df['Order No.']
# last_name = df['Last Name']
# contact_no = df['Contact No.']
# status_list = []
# date_of_purchase = df['Date of Purchase']

# print(order_no, last_name, contact_no, status_list)

# browser.get("https://addons.mozilla.org/en-US/firefox/addon/smartproxyextension/?src=search")
# add_ext = browser.find_element_by_xpath('/html/body/div/div/div/div/div[2]/div[1]/section[1]/div/header/div[3]/div/div/a')
# add_ext.click()
# time.sleep(40)


def order_status(data,path):
    details = {}
    current_path = os.path.join(path,"chromedriver.exe")
    # current_path = os.path.join(path, DRIVER_PATH)
    print(current_path)
    chrome_options = Options()
    # chrome_options.add_argument('--headless')
    # chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')

    browser = webdriver.Chrome(executable_path=current_path,chrome_options=chrome_options)
    time.sleep(2)

    try:
        browser.get('https://www.bestbuy.com/profile/ss/guestorderlookup')
        time.sleep(3)

        fill_order = browser.find_element_by_id('orderNumber-id')
        fill_order.send_keys(str(data['order_number']))
        # final_df.loc[i, 'Order No.'] = order_no[i]

        fill_last = browser.find_element_by_id('lastName-id')
        fill_last.send_keys(str(data['last_name']))
        # final_df.loc[i, 'Last Name'] = last_name[i]
        # final_df.loc[i, 'First Name'] = first_name[i]

        fill_contact = browser.find_element_by_id('phoneNumber-id')
        fill_contact.send_keys(str(data['mobile']))
        # final_df.loc[i, 'Contact No.'] = contact_no[i]

        browser.find_element_by_xpath('/html/body/main/div/div/div[1]/div/form/button').click()
        time.sleep(5)

        try:
            delivery_status_list = []
            address_list = []
            sku_list = []
            quantity_list = []

            purchase_date = browser.find_element_by_class_name(
                'order-details-summary__order-date.oss-col-l-3').text.replace('Purchase Date:', '')
            print(purchase_date)

            delivery_list_group = browser.find_element_by_class_name('item-details')
            delivery_list = delivery_list_group.find_elements_by_class_name('fulfillment-group')

            for delivery_entry in delivery_list:
                try:
                    soup = BeautifulSoup(delivery_entry.get_attribute('innerHTML'), 'html.parser')
                    shipping_info = delivery_entry.find_element_by_class_name('fulfillment-tracker.oss-wrapper--l')
                    try:
                        heading = delivery_entry.find_element_by_class_name('fulfillment-group-header__heading').text
                        if re.search('Digital Item', heading):
                            raise Exception
                    except:
                        pass

                    delivery_status = shipping_info.find_element_by_class_name('customer-status-info-message').text
                    print(delivery_status)
                    delivery_status_list.append(delivery_status)

                    name = soup.find('div', attrs={'data-test': 'address-name'})
                    address_line = name.find_next_sibling('div')
                    try:
                        address_line_1 = address_line.find('div', attrs={'data-test': 'address-line1'}).text
                    except:
                        address_line_1 = ''
                    try:
                        address_line_2 = address_line.find('div', attrs={'data-test': 'address-line2'}).text
                    except:
                        address_line_2 = ''
                    try:
                        address_line_3 = address_line.find('div', attrs={'data-test': 'address-line3'}).text
                    except:
                        address_line_3 = ''
                    address_unicode = ' '.join([address_line_1, address_line_2, address_line_3])
                    name = name.text
                    address = unicodedata.normalize("NFKD", address_unicode)
                    print(name, address)
                    address_list.append(address)

                    items = delivery_entry.find_elements_by_class_name('fulfillment-item-row')
                    for item in items:
                        sku = soup.find('span', attrs={'data-test': 'item-sku'}).text.replace("SKU:", '')
                        quantity = soup.find('span', attrs={'data-test': 'item-quantity'}).text.replace("Quantity:", '')
                        print(sku, quantity)
                        sku_list.append(int(sku))
                        quantity_list.append(int(quantity))

                except Exception as z:
                    traceback.print_tb(z.__traceback__)
                    print(z)

            details['status'] = delivery_status_list
            details['qty'] = int(sum(quantity_list))

        except Exception as e:
            traceback.print_tb(e.__traceback__)
            print(e)

    except Exception as e:
        traceback.print_tb(e.__traceback__)
        print(e)

    browser.delete_all_cookies()
    browser.quit()
    return details

# in_data = {
# "order_number": "BBY01-806282707265",
# "last_name": "Mauricio",
# "mobile": "9817667660"
# }
# print(order_status(in_data))