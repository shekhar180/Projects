from django.apps import AppConfig


class Message91Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'message91'
