from django.apps import AppConfig


class AwsemailConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'awsemail'
