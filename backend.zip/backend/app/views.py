import requests

from django.http.response import JsonResponse, HttpResponse
from django.shortcuts import render
from rest_framework import views
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from rest_framework import viewsets
from app.helper1 import get_c_no

from .models import Convo_Wati_Acc_Numb,CallingData1,Wati_Webhook, DailyReport

from .serializers import (
    Convo_Wati_Acc_NumbSerializer, CallingData1Serializer, Wati_WebhookSerializer,
    DailyReportSerializer
)


contact_numbers = get_c_no()

def save_conversations_acc_numb(request):
    for c in contact_numbers:
        url = "https://live-server-2553.wati.io/api/v1/getMessages/{0}".format(c)
        headers = {"Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI0MzE5NjQxMC1iNDA2LTQ0ZDktOWFiYy1lZTE5ZmZiZWMzNWEiLCJ1bmlxdWVfbmFtZSI6IlNvbmFtQGtzbGVnYWwuY28uaW4iLCJuYW1laWQiOiJTb25hbUBrc2xlZ2FsLmNvLmluIiwiZW1haWwiOiJTb25hbUBrc2xlZ2FsLmNvLmluIiwiYXV0aF90aW1lIjoiMDgvMDMvMjAyMSAwNToyOToxNCIsImh0dHA6Ly9zY2hlbWFzLm1pY3Jvc29mdC5jb20vd3MvMjAwOC8wNi9pZGVudGl0eS9jbGFpbXMvcm9sZSI6IkFETUlOSVNUUkFUT1IiLCJleHAiOjI1MzQwMjMwMDgwMCwiaXNzIjoiQ2xhcmVfQUkiLCJhdWQiOiJDbGFyZV9BSSJ9.d8Z083VdTnmkv4k86NTY6oU6PhRhEi_ldUc-7cHN9Sg"}
        response = requests.request("GET", url, headers=headers)
        r = response.json()
        if response.status_code == 200 and r["result"]=="success":

            for i in range (len(r["messages"]["items"])):

                if len(r["messages"]["items"][i]) == 12:

                    # print("Wati Template Message : \n")
                    # print(r["messages"]["items"][i]["finalText"])

                    Convo_Wati_Acc_Numb.objects.update_or_create(number=c,conversation = r["messages"]["items"][i]["finalText"],From = "Wati Template Message" ,To = "User", created = r["messages"]["items"][i]["created"]) 

                elif len(r["messages"]["items"][i]) == 19 and r["messages"]["items"][i]["owner"] == False:

                    # print("User Message : \n")
                    # print(r["messages"]["items"][i]["text"])

                    Convo_Wati_Acc_Numb.objects.update_or_create(number=c,conversation = r["messages"]["items"][i]["text"],From = "User" ,To = "Wati",created = r["messages"]["items"][i]["created"]) 


                elif len(r["messages"]["items"][i]) == 19 and r["messages"]["items"][i]["owner"] == True:

                    # print("Wati Message : \n")
                    # print(r["messages"]["items"][i]["text"])

                    Convo_Wati_Acc_Numb.objects.update_or_create(number=c,conversation = r["messages"]["items"][i]["text"],From = "Wati" ,To = "User",created = r["messages"]["items"][i]["created"]) 
                else:
                    pass
    return JsonResponse({"status": "success"})


class conversations_api_acc_numb(APIView):

    def get(self,request,format=None):
        
        number_entered_by_user = request.query_params.get('number')
        if number_entered_by_user:
            queryset = Convo_Wati_Acc_Numb.objects.filter(number=number_entered_by_user).order_by('-created')
        else:
            # queryset = Conversation.objects.all().order_by('-sent')
            queryset = Convo_Wati_Acc_Numb.objects.all().order_by('-created')
        serializer = Convo_Wati_Acc_NumbSerializer(queryset,many = True)
        # filterset_fields = ['number','name','status']

        response = {
                'status': True,
                'message': 'Data fetched successfully.',
                'data': serializer.data
        }
        return Response(response, status=status.HTTP_200_OK)


@api_view(['POST'])
def send_msg_from_wati(request):
    if request.method == "POST":
        res = request.data
        url = "https://live-server-2553.wati.io/api/v1/sendSessionMessage/"+res['number']
        querystring = {"messageText":res['message']}
        headers = {
            "Content-Type": "application/json-patch+json",
            "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI4ODkxY2IzOC0zYmMyLTQ4Y2QtYTg1Ni1kMzU1NWVhZWVjNDAiLCJ1bmlxdWVfbmFtZSI6IlNvbmFtQGtzbGVnYWwuY28uaW4iLCJuYW1laWQiOiJTb25hbUBrc2xlZ2FsLmNvLmluIiwiZW1haWwiOiJTb25hbUBrc2xlZ2FsLmNvLmluIiwiYXV0aF90aW1lIjoiMDcvMzEvMjAyMSAwNTo0OToxNCIsImh0dHA6Ly9zY2hlbWFzLm1pY3Jvc29mdC5jb20vd3MvMjAwOC8wNi9pZGVudGl0eS9jbGFpbXMvcm9sZSI6IkFETUlOSVNUUkFUT1IiLCJleHAiOjI1MzQwMjMwMDgwMCwiaXNzIjoiQ2xhcmVfQUkiLCJhdWQiOiJDbGFyZV9BSSJ9.Rb0BUVwOjbQC1WDY4GxoZivv2Dk2NSnUFwXDKyaJn90"
        }
        res = requests.request("POST", url, headers=headers, params=querystring)
        if res.status_code == 200:
            data = res.json()
            
            return Response(data, status=status.HTTP_200_OK)
        return Response({"error": "Request failed"}, status=res.status_code)
    else:
        return Response({"error": "Method not allowed"}, status=status.HTTP_400_BAD_REQUEST)


class CustomerData(APIView):
    def get(self,request,format=None):
        queryset = CallingData1.objects.all()
        serializer = CallingData1Serializer(queryset,many = True)
        response = {
                'status': True,
                'message': 'Data fetched successfully.',
                'data': serializer.data
        }
        return Response(response, status=status.HTTP_200_OK)


class Wati_Webhook_View(APIView):
    def post(self, request, format=None):
        res = str(request.data)
        webhook_serializer = Wati_WebhookSerializer(data={'webhook': res})
        if webhook_serializer.is_valid():
            serializer = webhook_serializer.save()
            response = {
                'status': True,
                'message': 'Data saved sucessfully.',
                'data': {
                    'webhook': webhook_serializer.data

                }
            }
            return Response(response, status=status.HTTP_201_CREATED)
        else:
            err_res = {
                'status': False,
                'message': webhook_serializer.errors,
                'data': None
            }
            return Response(err_res, status=status.HTTP_200_OK)


class GetDailyReportView(viewsets.ReadOnlyModelViewSet):
    queryset = DailyReport.objects.distinct('mobile_number')
    serializer_class = DailyReportSerializer
