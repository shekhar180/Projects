DTYPES = {
    "ConversationWati": {
        'conversationId': 'string',
        'text': 'string',
        'finalText': 'string',
        'owner' : 'string',
        'created': 'string',
        'eventDescription': 'string',
        'number': 'string',
        'batch_id': 'string'
        
    }
}

BATCH_TABLE_HELPER = {
    "ConversationWati": ['conversationId', 'text', 'finalText','owner','created', 'eventDescription', 'number','batch_id']
}