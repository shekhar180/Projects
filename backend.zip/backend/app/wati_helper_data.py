# from batchHelperData import BATCH_TABLE_HELPER


DTYPES = {

        'number': 'string',
        'name': 'string',
        'value': 'string',
        'fullName': 'string'
 
}

