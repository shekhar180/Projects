DTYPES = {
        'wAid': 'string',
        'fullName': 'string',
        'contactStatus': 'string'
        
}

